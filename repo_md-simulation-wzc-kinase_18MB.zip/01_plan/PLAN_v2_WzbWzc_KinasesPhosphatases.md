# Plan de trabajo v2 — Ciclo de fosforilación Wzb/Wzc en *Acinetobacter baumannii*
### Artículo para *Kinases and Phosphatases* (MDPI)

**Sustituye a la v1 (UppP).** Cambio de blanco decidido en la compuerta 0: el sustrato ahora es una **proteína** (la cola rica en tirosinas de Wzc), no un lípido, con lo que el encaje con el alcance de la revista deja de ser argumentativo y pasa a ser literal.

**Restricción de cómputo:** dinámica molecular limitada. Con el nuevo blanco esta restricción se relaja de forma importante (ver §5).
**Entorno:** Google Colab para todo excepto la producción de DM.
**Fecha:** 31 de julio de 2026. **Estado:** compuerta 0 CERRADA. Fase 1 en cola.

---

## 1. Compuerta 0 — cerrada. Decisiones tomadas

| Decisión | Resolución |
|---|---|
| Objeto del artículo | Ciclo quinasa/fosfatasa **Wzc (BY-quinasa de tirosina) / Wzb (fosfatasa de tirosina de bajo peso molecular)** que regula la producción de cápsula y exopolisacárido en *A. baumannii*. En el clúster capsular figuran anotados como *ptk* y *ptp*. |
| Sistema descartado | UppP / ciclo Und-P: sustrato lipídico, fuera del alcance declarado de la revista (modificaciones postraduccionales de proteínas). Se conserva como material para otra revista. |
| Plan B | BfmR / BfmS (sistema de dos componentes). Fenotipo más amplio y estructura experimental disponible, pero espacio de inhibidores más ocupado (campaña publicada en 2024) y la actividad fosfatasa reside en una quinasa de histidina de membrana. |
| Blanco estructural (docking + DM) | **Lo decide el resultado del control** (Fase 2). Regla de decisión pre-especificada en §4 — se fija ahora, antes de ver los números, para que la elección no sea post hoc. |
| Marco metodológico | Se conserva íntegro: sistemas → estructura → cierre del lazo. Cambia el formalismo del módulo de sistemas: de control de flujo metabólico a **control de un ciclo de modificación covalente**. |
| Revista | *Kinases and Phosphatases*, APC 1000 CHF, ~24 días a primera decisión. **Pendiente:** verificar indexación en Scopus/Scimago antes de comprometer el APC, y enviar pre-submission inquiry. |

### Título de trabajo
*"Is the phosphatase or the kinase in control? Control analysis of the Wzb–Wzc tyrosine phosphorylation cycle in* Acinetobacter baumannii *couples systems-level modeling with structure-based inhibitor prioritization."*

### Hipótesis
- **H1.** El control sobre la salida del ciclo (producción de EPS/cápsula) no se reparte por igual entre la quinasa y la fosfatasa.
- **H2.** La priorización guiada por control reordena los candidatos inhibidores respecto del ordenamiento por afinidad de docking.
- **H3 (emergente, ver §3.2).** La variable controlada no es el *nivel* de fosforilación sino el *ciclado*: la salida sería no monótona respecto del estado de fosforilación, de modo que inhibir cualquiera de las dos enzimas reduce la producción, y el análisis de control dice cuál lo hace con menos dosis.

### Novedad, verificada en la auditoría de Fase 0
- Existe un antecedente que modeló Wzb y Wzc de *A. baumannii* por homología y atacó su interacción (PMID 32402850), y otro que mostró que la inhibición química de una fosfatasa de tirosina bacteriana suprime la producción de cápsula (PMC3356977). **No compiten:** se citan como antecedente directo y se los supera en rigor (estructura de era AlphaFold con validación local del sitio, PoseBusters, DM replicada, y sobre todo el módulo de control y el cierre del lazo, que ninguno tiene).
- La literatura sobre el ciclo declara explícitamente que el mecanismo por el cual el ciclado entre estados de alta y baja fosforilación regula la cápsula **sigue sin esclarecerse**. Ese es el hueco que atacamos con un número.
- Argumento de selectividad regalado: las BY-quinasas no tienen homólogos eucariotas.

---

## 2. Grupo de trabajo

Sin cambios respecto de la v1 en su composición; cambia el énfasis de dos roles.

| Rol | Cambio respecto de la v1 |
|---|---|
| **L — Líder integrador** | Igual. Custodia la narrativa y las compuertas. |
| **S — Biólogo de sistemas / matemático** | Ahora modela un **ciclo de modificación covalente** (ultrasensibilidad de orden cero, multisitio), no una vía metabólica lineal. Es un modelo más pequeño y más limpio. |
| **B — Bioquímico enzimólogo** | Curaduría cinética de LMW-PTP (EC 3.1.3.48) y de la autofosforilación de BY-quinasas; ATP celular; estequiometría del racimo de tirosinas. |
| **E — Bioinformático estructural** | **Ya no hay membrana** para la fosfatasa. Plantillas experimentales disponibles para Wzb bacteriana; para Wzc, el dominio quinasa citoplasmático. |
| **Q — Químico computacional** | Nuevo cuidado obligatorio: los inhibidores de fosfatasas de tirosina están plagados de PAINS (catecoles, quinonas, miméticos de fosfotirosina promiscuos). Filtro PAINS **obligatorio**, no opcional. |
| **D — Científico de datos** | Igual. QSAR solo si aparecen datos de actividad reales; para LMW-PTP es más probable que existan que para UppP. |
| **M — Especialista en DM** | Sistema en agua, sin bicapa. MM/PBSA vuelve a ser metodológicamente válido. Triplicado ahora sí es alcanzable. |
| **A — Auditor adversarial** | Igual (protocolo en §7). |
| **R — Editor científico** | Igual. |

---

## 3. Fases

### FASE 1 — Curaduría (cuello de botella real)
**Colab: N1.**

Qué hay que traer, con fuente citable en cada celda:

1. **Identidad molecular exacta.** Secuencias y anotación de *ptp* (Wzb) y *ptk* (Wzc) en la cepa elegida, desde UniProt y RefSeq. Decidir cepa: preferible una con genoma bien anotado y relevancia clínica; justificar la elección por escrito.
2. **Sitios de fosforilación.** Residuos del racimo C-terminal de tirosinas de Wzc y sitio catalítico de Wzb (motivo CX5R típico de LMW-PTP). Verificar contra literatura, no asumir por homología.
3. **Cinética.** Para la fosfatasa, EC 3.1.3.48 en BRENDA/SABIO-RK (hay abundante caracterización de LMW-PTP en ortólogos; marcar cada valor). Para la autoquinasa, constantes de autofosforilación de Wzc de *E. coli* y homólogos. Concentración de ATP intracelular y abundancias de proteína (PaxDb).
4. **Plantillas estructurales.** Estructuras experimentales de Wzb bacteriana y CpsB depositadas en PDB (p. ej. la entrada 2WJD reúne Wzb de *E. coli* y CpsB de *S. pneumoniae*); para Wzc, la estructura crio-EM del complejo publicada en 2021. Verificar identidad de secuencia con nuestras proteínas antes de usarlas.
5. **Control positivo químico.** Recuperar el compuesto que en 2012 inhibió una PTP bacteriana y suprimió la cápsula, con su IC50. Ese valor fija la escala realista de Ki para el lazo cerrado.

**Compuerta 1.** Igual que en la v1: si menos de la mitad de los parámetros son rastreables, se pasa a **modelo de ensamble** (muestrear el espacio de parámetros plausible y reportar la *distribución* de los coeficientes de control) en vez de un juego puntual. Se decide con los datos en la mano.

### FASE 2 — Modelo del ciclo y análisis de control
**Colab: N2.** Minutos de CPU.

- Ecuaciones: fosforilación de Wzc (autoquinasa, dependiente de ATP) ⇄ desfosforilación por Wzb, con **conservación del Wzc total** y tratamiento explícito del carácter multisitio si los datos lo permiten (si no, aproximación de un solo sitio efectivo, declarada).
- **Dos observables, no uno** (esto es H3 y es donde está la gracia):
  - la fracción de Wzc fosforilado en estado estacionario;
  - el **flujo de ciclado** (velocidad de recambio fosforilación/desfosforilación), que es el candidato natural a variable acoplada a la salida de polisacárido.
- Coeficientes de control de la quinasa y de la fosfatasa sobre **ambos** observables, por perturbación ±1 % de cada actividad. Validación con el teorema de sumatoria.
- Sobol (±50 %, N ≈ 10 000) para robustez del ranking.
- Curvas de respuesta: comprobar si aparece ultrasensibilidad de orden cero y si la salida es no monótona.
- Exportar SBML.

**Compuerta 2 — auditoría técnica y decisión del blanco estructural.** No se avanza si el teorema de sumatoria falla o si el ranking se voltea bajo Sobol.

### FASE 3 — Preparación estructural
**Colab: N3** + servidores web.
Estructura del blanco elegido (AlphaFold DB o ColabFold), validación de pLDDT **local en el sitio**, ProSA, MolProbity, superposición contra la plantilla experimental, protonación a pH 7,4. Atención especial al estado de protonación de la cisteína catalítica del motivo CX5R si el blanco es Wzb: es el residuo que define el mecanismo y el docking.

### FASE 4 — Biblioteca, docking y selección del candidato
**Colab: N4.**
- Biblioteca enfocada de 2.000–10.000: ChEMBL (activos contra LMW-PTP y PTPs bacterianas), DrugBank (reposicionamiento), COCONUT (productos naturales, tu línea previa), más análogos del control positivo.
- Vina → rescoring GNINA → **PoseBusters** → **filtro PAINS obligatorio**.
- Validación del protocolo: recuperar el control positivo entre los mejores rankeados y reportar el enriquecimiento.

**Compuerta 4.** Selección del compuesto único para DM: pasa PoseBusters, pasa PAINS, consenso entre dos funciones de scoring, contactos con residuos catalíticos o del sitio definido, plausibilidad química y una historia que contar.

### FASE 5 — Dinámica molecular
**Producción fuera de Colab; análisis en Colab (N5).**
Sistema soluble en agua: **3 réplicas de 100 ns** (objetivo) con semillas distintas, más **la proteína apo** como control. CHARMM36m/TIP3P, ligando por CGenFF reportando el penalty. MM/PBSA con gmx_MMPBSA sobre la parte estable, media ± desviación entre réplicas. Métricas: RMSD, RMSF, Rg, SASA, puentes de H y ocupancia del ligando en el sitio.

**Compuerta 5.** RMSD estabilizado, ligando en el sitio al final, ΔG con incertidumbre.

### FASE 6 — Cierre del lazo
**Colab: N6.**
ΔG → Ki propagando una **banda** de ±1–2 unidades logarítmicas (MM/PBSA no da valores absolutos fiables). Reinyección como inhibición del nodo correspondiente. Curvas de salida residual vs. dosis, comparando inhibir la quinasa frente a inhibir la fosfatasa a igual Ki. Contraste docking vs. efecto sistémico presentado como caso trabajado en profundidad, no como estadística sobre pocos puntos.

### FASE 7 — Manuscrito, repositorio y auditoría final
Repositorio + Zenodo + depósito del modelo en BioModels; redacción en inglés con formato MDPI; auditoría adversarial completa simulando tres revisores (sistemas, química computacional, microbiología de envoltura/señalización); carta de presentación con dos frases de encaje.

---

## 4. Regla de decisión pre-especificada para el blanco estructural

Se fija **antes** de correr el modelo. Sea C el coeficiente de control sobre el observable acoplado a la salida:

- **Wzb (fosfatasa) domina** (C_Wzb − C_Wzc ≥ 0,15) → docking y DM sobre **Wzb**. Escenario más cómodo: proteína soluble pequeña.
- **Wzc (quinasa) domina** (C_Wzc − C_Wzb ≥ 0,15) → docking y DM sobre el **dominio quinasa citoplasmático de Wzc**, simulado como constructo soluble aislado, declarando explícitamente que se omite el anclaje de membrana y por qué. Sigue siendo viable sin bicapa.
- **Control repartido** (|diferencia| < 0,15) → docking sobre **ambos**, y la DM se hace sobre aquel cuyo mejor complejo tenga mejor calidad de pose y de sitio (criterios de la compuerta 4). Se reporta el reparto como hallazgo: un ciclo con control compartido es en sí mismo un resultado.

En los tres escenarios el artículo funciona. Esa es la señal de que la pregunta está bien planteada.

---

## 5. Qué ganamos con el cambio de blanco

| | UppP (v1) | Wzb/Wzc (v2) |
|---|---|---|
| Encaje con la revista | Argumentativo, riesgo alto de rechazo de escritorio | Literal: fosforilación de una proteína por una quinasa, revertida por una fosfatasa |
| Sistema de DM | Proteína + bicapa + agua, ~150 mil átomos | Proteína soluble + agua, ~30–50 mil átomos |
| Réplicas alcanzables | Una, con dificultad | Tres, más el apo |
| MM/PBSA | Inválido sin membrana implícita | Válido en el esquema estándar |
| Sitio de unión | Bolsillo transmembranal, docking difícil de defender | Sitio catalítico definido por motivo conservado |

---

## 6. Notebooks de Colab

| Notebook | Fase | Contenido | Coste |
|---|---|---|---|
| N1 | 1 | Curaduría trazable de secuencias, sitios, cinética y plantillas | minutos, CPU |
| N2 | 2 | Modelo del ciclo, estado estacionario, control, Sobol, SBML | minutos, CPU |
| N3 | 3 | Preparación y validación estructural | minutos, CPU |
| N4 | 4 | Ligandos, docking, PoseBusters, PAINS, rescoring | horas, CPU/GPU |
| N5 | 5 | Análisis de trayectorias (MDAnalysis/MDTraj) | 1–2 h, CPU |
| N6 | 6 | ΔG → Ki → salida residual → re-ranking y figuras | minutos, CPU |

Fuera de Colab: GROMACS, ProSA-web, MolProbity, BRENDA/SABIO-RK, PDB/AlphaFold DB.

---

## 7. Auditoría adversarial

Sin cambios respecto de la v1: se ejecuta en las compuertas 0, 2, 4 y 7; busca en PubMed, Consensus, Elicit y editoriales; cero invención de citas; salida en formato tabla → críticas priorizadas (Bloqueante / Mayor / Menor) → veredicto simulado → acciones. Ninguna crítica bloqueante queda abierta al pasar de fase.

Ejes específicos que el auditor debe atacar en este proyecto: (i) ¿el modelo del ciclo es demasiado simple para sostener las conclusiones?; (ii) ¿los parámetros de ortólogo invalidan el ranking?; (iii) ¿el compuesto elegido es un PAINS disfrazado?; (iv) ¿se está confundiendo nivel de fosforilación con flujo de ciclado?; (v) ¿la conclusión excede lo que un estudio 100 % in silico puede afirmar?

---

## 8. Riesgos

| Riesgo | Mitigación |
|---|---|
| Sin cinética propia de *A. baumannii* | Modelo de ensamble + Sobol; marcado explícito de ortólogos |
| Inhibidores de PTP notoriamente promiscuos | PAINS obligatorio + discusión honesta de selectividad frente a LMW-PTP humanas |
| El antecedente de 2020 nos pisa el blanco | Diferenciación clara: control cuantitativo + cierre del lazo + rigor estructural |
| Modelo del ciclo demasiado simple | Dos observables, multisitio si los datos lo permiten, y declaración explícita de simplificaciones |
| Revista sin indexar → sin cuartil | Verificar en Scopus/Scimago antes de pagar; plan B: IJMS o Pharmaceuticals |
| Control repartido, sin ganador claro | Ya contemplado en la regla de decisión: es un resultado, no un fracaso |

---

## 9. Manejo de sesiones y modelo

- **Modelo menor:** Fase 1 completa, escritura de N1/N3/N5, formateo de tablas y referencias.
- **Modelo mayor:** compuertas de decisión, diseño e interpretación del modelo del ciclo, selección del candidato, auditorías, discusión y limitaciones.

Al abrir sesión nueva, pegar:

```
Proyecto: Wzb/Wzc — Kinases and Phosphatases
Fase cerrada: ___
Fase actual: ___
Pendiente inmediato: ___
```

---

## 10. Siguiente paso

**Fase 1, notebook N1.** Fijar cepa, traer secuencias y sitios desde UniProt/RefSeq, y empezar la tabla de parámetros cinéticos con fuente por celda. En paralelo, verificar la indexación de la revista y preparar el pre-submission inquiry con el nuevo título.
