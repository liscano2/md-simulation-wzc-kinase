# Reconstrucción honesta del flujo PRISMA a partir de las 11 búsquedas reales
# ejecutadas en esta sesión para curar el sistema Wzb/Wzc (no incluye las
# búsquedas de la Fase 0 sobre encaje editorial/alcance de la revista, que
# son un objetivo distinto).

queries = {
    "Q1_locus_tags_ptp_ptk": 10,
    "Q2_uniprot_locus_tags": 10,
    "Q3_uniprot_AB307_wzb": 8,
    "Q4_pdb_VvWzb": 7,
    "Q5_standish_2012": 6,
    "Q6_fascioquinol_IC50_Wzb": 6,
    "Q7_wzc_cryoEM_2021": 6,
    "Q8_pnas_interfaz_wzb_wzc": 6,
    "Q9_cinetica_wzb_pnpp": 8,
    "Q10_wzc_cryoEM_pdb_id": 7,
    "Q11_uniprot_proteoma_AB307": 6,
}
identificados = sum(queries.values())
print(f"Registros identificados (suma de resultados de las 11 búsquedas): {identificados}")
