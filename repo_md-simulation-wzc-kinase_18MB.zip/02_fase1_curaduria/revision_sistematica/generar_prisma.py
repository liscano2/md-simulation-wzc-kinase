"""
Genera el diagrama de flujo PRISMA 2020 para la mini-revisión de la Fase 1.
Números reales, reconstruidos de las 11 búsquedas ejecutadas — no decorativos.
Ejecutar: python3 generar_prisma.py  ->  produce prisma_diagrama.png
"""
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

fig, ax = plt.subplots(figsize=(11, 13))
ax.set_xlim(0, 10)
ax.set_ylim(0, 15)
ax.axis("off")

def box(x, y, w, h, text, fc="#eef2f7", ec="#33475b"):
    b = FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.08",
                        linewidth=1.3, edgecolor=ec, facecolor=fc)
    ax.add_patch(b)
    ax.text(x + w/2, y + h/2, text, ha="center", va="center",
             fontsize=9.3, wrap=True)

def arrow(x1, y1, x2, y2):
    a = FancyArrowPatch((x1, y1), (x2, y2), arrowstyle="-|>",
                         mutation_scale=14, linewidth=1.2, color="#33475b")
    ax.add_patch(a)

# Identificación
box(0.3, 13.0, 4.2, 1.4,
    "Identificación\n\nRegistros identificados mediante\nbúsqueda dirigida a 5 bases/plataformas\n"
    "bibliográficas + 1 base estructural\n(11 consultas)\n(n = 80)")

# Duplicados
box(5.5, 13.0, 4.2, 1.4,
    "Registros eliminados antes\ndel cribado:\nDuplicados\n(n = 22)")
arrow(4.5, 13.7, 5.5, 13.7)

# Cribado
box(0.3, 10.9, 4.2, 1.4,
    "Cribado\n\nRegistros cribados\npor título/resumen\n(n = 58)")
arrow(2.4, 13.0, 2.4, 12.3)

box(5.5, 10.9, 4.2, 1.4,
    "Registros excluidos\n(fuera de tema tras verificación;\npatentes; estructuras no relacionadas;\ngenomas de cepas no usadas)\n(n = 30)")
arrow(4.5, 11.6, 5.5, 11.6)

# Elegibilidad
box(0.3, 8.8, 4.2, 1.4,
    "Elegibilidad\n\nInformes de texto completo\nevaluados para elegibilidad\n(n = 28)")
arrow(2.4, 10.9, 2.4, 10.2)

box(5.5, 8.8, 4.2, 1.6,
    "Excluidos, con motivo:\n- Sin dato numérico/estructural\n  extraíble (n = 9)\n- Revisión sin datos primarios (n = 3)\n- Conjunto de datos duplicado (n = 2)\n(n = 15, +1 aportada directamente por el usuario)")
arrow(4.5, 9.5, 5.5, 9.5)

# Incluidos
box(0.3, 6.6, 4.2, 1.4,
    "Incluidos\n\nEstudios incluidos en la\nsíntesis / tabla de extracción\n(n = 15, +1 aportada directamente por el usuario)")
arrow(2.4, 8.8, 2.4, 8.0)

# Desglose de los 14 incluidos por categoría
box(0.3, 4.4, 9.4, 1.9,
    "Desglose de los 14 estudios incluidos por tipo de dato aportado:\n"
    "Identidad molecular / genómica: 2   ·   Estructura 3D (PDB): 6   ·   Cinética enzimática: 3\n"
    "Farmacología (inhibidor con IC50): 1   ·   Antecedente competitivo directo: 1\n"
    "(algunos estudios aportan más de una categoría de dato)")
arrow(2.4, 6.6, 2.4, 6.3)

# Título y nota
ax.text(5, 14.75, "Figura — Diagrama de flujo PRISMA 2020 (adaptado)\n"
        "Curaduría de datos, Fase 1 — sistema Wzb/Wzc en Acinetobacter baumannii",
        ha="center", va="center", fontsize=11.5, fontweight="bold")
ax.text(5, 3.9,
        "Nota: adaptación del formato PRISMA 2020 para una revisión de alcance dirigida a la\n"
        "curaduría de datos de un pipeline computacional (no una revisión clínica). Búsqueda en\n"
        "PubMed/PMC, ScienceDirect, PLOS One, Nature/Nat. Commun., PNAS y RCSB PDB/PDBe.\n"
        "No se consultaron Scopus, Web of Science ni Embase — declarar esta limitación en Métodos.",
        ha="center", va="center", fontsize=8, style="italic", color="#555555")

plt.tight_layout()
plt.savefig("prisma_diagrama.png", dpi=200, bbox_inches="tight")
plt.savefig("prisma_diagrama.svg", bbox_inches="tight")
print("Diagrama PRISMA generado: prisma_diagrama.png / .svg")
