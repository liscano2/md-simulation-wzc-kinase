# Mini-revisión sistemática — insumos de la Fase 1 (ciclo Wzb/Wzc)

**Propósito.** Esta no es la revisión sistemática de todo el artículo (esa, si aplica, iría en la
introducción para justificar la novedad — protocolo aparte). Esta es una revisión sistemática
**acotada a la Fase 1**: documenta con qué criterio se seleccionó, se incluyó o se descartó cada
fuente usada para curar identidad molecular, cinética, estructura y farmacología del par Wzb/Wzc.
Su función en el manuscrito es doble: (1) da a la sección 2.1 de Métodos una base metodológica
auditable en vez de una lista de referencias sueltas, y (2) es exactamente el tipo de rigor que un
revisor de *Kinases and Phosphatases* va a buscar antes de confiar en los parámetros del modelo.

**Fecha de la búsqueda:** 31 de julio de 2026 (sesión única; ver limitación de reproducibilidad
temporal en la sección de riesgo de sesgo).

---

## 1. Pregunta y marco de elegibilidad

No es una pregunta clínica, así que PICO/PECO no encaja literalmente. Se usa un marco adaptado
para **validación de blanco farmacológico**:

| Elemento | Definición para esta revisión |
|---|---|
| **Sistema** | El par quinasa/fosfatasa Wzb (LMW-PTP)/Wzc (BY-quinasa) y sus ortólogos directos en bacterias |
| **Tipo de evidencia** | Estudios primarios que reportan (a) parámetros cinéticos (Km, kcat, Vmax), (b) estructuras 3D depositadas (cristal, RMN o crio-EM), o (c) inhibidores químicos con potencia cuantificada (IC50/Ki) |
| **Comparador** | Ortólogos entre especies bacterianas (*E. coli*, *A. baumannii*, *V. vulnificus*, *B. subtilis*, *Lactobacillus*, etc.), marcando siempre cuál es el organismo real de interés y cuál es el ortólogo |
| **Desenlace de interés** | Valor numérico o estructural extraíble y trazable a una fuente citable, utilizable directamente como insumo del modelo de EDO (Fase 2) o del docking (Fase 4) |

## 2. Fuentes consultadas (declaración honesta de acceso real)

Se buscó en **5 bases/plataformas bibliográficas** más **1 base estructural**, todas de acceso
efectivamente verificado en esta sesión (no se afirma acceso a bases que no se consultaron):

1. **PubMed / PMC** (ncbi.nlm.nih.gov, pubmed.ncbi.nlm.nih.gov)
2. **ScienceDirect** (sciencedirect.com)
3. **PLOS One** (journals.plos.org)
4. **Nature / Nature Communications** (nature.com)
5. **PNAS** (pnas.org)
6. **RCSB PDB / PDBe** (rcsb.org, ebi.ac.uk/pdbe) — base estructural, no bibliográfica

**Limitación declarada sin rodeos:** el acceso no fue mediante la interfaz de búsqueda avanzada
nativa (Booleana) de cada base, sino mediante un motor de búsqueda web general dirigido a esos
dominios. Esto es **más débil** que una búsqueda Boole nativa en Scopus/Web of Science/Embase —
que no se pudieron consultar en esta sesión por no tener acceso — y debe declararse así en el
manuscrito. Antes del envío, se recomienda repetir al menos la cadena de búsqueda maestra (§3)
directamente en Scopus o Web of Science para blindar la sección de Métodos frente a un revisor que
pida evidencia de búsqueda sistemática real.

## 3. Cadena de búsqueda (reproducible)

Cadena maestra (variantes usadas en las 11 consultas ejecutadas):

```
("Wzb" OR "Wzc" OR "protein tyrosine phosphatase" OR "BY-kinase" OR
 "bacterial tyrosine kinase" OR "low molecular weight protein tyrosine phosphatase")
AND
("Acinetobacter baumannii" OR "Escherichia coli" OR "Vibrio vulnificus" OR
 "Bacillus subtilis" OR capsul* OR exopolysaccharide OR "colanic acid")
AND
(kinetics OR Km OR kcat OR structure OR crystal OR "solution structure" OR
 "cryo-EM" OR inhibitor OR IC50 OR Ki)
```

Sin restricción de idioma ni fecha de publicación (se aceptaron estudios clásicos de los años
90 sobre Wzb/Wzc de *E. coli*, deliberadamente, porque son la caracterización cinética
fundacional del sistema).

## 4. Criterios de inclusión y exclusión

**Inclusión (debe cumplir al menos uno):**
- I1. Reporta parámetros cinéticos numéricos (Km, kcat o Vmax) de Wzb/Wzc o de un ortólogo directo
  de la familia LMW-PTP/BY-quinasa, con condición experimental declarada (sustrato, pH, T).
- I2. Reporta una estructura 3D depositada en PDB (cristalografía, RMN o crio-EM) de Wzb, Wzc, o
  de sus ortólogos/homólogos de familia directos.
- I3. Reporta un inhibidor químico con potencia cuantificada (IC50/Ki) contra Wzb, Wzc, o su
  familia funcional (PTP bacteriana reguladora de cápsula/EPS).
- I4. Establece identidad molecular verificable (locus_tag, número de acceso, cepa) del sistema
  Wzb/Wzc en *A. baumannii*.

**Exclusión:**
- E1. Revisión, editorial o comentario sin datos primarios extraíbles.
- E2. Estudio exclusivamente en LMW-PTP eucariotas sin comparación o relevancia bacteriana.
- E3. Sin dato numérico o estructural extraíble (menciona el sistema pero no reporta valores).
- E4. Registro duplicado de un conjunto de datos ya capturado por una fuente más completa
  (p. ej., una nota de prensa o un resumen que repite un hallazgo ya extraído del artículo
  original).
- E5. Fuera de tema tras verificación (falso positivo del motor de búsqueda — p. ej. estructuras
  de hemolisina de *Vibrio vulnificus* que comparten organismo pero no el sistema de interés).

## 5. Proceso de cribado y flujo (números reales de esta sesión)

| Etapa | n | Nota |
|---|---|---|
| Registros identificados (11 búsquedas, suma de resultados devueltos) | **80** | Ver `_conteo_prisma.py` para el detalle por consulta |
| Duplicados eliminados (mismo artículo/URL recuperado por más de una consulta) | 22 | p. ej. Tomaras et al. 2010 apareció en 3 consultas distintas; el par Alphonse et al. 2022 apareció en 2 |
| Registros cribados por título/resumen | 58 | |
| Excluidos en cribado (E5 mayoritariamente: patentes de FabI, lectina de hemolisina de *V. vulnificus*, anuncios de genoma de cepas no relacionadas, documentación de software Phenix, un registro con PMID no correspondiente al título) | 30 | |
| Texto completo evaluado para elegibilidad | 28 | |
| Excluidos tras evaluación de texto completo (E1/E3 mayoritariamente) | 14 | p. ej. revisión general de blancos anti-neumocócicos sin dato propio extraíble; genomas anunciados de cepas no usadas |
| **Incluidos en la síntesis / tabla de extracción** | **14** | Ver `tabla_extraccion.csv` |

Diagrama en `prisma_diagrama.png` (generado por `generar_prisma.py`, real, no una imagen decorativa).

## 6. Extracción de datos

Ver `tabla_extraccion.csv`. Columnas: ID, cita, revista/base, tipo de estudio, organismo,
categoría del dato (identidad / cinética / estructura / farmacología / antecedente), valor
extraído, condición experimental, bandera de ortólogo, y estado (confirmado / confirmado
parcial — ver huecos declarados en la Fase 1).

## 7. Evaluación de riesgo de sesgo / calidad

**No existe un instrumento validado y verificado por mí para esta combinación exacta de
enzimología in vitro + biología estructural** (herramientas como RoB2 o STROBE son para ensayos
clínicos y estudios observacionales, no aplican aquí). En vez de invocar un nombre de herramienta
que no verifiqué por búsqueda, se usa un **checklist adaptado y declarado como tal**, con siete
dominios pensados específicamente para insumos de un pipeline computacional:

| Dominio | Qué evalúa |
|---|---|
| D1 — Identidad del organismo | ¿Cepa/locus_tag/número de acceso declarado sin ambigüedad? |
| D2 — Condiciones del ensayo (solo cinética) | ¿pH, temperatura, sustrato y buffer declarados? |
| D3 — Replicación | ¿n, SD/SEM o al menos declaración explícita de determinación única? |
| D4 — Calidad estructural (solo estructuras) | ¿Resolución/método declarado y depositado en PDB con informe de validación? |
| D5 — Directitud | ¿Es el organismo de interés (*A. baumannii*) o un ortólogo? (marcador de aplicabilidad, no de sesgo en sentido estricto, pero crítico para decidir la Compuerta 1) |
| D6 — Conflicto de interés / financiación | ¿Declarado en la fuente? |
| D7 — Confirmación independiente | ¿El hallazgo se repite/cita en trabajos posteriores o es un dato aislado de un solo estudio? |

Calificación por dominio: **Bajo** (criterio satisfecho) / **Medio** (parcialmente satisfecho o no
verificable con lo recuperado) / **Alto** (no satisfecho — riesgo de sesgo o inaplicabilidad
relevante). Ver `tabla_riesgo_sesgo.csv` para la calificación de las 14 fuentes incluidas.

**Hallazgo agregado más importante de esta evaluación:** la mayoría de las fuentes de cinética
disponibles son de **D5 = Alto** (ortólogo, no *A. baumannii* directo) — esto no es un defecto de
la búsqueda, es el estado real de la literatura, y es precisamente el dato que alimenta la
**Compuerta 1** del plan (determinista vs. ensamble). Repórtalo así en el manuscrito: como
hallazgo, no como debilidad oculta.

## 8. Limitaciones de esta mini-revisión

- Búsqueda en una sola sesión, un solo motor, sin doble cribado independiente (aquí el "segundo
  revisor" es la auditoría adversarial de la Compuerta 1, no una segunda persona).
- No se consultaron Scopus, Web of Science ni Embase directamente — declarar esto en el
  manuscrito y, si el tiempo lo permite, repetir la cadena maestra ahí antes del envío.
- No se registró protocolo previo en PROSPERO (no aplica: esto no es una revisión sistemática
  clínica registrable, es un protocolo de curaduría de datos para un pipeline computacional).
