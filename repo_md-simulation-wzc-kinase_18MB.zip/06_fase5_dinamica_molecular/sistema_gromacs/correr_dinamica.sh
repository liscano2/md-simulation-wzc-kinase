#!/bin/bash
# =============================================================================
# Ejecución de la dinámica con GPU (CUDA) real
#   -nb gpu -pme gpu -bonded gpu -update gpu: modo "GPU-resident" -- mantiene
#   los datos en la GPU entre pasos, minimiza la transferencia por PCIe.
#   -ntmpi 1: un solo rango (correcto para 1 GPU). -ntomp sin fijar: deja que
#   GROMACS detecte automáticamente los hilos de CPU disponibles -- si el
#   rendimiento no es el esperado, se puede fijar a mano después.
# =============================================================================
set -e

init=step3_input
mini_prefix=step4_0_minimization
equi_prefix=step4_1_equilibration
prod_prefix=step5_production
prod_step=step5

FLAGS_GPU_MD="-ntmpi 1 -nb gpu -pme gpu -bonded gpu -update gpu"
FLAGS_GPU_MIN="-ntmpi 1 -nb gpu -pme gpu -bonded gpu"   # minimización: sin -update gpu (no es dinámica real)

# --- Minimización ---
if [ ! -f "${mini_prefix}.gro" ]; then
    gmx grompp -f ${mini_prefix}.mdp -o ${mini_prefix}.tpr -c ${init}.gro -r ${init}.gro -p topol.top -n index.ndx -maxwarn -1
    gmx mdrun -v -deffnm ${mini_prefix} ${FLAGS_GPU_MIN}
else
    echo "Minimización ya completa -- se salta."
fi

# --- Equilibración ---
if [ ! -f "${equi_prefix}.gro" ]; then
    gmx grompp -f ${equi_prefix}.mdp -o ${equi_prefix}.tpr -c ${mini_prefix}.gro -r ${init}.gro -p topol.top -n index.ndx
    gmx mdrun -v -deffnm ${equi_prefix} ${FLAGS_GPU_MD}
else
    echo "Equilibración ya completa -- se salta."
fi

# =============================================================================
# Producción por bloques de 10 ns
# =============================================================================
CNT_HASTA=5          # <-- 5 = 50 ns ahora; sube hasta 20 para 200 ns después
CHECKPOINT_MIN=10

cnt=1
while [ ${cnt} -le ${CNT_HASTA} ]; do
    pcnt=$((cnt - 1))
    istep=${prod_step}_${cnt}
    pstep=${prod_step}_${pcnt}

    if [ -f "${istep}.gro" ]; then
        echo "Bloque ${cnt} (${istep}) ya está completo -- se salta."
        cnt=$((cnt + 1))
        continue
    fi

    if [ -f "${istep}.cpt" ]; then
        echo "=== Bloque ${cnt} (${istep}) estaba a medias -- retomando desde su checkpoint ==="
        gmx mdrun -v -deffnm ${istep} -cpi ${istep}.cpt -append -cpt ${CHECKPOINT_MIN} ${FLAGS_GPU_MD}
    else
        if [ ${cnt} -eq 1 ]; then
            pstep=${equi_prefix}
            gmx grompp -f ${prod_prefix}.mdp -o ${istep}.tpr -c ${pstep}.gro -p topol.top -n index.ndx
        else
            gmx grompp -f ${prod_prefix}.mdp -o ${istep}.tpr -c ${pstep}.gro -t ${pstep}.cpt -p topol.top -n index.ndx
        fi
        echo "=== Corriendo bloque ${cnt}/${CNT_HASTA} (${istep}, 10 ns) ==="
        gmx mdrun -v -deffnm ${istep} -cpt ${CHECKPOINT_MIN} ${FLAGS_GPU_MD}
    fi

    cnt=$((cnt + 1))
done

echo ""
echo "Completados hasta el bloque ${CNT_HASTA} = $((CNT_HASTA * 10)) ns totales."
