# Plan de análisis de la dinámica molecular (Fase 5) — pendiente de ejecutar
### Escrito 2026-08-02, ANTES de tener resultados. Actualizar cuando lleguen los .xvg reales.

## Estado: simulación corriendo (bloques 2-20, hacia 200 ns). Análisis aún no ejecutados.

---

## Paso 0 — Preparación (obligatorio antes de cualquier análisis)

```bash
# Unir las 20 trayectorias
gmx trjcat -f step5_1.xtc step5_2.xtc ... step5_20.xtc -o md_completa_raw.xtc

# Corregir PBC -- sin esto, cualquier RMSD/distancia posterior no tiene sentido
gmx trjconv -s step5_1.tpr -f md_completa_raw.xtc -o md_completa.xtc -pbc mol -center
# (elegir Protein para centrar, System o Protein_LIG para la salida)

# Unir los 20 archivos de energía
gmx eneconv -f step5_1.edr step5_2.edr ... step5_20.edr -o energia_completa.edr
```

---

## FIGURA 7 (principal, panel de 6) — Estabilidad estructural y comportamiento del complejo

Destino: cuerpo del manuscrito, mismo formato que Figuras 3/5/6 (panel compuesto, sin título
embebido, en inglés, con pie + análisis).

| Panel | Análisis | Comando GROMACS | Qué muestra |
|---|---|---|---|
| A | RMSD proteína (backbone) | `gmx rms -s step5_1.tpr -f md_completa.xtc -o rmsd_proteina.xvg -tu ns` | Si la proteína se estabiliza o sigue derivando en 200 ns |
| B | RMSD ligando (lig_012) | `gmx rms -s step5_1.tpr -f md_completa.xtc -o rmsd_ligando.xvg -tu ns` | **La pregunta central**: ¿se queda lig_012 en el bolsillo? |
| C | RMSF por residuo, con el bolsillo (481-499,541-548,575) resaltado | `gmx rmsf -s step5_1.tpr -f md_completa.xtc -o rmsf_por_residuo.xvg -res` | Si el sitio catalítico es más rígido que el resto de la proteína |
| D | Radio de giro | `gmx gyrate -s step5_1.tpr -f md_completa.xtc -o radio_giro.xvg` | Compactación/desplegamiento global de la proteína |
| E | SASA total + por residuo | `gmx sasa -s step5_1.tpr -f md_completa.xtc -o sasa_total.xvg -or sasa_por_residuo.xvg -tu ns` | Si el ligando queda más enterrado o se expone con el tiempo |
| F | PCA -- proyección 2D (PC1 vs PC2) | `gmx covar -s step5_1.tpr -f md_completa.xtc -o eigenvalues.xvg -v eigenvectors.trr -av average.pdb` luego `gmx anaeig -v eigenvectors.trr -f md_completa.xtc -first 1 -last 2 -2d pca_2d.xvg` | Si la dinámica explora una sola conformación estable o varias |

---

## FIGURA 8 (panel de 4) — Interacciones clave: agregado, energía, persistencia y ocupación

Destino: cuerpo del manuscrito o suplementaria (a decidir según espacio final). Conecta
directamente con la Tabla S5 (interacciones PLIP del docking, pose estática) -- esta figura
responde si esos mismos hallazgos se sostienen durante los 200 ns de dinámica, no solo en la
pose inicial.

| Panel | Análisis | Comando | Qué muestra |
|---|---|---|---|
| A | Puentes de hidrógeno totales a lo largo del tiempo | `gmx hbond -s step5_1.tpr -f md_completa.xtc -num hbonds_totales.xvg -tu ns` | Si el número agregado de puentes H se mantiene estable o decae |
| B | Energía de unión por residuo ("puntos calientes") | `gmx_MMPBSA` con `idecomp=2` (ver instalación abajo) | Qué residuos contribuyen más a la energía de unión -- se espera que coincidan con Glu543/Lys546/Gln487 (ya vistos en PLIP) |
| C | Distancia de los contactos clave específicos a lo largo del tiempo | `gmx distance -s step5_1.tpr -f md_completa.xtc -select 'resname LIG and name <atomo> ; resid 543 and name <atomo>'` (repetir para Glu543, Lys546, Gln487 -- requiere índices de átomo reales, ver nota) | Si los contactos puntuales identificados en el docking (no solo el conteo agregado) persisten uno por uno |
| D | Ocupación de contacto por residuo del bolsillo (18 residuos) | `gmx mindist -s step5_1.tpr -f md_completa.xtc -or ocupacion_bolsillo.xvg` (con grupo índice del ligando vs. cada residuo del bolsillo) | Qué fracción del tiempo cada uno de los 18 residuos validados en Fase 3 está en contacto real con el ligando -- extiende el análisis de contacto ya hecho en el docking (Figura 6B) a la escala de tiempo de la dinámica |

**Nota importante sobre el Panel C:** `gmx distance` necesita los NOMBRES DE ÁTOMO reales (no solo
el residuo) -- por ejemplo el oxígeno carbonílico de Glu543 o el nitrógeno de amida de Lys546,
los mismos que salieron en el reporte de PLIP (`TableS5_PLIP_interactions_lig012.csv` /
`complejo_lig012_receptor_report.xml`, ya en el proyecto). Se arma el comando exacto con esos
átomos reales una vez se tenga la trayectoria -- no se adivina el nombre de átomo ahora.

**Nota sobre el Panel D:** más simple y robusto con un script corto en Python (MDAnalysis) que
recorra los 18 residuos del bolsillo de una vez, en vez de 18 llamadas separadas a `gmx mindist`.
Se arma cuando se tenga la trayectoria real, reutilizando el mismo cutoff de 4.5 Å y la misma
lista de 18 residuos ya usada en el docking (Fase 4, `contacto_bolsillo_top10.csv`) -- consistencia
metodológica con lo ya hecho, no un criterio nuevo.

---

## FIGURA SUPLEMENTARIA — Estabilidad termodinámica del sistema (panel de 4)

Destino: material suplementario. Es la que un revisor riguroso pide si no está -- confirma que la
simulación en sí es físicamente confiable antes de creer cualquier conclusión estructural.

| Panel | Análisis | Comando | Qué debe verse |
|---|---|---|---|
| A | Temperatura | `gmx energy -f energia_completa.edr -o temperatura.xvg` (elegir Temperature) | Estable ~310.15 K, sin deriva |
| B | Presión | `gmx energy -f energia_completa.edr -o presion.xvg` (elegir Pressure) | Ruidosa pero promedio ~1 bar |
| C | Densidad | `gmx energy -f energia_completa.edr -o densidad.xvg` (elegir Density) | Plana durante producción (ya estabilizada desde equilibración) |
| D | Energía potencial/total | `gmx energy -f energia_completa.edr -o energia_potencial.xvg` (elegir Potential o Total Energy) | Sin tendencia sostenida hacia arriba o abajo |

---

## Energía de unión por residuo ("puntos calientes") — CONFIRMADO, va en Figura 8 Panel B

**No es GROMACS puro** -- requiere `gmx_MMPBSA` (herramienta externa, activa y vigente,
confirmada con GROMACS 2026 en foros reales). Más pesado computacionalmente (recalcula energías
sobre cientos de fotogramas) -- considerar submuestrear frames (ej. 1 de cada 10) si el tiempo de
cómputo es excesivo sobre los 200 ns completos.

Instalación (entorno conda propio, no interfiere con GROMACS):
```bash
conda create -n gmxMMPBSA python=3.10
conda activate gmxMMPBSA
conda install -c conda-forge -c bioconda gmx_MMPBSA
```

Con `idecomp=2` en su archivo de configuración da la descomposición por residuo -- esperaríamos
que Glu543, Lys546, Gln487 (los mismos de PLIP) salgan como los mayores contribuyentes. El
archivo `.in` de configuración exacto se arma cuando se tenga la trayectoria real disponible.

---

## Resumen de destino por figura

| Análisis | Destino |
|---|---|
| RMSD proteína, RMSD ligando, RMSF+bolsillo, Rg, SASA, PCA | **Figura 7** (principal, panel de 6) |
| Puentes H agregados, energía por residuo (gmx_MMPBSA), distancias de contactos clave, ocupación por residuo del bolsillo | **Figura 8** (panel de 4 -- confirmado) |
| Temperatura, presión, densidad, energía potencial | **Figura suplementaria** (panel de 4) |
