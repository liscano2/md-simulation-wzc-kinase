# Pipeline completo de comandos — Fase 5 (Dinámica Molecular)
### Proyecto Wzb/Wzc. Documento de referencia reutilizable — cada comando aquí fue PROBADO y
### FUNCIONÓ en este proyecto real, con las correcciones ya incorporadas (no la versión ingenua
### que falló la primera vez). Guardar para el próximo proyecto de MD.

---

## 0. CHARMM-GUI — lecciones aprendidas (no comandos, pero sí decisiones que ahorran tiempo)

1. **NUNCA nombrar el ligando "LIG" ni ningún código de 3 letras al usar "Upload PDB File"** en
   PDB Reader & Manipulator o Ligand Reader & Modeler por esa vía -- CHARMM-GUI compara contra el
   diccionario de componentes químicos de RCSB (>49,000 entradas, casi saturado -- hasta "ZZZ" y
   "9ZZ" son códigos reales). Esto causó el error real "Mismatch in Ligand Atom Order".
2. **Usar "Load SMILES" en Ligand Reader & Modeler**, no "Upload PDB File", para evitar ese
   problema de raíz -- no hay comparación con RCSB en esa vía.
3. El campo de nombre de residuo para "Make CGenFF topology" acepta de 3 a 6 caracteres, pero
   **usar 3-4 caracteres estándar evita problemas de alineación de columnas** en formato PDB de
   ancho fijo si luego se edita el PDB del complejo a mano (Biopython no maneja bien nombres >4
   caracteres al escribir).
4. **Biopython's PDBIO NO preserva los registros CONECT** al combinar/regenerar estructuras --
   hay que reinsertarlos manualmente si el PDB del ligando original los tenía (ver script abajo).
5. Flujo correcto (en este orden): **Ligand Reader & Modeler (parametrizar) -> PDB Reader &
   Manipulator (combinar con la proteína, usando "Upload CHARMM top & par for hetero chain") ->
   Solution Builder (solvatar/iones/caja)**. No intentar que PDB Reader & Manipulator parametrice
   el ligando automáticamente en línea -- es menos robusto.

---

## 1. Reinsertar CONECT del ligando tras combinar con Biopython (Python)

```python
from Bio.PDB import PDBParser, PDBIO

parser = PDBParser(QUIET=True)
s = parser.get_structure("complejo", "complejo_receptor_ligando.pdb")

# Renombrar el residuo si hace falta (evitar colisión con RCSB si se va a re-subir a CHARMM-GUI)
for residuo in s.get_residues():
    if residuo.resname == "NOMBRE_VIEJO":
        residuo.resname = "NOMBRE_NUEVO"  # 3-4 caracteres, no más

io = PDBIO()
io.set_structure(s)
io.save("complejo_corregido.pdb")

# Reinsertar CONECT (leídos del PDB del ligando SOLO, con el offset real de numeración)
OFFSET = <numero_atomo_inicial_ligando_en_complejo - 1>
conects_ligando = []
with open("ligando_solo.pdb") as f:
    for linea in f:
        if linea.startswith("CONECT"):
            numeros = [int(n) for n in linea.split()[1:]]
            conects_ligando.append([n + OFFSET for n in numeros])

with open("complejo_corregido.pdb") as f:
    lineas = f.readlines()
while lineas and lineas[-1].strip() in ("END", ""):
    lineas.pop()
for fila in conects_ligando:
    partes = [f"{n:>5d}" for n in fila]
    lineas.append(f"CONECT{''.join(partes)}\n")
lineas.append("END\n")
with open("complejo_corregido.pdb", "w") as f:
    f.writelines(lineas)
```

---

## 2. GROMACS — minimización, equilibración, producción (GPU real, NVIDIA/CUDA)

### Diagnóstico de advertencias de grompp -- NUNCA usar -maxwarn a ciegas
```bash
# Primero SIN -maxwarn, para ver qué advertencias hay de verdad
gmx grompp -f minimizacion.mdp -o minimizacion.tpr -c inicial.gro -r inicial.gro -p topol.top -n index.ndx
# Leer las advertencias reales, entenderlas, y SOLO ENTONCES poner el número exacto necesario
gmx grompp -f minimizacion.mdp -o minimizacion.tpr -c inicial.gro -r inicial.gro -p topol.top -n index.ndx -maxwarn 1
```
**Nota real:** `-maxwarn -1` (para "ignorar todas") YA NO FUNCIONA desde GROMACS 2023.1
(confirmado en issue oficial #4772) -- da error "need to be a positive integer".

### Banderas de GPU -- reales y verificadas, con las restricciones reales de cada paso
```bash
# Minimización (integrator=steep): SOLO -nb gpu funciona.
# -pme gpu y -bonded gpu fallan con "Non-dynamical integrator" -- es una restricción real
# de GROMACS, no un error de configuración.
gmx mdrun -v -deffnm minimizacion -ntmpi 1 -ntomp 8 -nb gpu

# Equilibración y producción (integrator=md): las 4 banderas completas SÍ funcionan.
gmx mdrun -v -deffnm equilibracion -ntmpi 1 -ntomp 8 -nb gpu -pme gpu -bonded gpu -update gpu
```

**CRÍTICO -- número de hilos (`-ntomp`):** NO usar más hilos que CPUs lógicas *realmente*
disponibles (especialmente en WSL, donde puede reportar más de las que de verdad reparte).
Usar `-ntomp 16` en una máquina con 8 CPUs efectivas dio "Oversubscribing" y **25,5 ns/día**;
corregir a `-ntomp 8` dio **~72 ns/día** -- casi 3x de mejora real, no cosmética. Si aparece el
aviso de "Oversubscribing", bajar el número hasta que desaparezca, no ignorarlo.

### Producción por bloques con checkpoint real y recuperación ante apagón
```bash
# Bloque 1 (arranca de la equilibración)
gmx grompp -f produccion.mdp -o bloque_1.tpr -c equilibracion.gro -p topol.top -n index.ndx
gmx mdrun -v -deffnm bloque_1 -cpt 10 -ntmpi 1 -ntomp 8 -nb gpu -pme gpu -bonded gpu -update gpu

# Bloque N (arranca del bloque N-1, coordenadas Y checkpoint)
gmx grompp -f produccion.mdp -o bloque_N.tpr -c bloque_N-1.gro -t bloque_N-1.cpt -p topol.top -n index.ndx
gmx mdrun -v -deffnm bloque_N -cpt 10 -ntmpi 1 -ntomp 8 -nb gpu -pme gpu -bonded gpu -update gpu

# Si se corta A MITAD de un bloque (existe el .cpt de ESE bloque, no del anterior):
gmx mdrun -v -deffnm bloque_N -cpi bloque_N.cpt -append -cpt 10 -ntmpi 1 -ntomp 8 -nb gpu -pme gpu -bonded gpu -update gpu
```

### Bucle de una línea para correr muchos bloques seguidos, con recuperación automática
```bash
for cnt in $(seq 2 20); do pcnt=$((cnt-1)); i=step5_${cnt}; p=step5_${pcnt}; [ -f "${i}.gro" ] && continue; [ -f "${i}.cpt" ] && gmx mdrun -v -deffnm ${i} -cpi ${i}.cpt -append -cpt 10 -ntmpi 1 -ntomp 8 -nb gpu -pme gpu -bonded gpu -update gpu || { gmx grompp -f step5_production.mdp -o ${i}.tpr -c ${p}.gro -t ${p}.cpt -p topol.top -n index.ndx && gmx mdrun -v -deffnm ${i} -cpt 10 -ntmpi 1 -ntomp 8 -nb gpu -pme gpu -bonded gpu -update gpu; }; done
```

### Cálculo de rendimiento real y proyección de tiempo (Python)
```python
paso_actual = <paso_donde_se_detuvo>
paso_total = <pasos_totales_del_bloque>
ns_dia = <valor_reportado_por_GROMACS_al_final_del_log>
ns_restantes = <total_a_correr>
horas = ns_restantes / ns_dia * 24
```

---

## 3. WSL — problema real encontrado y su solución

**Síntoma:** `Cannot rename checkpoint file... maybe you are out of disk space?` con espacio de
disco de sobra confirmado (`df -h .`).

**Causa más probable:** trabajar en `/mnt/c/...` (disco Windows vía capa de traducción NTFS/9P
de WSL) en vez del sistema de archivos nativo de Linux.

**Solución:** mover todo el trabajo a `~/` (ext4 nativo dentro de WSL) ANTES de correr producción
larga:
```bash
mkdir -p ~/proyecto_md
cp -r * ~/proyecto_md/   # usar -r, si no se omiten las carpetas (ej. toppar/)
cd ~/proyecto_md
```

**Verificación del uso real de GPU:** el Administrador de Tareas de Windows muestra por defecto
el motor "3D" de la GPU, que puede marcar ~0-5% aunque la GPU esté al máximo en cómputo. Cambiar
la vista a "Cuda" o "Compute_0" en la pestaña Rendimiento -> GPU para ver el uso real.

---

## 4. Post-procesamiento de trayectoria (GROMACS, local)

```bash
gmx trjcat -f bloque_1.xtc bloque_2.xtc ... bloque_N.xtc -o md_completa_raw.xtc

# IMPORTANTE: centrar en el grupo PROTEÍNA+LIGANDO combinado (ej. "SOLU" si viene de
# CHARMM-GUI Solution Builder), NO solo en "Protein". Centrar solo en la proteína puede
# causar problemas reales de PBC si el ligando no participa en el cálculo del centro
# (caso real documentado: foro de gmx_MMPBSA, sistemas donde centrar en la proteína sola
# no resolvió el PBC y hubo que centrar en un grupo distinto). Verificar con
# `gmx make_ndx` o revisar el índice ya generado por CHARMM-GUI qué grupo combina
# proteína+ligando antes de correr esto.
gmx trjconv -s bloque_1.tpr -f md_completa_raw.xtc -o md_completa.xtc -pbc mol -center
# grupo para centrar: SOLU (proteína+ligando) -- grupo para salida: System o SOLU

gmx eneconv -f bloque_1.edr bloque_2.edr ... bloque_N.edr -o energia_completa.edr
echo "Temperature" | gmx energy -f energia_completa.edr -o temperatura.xvg
echo "Pressure"    | gmx energy -f energia_completa.edr -o presion.xvg
echo "Density"     | gmx energy -f energia_completa.edr -o densidad.xvg
echo "Potential"   | gmx energy -f energia_completa.edr -o energia_potencial.xvg
```

---

## 5. Análisis en Python (MDAnalysis, Colab) — ver notebook `N6_analisis_MD_completo.ipynb`

Resumen de qué hace cada análisis (código completo en el notebook):
- RMSD proteína/ligando: `MDAnalysis.analysis.rms.RMSD`
- RMSF por residuo: `MDAnalysis.analysis.rms.RMSF` (tras `align.AlignTraj`)
- Radio de giro: `AtomGroup.radius_of_gyration()` (nativo, sin módulo aparte)
- SASA: paquete `freesasa` (no está nativamente robusto en MDAnalysis)
- PCA: `MDAnalysis.analysis.pca.PCA`
- Interacciones por fotograma: `pandamap` (CLI, requiere `dssp` como dependencia de sistema)
- Distancias/ocupación de contacto: cálculo directo con `numpy.linalg.norm` entre AtomGroups

**Detección automática del nombre del ligando:** no asumir el nombre a ciegas -- filtrar
`u.residues.resnames` excluyendo los 20 aminoácidos estándar + agua + iones comunes.

---

## 7. Por qué se usa cada cosa — explicación para recordar en el próximo proyecto

| Comando/decisión | Por qué existe / para qué sirve |
|---|---|
| `gmx grompp` sin `-maxwarn` primero | Para VER las advertencias reales antes de decidir si son seguras de ignorar -- nunca usar un número grande "por si acaso" sin leerlas |
| `-maxwarn N` (número exacto, no genérico) | Le dice a GROMACS cuántas advertencias reales ya revisaste y aceptas -- un número mayor al necesario puede esconder un problema real distinto |
| `-nb gpu` (siempre) | Mueve el cálculo de interacciones no-enlazantes (la parte más pesada) a la GPU |
| `-pme gpu -bonded gpu -update gpu` (solo con `integrator=md`) | Modo "GPU-resident": mantiene los datos en la GPU entre pasos, evita transferencia constante por PCIe -- pero requiere un integrador dinámico real, no funciona con minimización (`steep`) |
| `-ntmpi 1` | Correcto para 1 sola GPU -- un solo rango de MPI hablándole a la tarjeta |
| `-ntomp <N real>` | Debe coincidir con los hilos de CPU REALMENTE disponibles (verificar con el aviso de "Oversubscribing" si aparece) -- usar de más no acelera, ralentiza |
| `-cpt 10` | Punto de control cada 10 minutos REALES de reloj -- protege contra apagones/cortes, sin generar archivos de control excesivamente grandes |
| Trabajar en `~/` y no en `/mnt/c/...` (WSL) | La capa de traducción NTFS de WSL puede fallar en operaciones de archivo atómicas (como renombrar el checkpoint) -- el sistema de archivos nativo de Linux no tiene ese problema |
| `-settime` en `trjcat`/`eneconv` (con bloques que reinician en t=0) | Sin esto, GROMACS puede interpretar bloques con el mismo rango de tiempo como redundantes y quedarse solo con el último -- hay que decirle explícitamente el tiempo real acumulado de cada bloque |
| Centrar en `SOLU` (proteína+ligando), no solo `Protein` | El ligando debe participar en el cálculo del centro de la caja -- si no, hay riesgo real de que quede mal posicionado respecto a las imágenes periódicas |
| `-pbc mol -center` (siempre, antes de cualquier análisis) | Sin esto, moléculas pueden aparecer "cortadas" o saltando entre imágenes periódicas -- CUALQUIER RMSD/distancia calculada después sin esto no tiene sentido físico |
| Revisar SIEMPRE con `gmx check` tras unir trayectorias | Verificación independiente y objetiva (número de átomos, fotogramas, tiempo final) -- no confiar solo en que el comando "no dio error" |

## 8. Proceso estándar de dinámica molecular — checklist para recordar siempre

**Antes de correr:**
- [ ] Verificar GPU real: `gmx --version` debe decir `GPU support: CUDA`
- [ ] Confirmar hilos de CPU reales disponibles (evitar "Oversubscribing")
- [ ] Trabajar en filesystem nativo de Linux, no en `/mnt/c/` si usas WSL

**Durante la corrida:**
- [ ] Checkpoint real cada 10 min (`-cpt 10`), no confiar en el default
- [ ] Producción en bloques manejables (10 ns es un buen tamaño), no un solo bloque gigante
- [ ] Guardar el rendimiento real (ns/día) de cada corrida, no solo confiar en estimaciones

**Salidas que SIEMPRE pedir, como estándar, en todo proyecto de MD futuro:**
1. **Estabilidad del sistema** (obligatorio, revisor lo pide si falta): temperatura, presión,
   densidad, energía potencial -- sin esto, ninguna otra conclusión es confiable.
2. **RMSD de la proteína Y del ligando por separado** -- el del ligando es el que responde si el
   candidato se queda en el sitio o se sale.
3. **RMSF por residuo**, con el sitio de interés resaltado -- conecta con cualquier análisis
   estructural previo (docking, homología).
4. **Radio de giro** -- chequeo simple de que la proteína no se despliega.
5. **SASA** -- si el ligando se entierra más o se expone con el tiempo.
6. **PCA / dinámica esencial** -- si el sistema explora una sola conformación o varias.
7. **Interacciones específicas persistentes** (las mismas que salieron en el docking/PLIP) --
   confirma si lo que se vio en la pose estática se sostiene en el tiempo.
8. **Ocupación de contacto por residuo** del sitio validado -- extiende el análisis de docking a
   la escala de tiempo de la dinámica.

**Al unir/analizar trayectorias:**
- [ ] Verificar SIEMPRE con `gmx check` que el número de fotogramas y el tiempo final sean los
      esperados ANTES de seguir con cualquier análisis -- un error de unión silencioso invalida
      todo lo que se calcule después.
- [ ] Si hay más de un bloque con tiempo reiniciado en 0, usar `-settime` explícito, no confiar
      en la detección automática.

**Sobre réplicas (para recordar en el próximo proyecto):**
- Los revisores rigurosos prefieren triplicado (3 réplicas independientes, semillas de velocidad
  distintas) para reportar promedio ± SD real entre simulaciones.
- Si no hay recursos para triplicado, es válido presentar una única trayectoria larga, siempre
  que se declare la limitación explícitamente en el manuscrito -- NUNCA fabricar réplicas o
  presentar variación dentro de una sola trayectoria (block averaging) como si fuera variación
  entre réplicas independientes. Son conceptos distintos y deben nombrarse con precisión.


## 9. Herramientas externas mencionadas pero NO ejecutadas aún (pendiente si se retoma)

- **gmx_MMPBSA** (energía de unión por residuo, "puntos calientes"): entorno conda propio,
  `conda install -c conda-forge -c bioconda gmx_MMPBSA`, usar `idecomp=2` para descomposición
  por residuo. Más pesado computacionalmente -- considerar submuestrear fotogramas.

## 10. Lección real: .tpr NO sirve como referencia de topología para análisis por resid

**Encontrado en este proyecto:** CHARMM-GUI/GROMACS renumeran internamente los residuos de la
proteína empezando en 1 dentro del `.tpr` (confirmado: un dominio real numerado 451-700 aparecía
como 1-250 al cargar el `.tpr` con MDAnalysis), mientras que el `.pdb`/`.gro` de entrada original
(`step3_input.pdb`) SÍ conserva la numeración real.

**Regla para recordar:** para cualquier análisis por número de residuo (RMSF, distancias,
selección de bolsillo, etc.) usar SIEMPRE `step3_input.pdb` o `.gro` como referencia de topología
en MDAnalysis -- nunca el `.tpr`, aunque técnicamente también cargue y no dé error (el error es
silencioso: los `resid` simplemente no encuentran nada, o encuentran el residuo equivocado).

---

## 11. Análisis post-trayectoria en Python (MDAnalysis) — lo que funcionó

GROMACS no se reinstaló en Colab; todo el análisis de trayectoria se hizo con MDAnalysis, que es
mucho más liviano y suficiente para lo que no requiere GPU.

| Análisis | Herramienta real usada |
|---|---|
| RMSD proteína / ligando | `MDAnalysis.analysis.rms.RMSD` (con `groupselections` para el ligando) |
| RMSF por residuo | `rms.RMSF` **después** de `align.AlignTraj(..., in_memory=True)` |
| Radio de giro | `AtomGroup.radius_of_gyration()` (nativo, sin módulo extra) |
| SASA | paquete `freesasa` sobre PDB por fotograma (submuestreado) |
| PCA / dinámica esencial | `MDAnalysis.analysis.pca.PCA(..., align=True)` |
| Interacciones por fotograma | `pandamap` (CLI) sobre PDB extraídos cada 10 ns |
| Distancias / ocupación de contacto | `numpy.linalg.norm` directo entre AtomGroups, cutoff 4.5 Å |

### Trampas reales encontradas (todas costaron tiempo, todas evitables)

1. **`.tpr` NO sirve como referencia de topología.** Renumera los residuos desde 1 (un dominio
   451-700 aparece como 1-250). Usar SIEMPRE `step3_input.pdb`/`.gro`. El fallo es SILENCIOSO:
   los `resid` simplemente no encuentran nada.
2. **`trjcat` y `eneconv` descartan bloques con el mismo tiempo de inicio.** Si cada bloque
   reinicia su reloj en 0 ps, hay que pasar `-settime` con los tiempos acumulados explícitos
   (0, 10000, 20000...). Sin eso se queda SOLO con el último bloque, sin avisar. Verificar
   SIEMPRE después con `gmx check` (número de fotogramas y tiempo final esperados).
3. **Centrar en el grupo proteína+ligando** (`SOLU` si viene de CHARMM-GUI Solution Builder), no
   solo en `Protein`, y acordarse de pasar `-n index.ndx` o los grupos personalizados no aparecen.
4. **MDAnalysis escribe todo como `ATOM`**, incluido el ligando. PandaMap busca `HETATM` para
   identificar la molécula pequeña, así que hay que convertir esas líneas después de escribir el
   PDB (reemplazo seguro de columnas, misma longitud de línea).
5. **Parsear la salida de PandaMap por el número real, no por conteo de palabras.** Contar
   ocurrencias de "Interaction" da siempre 1. El dato real está en
   `Before filtering: N total interactions` → extraer con regex.
6. **Colab reinyecta `MPLBACKEND` tras un reinicio de kernel** y eso rompe cualquier subproceso
   externo que use matplotlib. Pasar `env` con `MPLBACKEND=Agg` al `subprocess.run`.
7. **Reiniciar el kernel borra las variables**, pero los archivos en disco sobreviven. Recargar
   desde los `.pkl` en vez de depender de que la variable siga en memoria.

## 12. Figuras en calidad de revista

- **MDPI exige mínimo 600 dpi** (verificado en su Layout Style Guide oficial, no asumido).
  Formatos aceptados: TIFF, PNG, JPG. Para figuras con más de un panel, etiquetar a, b, c, d.
- Exportar a TIFF con compresión **LZW** (sin pérdida): `img.save(ruta, format="TIFF",
  dpi=(600,600), compression="tiff_lzw")`. Convertir DESDE el PNG ya validado visualmente, no
  regenerar la figura (evita que se cuele un cambio no revisado).
- Para ensamblar paneles sin distorsión: medir la proporción alto/ancho REAL de cada PNG con PIL
  y usar esas proporciones como `height_ratios` del `GridSpec`, en vez de adivinarlas.
- Verificar la ausencia de superposición de forma programática, no a ojo:
  `ax.get_tightbbox(renderer)` para cada eje y `bbox1.overlaps(bbox2)` sobre todos los pares.
- No repetir letras de panel: si una fila completa ya lleva su letra, los subpaneles internos se
  identifican por su rótulo propio (ej. el tiempo en ns), no con otra A/B/C/D.

## 13. gmx_MMPBSA — estado real y dónde quedó bloqueado

Instalación que SÍ funcionó (entorno conda propio, sin tocar el GROMACS compilado con CUDA):
```bash
conda create -n gmxMMPBSA python=3.11 -y
conda activate gmxMMPBSA          # <- CRÍTICO: activar ANTES de instalar, o instala en base
conda install -c conda-forge "mpi4py=4.0.1" "ambertools<24" -y
conda install -c conda-forge "numpy=1.26.4" "matplotlib=3.7.3" "scipy=1.14.1" "pandas=1.5.3" -y
conda install -c conda-forge -c bioconda gmx_MMPBSA -y
gmx --version | head -3            # el GROMACS del sistema sigue visible; NO reinstalarlo aquí
```

Errores resueltos en orden (cada uno costó una iteración):
1. `gmx: command not found` en Colab tras `condacolab` → el entorno nuevo no traía GROMACS.
   Resuelto corriendo todo localmente en WSL, donde GROMACS ya estaba compilado.
2. `print_res="481-499,..."` → formato inválido. Requiere identificador de cadena: `"A/481-499,..."`.
3. `must define residues for both receptor and ligand` → faltaba el lado del ligando: `"A/... B/1"`.
4. `residue does not have a chain ID` → el PDB de CHARMM-GUI usa segmentos (PROA/HETA/IONS/SOLV)
   con la columna 22 (cadena) VACÍA. Hay que asignarla explícitamente mapeando segmento → cadena.

**BLOQUEADO en:** `número de residuos del complejo (251) y de la referencia (20999) son distintos`.
**Causa:** el `-cr` apuntaba al sistema completo (con agua e iones), pero el complejo que analiza
gmx_MMPBSA es solo proteína+ligando.
**Solución identificada, NO ejecutada:** construir el PDB de referencia con SOLO proteína+ligando
(251 residuos) y la columna de cadena asignada (A=proteína, B=ligando). Ese es el siguiente paso
exacto si se retoma.
