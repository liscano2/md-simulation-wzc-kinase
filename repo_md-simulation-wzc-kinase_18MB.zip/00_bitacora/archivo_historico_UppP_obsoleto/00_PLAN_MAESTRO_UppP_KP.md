> **⚠️ OBSOLETO (2026-07-31).** El blanco cambió de UppP (fosfatasa de sustrato lipídico) a
> **Wzb/Wzc** (fosfatasa/quinasa de sustrato proteico), por pedido explícito de trabajar con una
> proteína como blanco. El plan vigente es `PLAN_v2_WzbWzc_KinasesPhosphatases.md`. Este
> documento se conserva solo como registro histórico de la Fase 0 original. Ver
> `BITACORA_MAESTRA.md`, entrada 002, para el detalle del pivote.

# PLAN MAESTRO — Artículo UppP (*Acinetobacter baumannii*) para *Kinases and Phosphatases* (MDPI)

**Versión:** 1.0 · **Fecha:** 31 julio 2026 · **Responsable:** Yamil Liscano
**Estado:** Fase 0 (encuadre y blindaje editorial) — pendiente de aprobación de la Compuerta 0
**Archivo vivo:** actualizar al cierre de cada fase; la bitácora es el registro cronológico.

---

## 0. Resumen ejecutivo de la decisión estratégica

Se propone un artículo original, 100 % in silico, que encadena:

**(A)** modelo cinético de EDO del ciclo del undecaprenil-fosfato + Análisis de Control Metabólico (ACM) → prioriza a **UppP** como nodo de control de flujo;
**(B)** cribado virtual estructural sobre UppP embebida en membrana (sitio catalítico y sitio alostérico ya validado en el paper propio de *Toxins* 2026);
**(C)** **una sola dinámica molecular** del complejo líder + MM/PBSA → Ki predicho;
**(D)** **cierre del lazo**: reinyección del Ki en el modelo de EDO y re-ranking de candidatos por colapso de flujo de Lipid II, no por score de docking.

La contribución metodológica central es el eslabón **(D)**: *afinidad ≠ efecto*. La contribución biológica es posicionar a una **fosfatasa integral de membrana** como el punto de control cuantitativamente dominante de la homeostasis de la envoltura en un patógeno ESKAPE.

### Título de trabajo (inglés, para la revista)

> *Control-Guided Prioritization of the Integral-Membrane Phosphatase UppP in* Acinetobacter baumannii*: A Closed-Loop In Silico Framework Coupling Metabolic Control Analysis with Structure-Based Screening and Molecular Dynamics*

---

## 1. Análisis de encaje con la revista (lectura crítica, sin optimismo)

**Datos verificados el 31/07/2026 en la web de la revista:**

| Ítem | Dato |
|---|---|
| Revista | *Kinases and Phosphatases* (MDPI), ISSN 2813-3757 |
| Volumen actual | Vol. 4 (2026), trimestral, iniciada en 2022–2023 |
| 1.ª decisión | ~23,8 días (mediana, 1.er semestre 2026) |
| Aceptación → publicación | ~3,7 días |
| Alcance declarado | "procesos moleculares y biológicos de la fosforilación de proteínas **y de cualquier otra modificación postraduccional (PTM), de procariotas a humanos**"; incluye *estudios estructurales de quinasas y fosfatasas … para elucidar su mecanismo catalítico*, y *desarrollo de fármacos que afectan PTM* |

### 1.1 El riesgo real: UppP no es una enzima de PTM

UppP (EC 3.6.1.27) desfosforila un **pirofosfato lipídico** (Und-PP), no una proteína. El "Aims & Scope" está redactado alrededor de PTM. **Existe un riesgo concreto de rechazo de escritorio (desk rejection) por alcance**, y sería un error de planificación no decirlo.

### 1.2 Los tres argumentos que sí sostienen el envío

1. **Precedente propio de la revista**: publicó el Special Issue *"Inhibitors for Alkaline Phosphatase"* (editor invitado con intereses en inhibición enzimática y docking molecular). La fosfatasa alcalina tampoco es una enzima de PTM → la revista **ya aceptó fosfatasas no-PTM y trabajo de docking**.
2. **La propia descripción del portal** dice "*every aspect of post-translational modifications in all biological systems, **from bacteria to humans***" y lista **biología estructural, química medicinal y farmacología** entre sus disciplinas.
3. Hay artículos recientes de la revista que combinan **docking + dinámica molecular + validación** (p. ej. el trabajo sobre SET/CIP2A–PP2A, 2026) → el formato metodológico es bienvenido.

### 1.3 Acciones obligatorias de blindaje editorial (Fase 0)

- **Pre-submission inquiry** a `kinasesphosphatases@mdpi.com`: título + abstract + 3 líneas preguntando explícitamente si el alcance cubre una **fosfatasa bacteriana integral de membrana de la superfamilia PAP2/BacA** como blanco farmacológico. Mencionar el precedente del SI de fosfatasa alcalina. Coste: 0 €, ~3 días de espera, elimina el 80 % del riesgo.
- **Ingeniería de encaje del manuscrito** (no cosmética, estructural):
  - Encuadrar a UppP como **fosfatasa** en todo el texto: superfamilia PAP2, motivos catalíticos conservados (BacA1/BacA2), química de transferencia de fosfato, comparación con las otras fosfatasas del sistema (PgpB, YbjG, BcrC, HupA).
  - Una figura o subsección dedicada al **mecanismo catalítico de la fosfatasa** y a cómo el ligando líder perturba la geometría del sitio catalítico (esto sale de la MD única — ver §4, Fase 4).
  - Palabras clave con "phosphatase" en primer lugar.
- **Verificar antes de enviar** (páginas `/indexing` y `/apc` de la revista): indexación (Scopus/ESCI/PubMed) y APC vigente. **Advertencia honesta:** es una revista joven; probablemente **sin factor de impacto JCR todavía**. Si su institución/Minciencias exige cuartil Scimago o indexación Scopus, verifíquelo *antes* de invertir el APC.

### 1.4 Plan B (si hay desk rejection por alcance)

Orden de reenvío sin rehacer nada: **Antibiotics** (MDPI, Q1–Q2, encaje perfecto AMR) → **IJMS** → **Pharmaceuticals** → **Microorganisms**. Para el ángulo de sistemas: **Computation**, **Biomolecules**, o *npj Systems Biology and Applications*. El manuscrito debe escribirse de modo que el cambio de revista solo requiera reformatear referencias y ajustar 2–3 párrafos del encuadre.

---

## 2. Grupo de trabajo (roles virtuales)

Cada rol es una "voz" que se activa en su fase y firma sus decisiones en la bitácora. El **Líder Integrador** es el único que habla con el usuario para cerrar compuertas.

| Rol | Alias | Responsabilidad | Fases |
|---|---|---|---|
| **Líder Integrador (PI virtual)** | **L** | Coherencia de la narrativa, control de compuertas, gestión de créditos/sesiones, decide qué se reporta y qué se descarta | Todas |
| Bioquímico enzimático / curador de cinética | **BQ** | Km, kcat, [E], unidades, marcado de valores de ortólogo, trazabilidad BRENDA/SABIO-RK | F1 |
| Matemático / biólogo de sistemas | **MS** | EDO, estado estacionario, ACM, teorema de sumatoria, Sobol, SBML | F2, F5 |
| Biofísico estructural de membranas | **BE** | Modelo de UppP, orientación OPM/PDBTM, CHARMM-GUI, parámetros de MD, análisis de trayectoria | F3, F4 |
| Químico computacional / docking | **QC** | Biblioteca, preparación de ligandos, Vina/GNINA, PoseBusters, rescoring, huellas de interacción | F3 |
| Analista de datos / ingeniero de reproducibilidad | **AD** | Notebooks Colab, control de versiones, semillas, figuras publication-ready, Zenodo | Todas |
| Microbiólogo de RAM | **MB** | Relevancia clínica, cepa, esencialidad, resistencia a bacitracina, límites de la extrapolación | F0, F5, F6 |
| Editora científica | **ED** | Redacción en inglés, normas MDPI, cover letter, respuesta a revisores (skill `escritor-revistas-cientificas`) | F6, F7 |
| Panel de auditoría | **R1/R2/R3** | Revisión adversarial con literatura verificada (ver §5) | Fin de cada fase |

---

## 3. Correcciones de diseño respecto al borrador ilustrativo

El borrador en español (`UppP_borrador_ES.docx`) es una **maqueta con datos simulados**. Tres decisiones cambian para la versión real:

1. **Eliminar el módulo QSAR/ML** salvo que la Fase 3 confirme que existen datos de bioactividad etiquetados para UppP/BacA en ChEMBL/BindingDB (probablemente **no** existen: el blanco casi no tiene química publicada). Un QSAR entrenado sin datos reales es el defecto más fácil de detectar por un revisor. **Sustituto defendible:** cribado en dos etapas con *consensus scoring* (AutoDock Vina + GNINA CNN), filtro geométrico PoseBusters, y análisis de huellas de interacción (ProLIF) frente al control positivo Compound 4 (Jukič et al. 2022) y bacitracina.
2. **Una sola MD, pero diseñada para resistir revisión** (ver §4, Fase 4). El triplicado es el estándar Q1; al no poder pagarlo, se compensa con diseño y se declara como limitación explícita.
3. **Reutilizar activos propios ya publicados** (paper *Toxins* 2026): modelo AlphaFold2 de UppP de *A. baumannii* ACICU (UniProt B2HXY4), bolsillo alostérico validado, control Compound 4. Esto ahorra semanas y da continuidad de línea. **Cuidado:** el nuevo artículo debe ser claramente distinto (moléculas pequeñas + sistemas vs. péptidos) y citar el previo; nunca reciclar figuras.

---

## 4. Fases, compuertas y etapas en Colab

Regla general: **no se pasa de fase sin cerrar su compuerta con el usuario**. Cada fase produce archivos que se guardan en `~/Claude/proyecto/UppP_KP/<carpeta de la fase>/` y una entrada en la bitácora.

### FASE 0 — Encuadre y blindaje editorial *(sin Colab)*
**Tareas:** pre-submission inquiry; verificación de indexación/APC; búsqueda de novedad de blindaje (¿existe ya un modelo cinético del ciclo Und-P? ¿algún ACM de la vía de peptidoglicano?) en PubMed + Consensus + Elicit + Scopus; definición final de hipótesis H1/H2 y del título.
**Entregables:** `00_plan/presubmission_inquiry.md`, `00_plan/novedad_blindaje.md` (tabla de literatura con DOI verificados), título y abstract v1.
**Compuerta 0:** ¿la revista confirma el alcance (o el riesgo es aceptable) y ningún grupo publicó ya el modelo cinético del ciclo Und-P?

### FASE 1 — Parametrización cinética real *(Colab: Notebook 01)*
**Tareas (BQ):** reconstruir la topología del ciclo (KEGG/BioCyc/Rhea: MraY → MurG → MurJ → PBP/transpeptidación → UppP); extraer Km, kcat, Vmax, [E] de **BRENDA y SABIO-RK**; cuando no exista dato de *A. baumannii*, tomar ortólogo (*E. coli*, *P. aeruginosa*) y **marcarlo**; abundancias de proteína en PaxDb; tamaño del pool de Und-P desde literatura.
**Colab 01 hace:** consulta programática de SABIO-RK (API REST) y BRENDA (SOAP con credenciales gratuitas), normalización de unidades (todo a mM y s⁻¹), tabla de trazabilidad con fuente + organismo + condición experimental + flag `es_ortologo`.
**Entregables:** `01_datos_cineticos/tabla1_parametros.csv` + `.xlsx`, `fuentes.bib`.
**Compuerta 1 (crítica):** ¿hay ≥1 parámetro real (no inventado) por reacción? Si dos o más reacciones quedan sin ningún dato experimental ni de ortólogo cercano, **el paper cambia de forma** (se convierte en análisis de sensibilidad estructural, no en modelo parametrizado). Decidir aquí, no después.

### FASE 2 — Modelo de EDO + ACM + Sobol *(Colab: Notebook 02)*
**Tareas (MS):** leyes Michaelis–Menten reversibles; **conservación explícita del pool del transportador** (Und-P + Lipid I + Lipid II + Lipid II_out + Und-PP = constante); integración a estado estacionario (SciPy BDF/Radau o Tellurium); FCC por perturbación ±1 % de cada Vmax; **validación obligatoria ΣC^J = 1**; índices de Sobol de orden total (SALib, ±50 %, N ≈ 10 000); exportación a **SBML** para BioModels.
**Punto de partida:** `scripts/mca_template.py` del skill `pipeline-blancos-sistema-estructura` (ya probado con el modelo de juguete).
**Entregables:** `02_modelo_edo_acm/modelo.xml` (SBML), `fcc_resultados.csv`, `sobol_resultados.csv`, `Figura2.svg`.
**Compuerta 2:** ΣC^J = 1,000 ± 0,01 **y** decisión narrativa según el resultado:
- Si UppP domina (C^J ≳ 0,4) → narrativa planeada, todo sigue.
- Si el control se reparte o domina otra enzima → **no se fuerza el resultado**: el artículo se reescribe como "el control reside en X" y el blanco estructural cambia o se justifica UppP por otro criterio (esencialidad, druggability). Es un resultado publicable igual; forzarlo sería fraude.

### FASE 3 — Estructura, membrana y cribado virtual *(Colab: Notebook 03 + CHARMM-GUI en web)*
**Tareas (BE + QC):**
- Receptor: modelo AlphaFold2 de B2HXY4 (reutilizado del paper *Toxins*) **+ comparación/superposición con la estructura experimental del homólogo** (UppP de *E. coli*, Workman et al. 2018; BacA, El Ghachi et al. 2018) para justificar calidad local del sitio. Protonación a pH 7,4 (PROPKA/H++). Orientación con OPM/PDBTM.
- Definición de dos sitios: **catalítico** (motivos BacA1/BacA2; Glu17, Glu21, Ser27, Arg174, Ser175) y **alostérico** (el validado en *Toxins* 2026 con Compound 4).
- Biblioteca: ChEMBL + COCONUT (productos naturales, incluye la línea de venenos del grupo) + DrugBank; filtro de semejanza a fármaco; enumeración de tautómeros/protonación.
- Docking: **Vina** para volumen → top 5 % → **GNINA (CNN rescoring)** → **PoseBusters** (obligatorio) → huellas de interacción (ProLIF) → *consensus rank*.
- Controles: Compound 4 (positivo) + bacitracina (referencia mecanística) + señuelos aleatorios de propiedades pareadas (control negativo barato y muy bien visto).
**Colab 03 hace:** todo el docking (Vina/GNINA corren bien en Colab GPU), PoseBusters, ProLIF, figuras del embudo.
**Entregables:** `03_estructura_docking/ranking_docking.csv`, poses `.sdf`, `Figura3.svg`, informe de validación estructural (pLDDT del sitio, ProSA, MolProbity).
**Compuerta 3 (decisión de la MD única):** se elige **UN** complejo para dinámica. Criterio explícito y preregistrado: mejor *consensus rank* que además (i) pase PoseBusters, (ii) contacte residuos catalíticos o del bolsillo alostérico validado, (iii) sea sintéticamente/comercialmente accesible. **Escribir el criterio antes de mirar el ranking.**

### FASE 4 — Dinámica molecular única *(CHARMM-GUI + Colab GPU: Notebook 04)*
Diseño para que **una sola corrida** sobreviva a revisión:

- **Sistema:** UppP + ligando líder en bicapa de membrana interna Gram-negativa (POPE:POPG ~3:1), TIP3P, iones 0,15 M KCl, CHARMM36m; construido en **CHARMM-GUI** (web, gratis) con salida "GROMACS inputs". ~90–120 k átomos.
- **Producción:** **200 ns** del complejo. Si el presupuesto permite un segundo bloque: **100 ns de la enzima apo** (referencia imprescindible para RMSF/PCA y, además, valida el modelo AlphaFold en membrana — es un resultado en sí mismo y lo pedirá el revisor estructural).
- **Compensación del replicado ausente:** (i) análisis por **bloques independientes** (4 × 25 ns de la porción equilibrada) reportando media ± DE entre bloques; (ii) criterio de convergencia explícito (RMSD Cα en meseta, ΔRMSD entre mitades < 0,1 nm); (iii) ocupancia de puentes de H y persistencia de contactos; (iv) **PCA + paisaje de energía libre (FEL)**; (v) **DCCM / análisis de red alostérica** entre el bolsillo del ligando y el sitio catalítico → **este es el resultado "de fosfatasa" que la revista quiere ver**.
- **Energía libre:** `gmx_MMPBSA` con **modelo de membrana implícita** (`memopt`) — sin esto, MM/PBSA en sistemas de membrana es criticable; descomposición por residuo.
- **Etapas Colab:** montar Drive → instalar GROMACS con CUDA (compilar una vez y **cachear el binario en Drive**) *o* ruta alternativa OpenMM (instalación trivial, GPU inmediata) con conversión posterior para MM/PBSA → minimización/equilibrado (6 pasos de CHARMM-GUI) → producción en **trozos de 8–10 h** con `-maxh` y reinicio por checkpoint (`gmx mdrun -cpi state.cpt -noappend`), todo escrito en Drive → análisis (`gmx rms/rmsf/gyrate/sasa/hbond`, MDAnalysis, PyEMMA/scikit para PCA).
- **Decisión técnica pendiente (spike de 1 sesión):** GROMACS-compilado-en-Colab vs. OpenMM. Se resuelve al inicio de F4 con una prueba de 1 ns y medición de ns/día.
**Entregables:** `04_dinamica_molecular/` (topología, mdp, trayectoria comprimida sin agua, todos los `.xvg`), `Figura4.svg`, `mmpbsa_resultados.csv`.
**Compuerta 4:** ¿convergió? ¿el ligando permaneció en el sitio? Si se desprende, ese es el resultado y hay que decirlo (y probablemente pasar al segundo candidato en una corrida futura).

### FASE 5 — Cierre del lazo *(Colab: Notebook 05)*
**Tareas (MS):** ΔG(MM/PBSA) → Ki (ΔG = RT·ln Ki, declarando la aproximación); reinyección en el modelo de EDO como inhibición competitiva (Vmax_ef = Vmax/(1+[I]/Ki)); curvas de flujo residual de Lipid II vs. dosis; **re-ranking sistémico**; correlación docking vs. efecto sistémico (reportar el r real, sea cual sea); comparación con la inhibición equipotente de una enzima de bajo control.
**Entregables:** `05_cierre_lazo/flujo_residual.csv`, `Figura5.svg`, `Tabla2_reranking.csv`.
**Compuerta 5:** ¿la correlación es débil (soporta H2) o fuerte (refuta H2)? **Ambos resultados se publican**; si es fuerte, el mensaje cambia a "en este sistema la afinidad sí predice el efecto, y aquí está el criterio para saber cuándo".

### FASE 6 — Manuscrito, figuras y repositorio
Skill `escritor-revistas-cientificas` (normas MDPI, referencias estilo MDPI/Vancouver numerado, plantilla .docx). Redacción **en inglés**, con versión de referencia en español si se desea. Depósito: código + notebooks + SBML en GitHub → **Zenodo (DOI)**; modelo en **BioModels**. Cover letter + sugerencia de revisores + Data Availability Statement.

### FASE 7 — Auditoría final y envío
Auditoría adversarial completa (§5), corrección, chequeo anti-plagio conceptual con el propio paper de *Toxins*, envío por SuSy, y preparación anticipada de la respuesta a los tres comentarios que con más probabilidad harán (MD única, parámetros de ortólogo, MM/PBSA aproximado).

---

## 5. Acción de auditoría (ejecutable en cualquier momento)

**Comando del usuario:** `AUDITORÍA FASE N` (o `AUDITORÍA GLOBAL`).

**Qué ejecuto al recibirlo:**
1. Leo los entregables de esa fase (archivos que usted adjunte o que estén en el proyecto) + la bitácora.
2. Busco literatura de verificación en **PubMed, Consensus, Elicit, ChEMBL y web (ScienceDirect/Scopus)** — con la regla de **cero invención**: ningún DOI, PMID ni hallazgo que no venga de un resultado real; lo que no se encuentre se marca "No disponible".
3. Emito tres revisiones adversariales independientes:
   - **R1 — Biología de sistemas / modelado cinético:** parámetros, unidades, conservación de pools, ΣC^J, robustez de Sobol, uso legítimo del ACM.
   - **R2 — Estructural / MD / química computacional:** calidad del modelo, sitio de unión, PoseBusters, réplica única, convergencia, MM/PBSA en membrana, sobreinterpretación de ΔG.
   - **R3 — Microbiología de RAM + Editor:** relevancia clínica, cepa, esencialidad, encaje con el alcance de la revista, novedad frente a lo publicado, honestidad de limitaciones, calidad de figuras y de la narrativa.
4. Salida: tabla `Comentario | Severidad (Mayor/Menor) | Sección | Acción correctiva | Estado`, más una **recomendación editorial simulada** (aceptar / menor / mayor / rechazar) y la lista priorizada de arreglos.

---

## 6. Gestión de memoria, créditos y archivos

**Limitación honesta:** en este chat no tengo acceso de lectura/escritura al disco de su computadora. El flujo que sí funciona:

- Yo genero archivos → usted los descarga a `~/Claude/proyecto/UppP_KP/...` y a `~/Claude/bitacoras/`.
- Al **iniciar cada sesión nueva**, adjunte `BITACORA_MAESTRA.md` (o súbala al **conocimiento del Proyecto** en Claude, así queda disponible siempre) y los entregables de la fase en curso. Con eso recupero el estado completo.
- Trabajar **una fase por chat**. Cuando detecte que la sesión se está agotando, **paro, escribo la entrada de bitácora con el estado y el siguiente paso exacto**, y usted la guarda. Nunca dejo una fase a medias sin registro.

**Estructura de carpetas sugerida:**

```
~/Claude/proyecto/UppP_KP/
├── 00_plan/                 (este plan, presubmission, novedad)
├── 01_datos_cineticos/
├── 02_modelo_edo_acm/
├── 03_estructura_docking/
├── 04_dinamica_molecular/
├── 05_cierre_lazo/
├── 06_manuscrito/
├── 07_auditorias/
└── 99_repositorio/          (lo que va a GitHub/Zenodo)
~/Claude/bitacoras/
├── BITACORA_MAESTRA.md
└── bitacora_F<n>_AAAAMMDD.md
```

---

## 7. Cronograma realista

| Fase | Duración estimada | Cuello de botella |
|---|---|---|
| F0 | 1 semana | espera de respuesta editorial |
| F1 | 2–3 semanas | disponibilidad real de cinética en BRENDA/SABIO-RK |
| F2 | 1–2 semanas | depuración del modelo hasta ΣC^J = 1 |
| F3 | 2–3 semanas | preparación del receptor en membrana |
| F4 | 3–5 semanas | GPU de Colab: 200 ns en trozos de 8–10 h |
| F5 | 1 semana | — |
| F6 | 2–3 semanas | redacción en inglés + figuras |
| F7 | 1 semana | auditoría y correcciones |
| **Total** | **≈ 3,5–4,5 meses** | |

---

## 8. Riesgos y mitigaciones

| Riesgo | Prob. | Impacto | Mitigación |
|---|---|---|---|
| Desk rejection por alcance (no-PTM) | Media | Alto | Pre-submission inquiry (F0) + encuadre de fosfatasa + plan B a *Antibiotics* |
| Cinética real insuficiente para 5 enzimas | **Alta** | Alto | Ortólogos marcados + Sobol amplio; si falla, reformular como análisis estructural de sensibilidad |
| UppP no resulta el nodo dominante | Media | Medio | Reescribir la narrativa con el resultado real; nunca ajustar parámetros para forzar H1 |
| Revisor exige MD triplicada | **Alta** | Medio | Análisis por bloques + apo + declaración explícita; ofrecer réplicas en revisión menor si hay acceso a HPC |
| Colab corta la sesión y se pierde la MD | Alta | Alto | Checkpointing a Drive cada 30 min + `-maxh` + reinicio automatizado |
| Solapamiento con el paper de *Toxins* 2026 | Baja | Alto | Objeto de estudio distinto (moléculas pequeñas + sistemas), citación explícita, cero reutilización de figuras |
| MM/PBSA en membrana mal hecho | Media | Medio | `memopt` de gmx_MMPBSA + declarar la aproximación de Ki |

---

## 9. Compuerta 0 — decisiones que necesito de usted antes de arrancar

1. ¿Enviamos la consulta de alcance a la revista antes de invertir meses de trabajo? (recomendación: **sí**)
2. Presupuesto de GPU: ¿Colab Pro (12 h/sesión) o Pro+ (24 h)? De esto depende si la MD es 200 ns complejo + 100 ns apo, o solo 200 ns del complejo.
3. ¿Confirma reutilizar el modelo AlphaFold2 y el sitio alostérico del paper de *Toxins* 2026 como punto de partida?
