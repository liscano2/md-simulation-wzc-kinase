> **⚠️ OBSOLETO (2026-07-31).** Superado por `PLAN_v2_WzbWzc_KinasesPhosphatases.md` (blanco
> proteico: ciclo Wzb/Wzc). Se conserva como registro histórico.

# Plan de trabajo — Artículo real sobre UppP para *Kinases and Phosphatases* (MDPI)

**Proyecto:** priorización guiada por control del ciclo del transportador lipídico Und-P en *Acinetobacter baumannii*, cerrando el lazo sistemas → estructura → sistemas.
**Restricción dura del proyecto:** una sola dinámica molecular, de un solo candidato, elegido a partir del docking.
**Entorno de trabajo:** Google Colab para todo excepto la producción de DM (GPU externa), cuyos archivos se analizan de vuelta en Colab.
**Fecha del plan:** 31 de julio de 2026.

---

## 0. Diagnóstico editorial: la decisión más importante antes de calcular nada

Datos verificados hoy en la web de la revista:

| Ítem | Valor |
|---|---|
| ISSN | 2813-3757 |
| Alcance declarado | "todos los aspectos de las modificaciones postraduccionales en todos los sistemas biológicos, de bacterias a humanos", con disciplinas que incluyen bioquímica, biología estructural, química medicinal y farmacología |
| Periodicidad | Trimestral |
| APC | 1000 CHF |
| Tiempo a primera decisión | ~23,8 días (mediana, 1.er semestre 2026) |
| Aceptación → publicación | ~3,7 días |
| Indexación / cuartil | **No verificado.** Revista joven (Vol. 1 = 2023). Hay que confirmar en Scopus Sources y Scimago **antes** de decidir. Si aún no está indexada, el artículo no suma cuartil. |

### 0.1 El riesgo real: encaje de alcance (scope)

UppP es una fosfatasa, sí — pero **no es una fosfatasa de proteínas y su sustrato no es una modificación postraduccional**. Desfosforila un pirofosfato lipídico (Und-PP → Und-P). Si el manuscrito llega al editor escrito como "descubrimiento de antibacterianos contra *A. baumannii*", el desenlace más probable es **rechazo de escritorio por fuera de alcance**, no revisión por pares. Esto es lo primero que hay que resolver.

### 0.2 Estrategia de encaje (tres acciones, en orden)

1. **Reencuadrar el objeto del artículo: el ciclo fosforilación/desfosforilación del transportador lipídico.**
   El ciclo Und-P **es literalmente un ciclo de transferencia de fosfato**: se genera Und-PP en la reacción de transpeptidación/transglicosilación, una fosfatasa (UppP/BacA, EC 3.6.1.27) lo desfosforila a Und-P, y — punto clave — en varias bacterias existe además una **quinasa de undecaprenol (DgkA-like, EC 2.7.1.66)** que fosforila undecaprenol a Und-P. Es decir, hay un **par quinasa/fosfatasa operando sobre un portador lipídico**, exactamente el objeto de la revista, solo que fuera del mundo de las proteínas. El artículo deja de ser "antibacterianos" y pasa a ser: *"¿quién controla el flujo en un ciclo quinasa/fosfatasa: la quinasa o la fosfatasa?"*, con respuesta cuantitativa por Análisis de Control Metabólico (ACM) y consecuencia farmacológica.
   **A verificar en Fase 1 (crítico):** si la quinasa de undecaprenol existe y está anotada en *A. baumannii*. En Gram-positivos (*B. subtilis*, *S. aureus*) está bien documentada; en Gram-negativos su papel es discutido. Si **no** existe en *A. baumannii*, el encuadre se sostiene igual (ciclo de fosforilación/desfosforilación del portador, con la fosfatasa como único nodo de reciclaje), pero hay que decirlo explícitamente y no insinuar lo contrario.

2. **Título propuesto (orientado a la revista, no a la infectología):**
   *"The undecaprenyl-pyrophosphate phosphatase UppP is the flux-controlling node of the lipid-carrier phosphorylation cycle in* Acinetobacter baumannii*: a control-guided, closed-loop in silico framework for phosphatase inhibitor prioritization"*.

3. **Pre-submission inquiry al editorial office.** Gratis, sin compromiso y responde en días. Se envía título + abstract de ~200 palabras + una frase explícita de encaje ("phosphatase enzymology and kinase/phosphatase cycle control in bacteria"). **No empezar la Fase 2 sin esta respuesta**: si el editor dice que no encaja, ahorras meses. Ver Fase 0.

### 0.3 Revistas de respaldo (decidir el orden antes de empezar, no después del rechazo)

Si el pre-submission inquiry sale negativo, el mismo manuscrito, con el encuadre revertido a "priorización de blancos antimicrobianos", va a: *IJMS* (MDPI, Q1/Q2), *Pharmaceuticals* (MDPI), *Antibiotics* (MDPI, si se enfatiza AMR), *Computers in Biology and Medicine* (Elsevier), o *npj Systems Biology and Applications* si el ángulo de sistemas queda muy fuerte. **Verificar cuartil y APC vigentes antes de decidir.**

---

## 1. Grupo de trabajo (roles, con un líder que integra)

Cada rol es un "sombrero" con misión, insumos, entregable y criterio de calidad propio. Cuando trabajemos, invocaré el rol que corresponda y lo diré explícitamente, para que sepas desde qué criterio te estoy hablando.

| Rol | Misión | Entregable propio | Criterio de aceptación de su trabajo |
|---|---|---|---|
| **L — Líder integrador** (investigador principal) | Coherencia global: que la pregunta, los métodos, los resultados y la conclusión cuenten **una sola historia**. Decide go/no-go en cada compuerta. Es el único que puede declarar una fase cerrada. | Narrativa maestra (una página, actualizada en cada fase) y decisiones de compuerta documentadas | Ningún resultado entra al manuscrito sin trazabilidad de fuente y sin encajar en la narrativa |
| **S — Biólogo de sistemas / matemático** | Modelo de EDO del ciclo, estado estacionario, ACM, Sobol, lazo cerrado | `modelo.py` + SBML + notebook N2/N6 | ΣC^J = 1,000 ± 0,001; estado estacionario con todas las velocidades convergiendo al mismo J; Sobol reportado |
| **B — Bioquímico enzimólogo** | Curaduría cinética: Km, kcat, [E], unidades, condiciones (pH, T), plausibilidad fisiológica. Marca qué viene de ortólogo | Tabla de parámetros con columna *fuente* y columna *organismo real* | Cero valores sin fuente citable; unidades homogéneas; ningún kcat usado sin [E] declarada |
| **E — Bioinformático estructural** | Estructura de UppP, calidad del modelo, orientación en membrana, definición y justificación del sitio | PDB preparado + informe de validación (pLDDT local, ProSA, MolProbity) | pLDDT > 70 en los residuos del sitio; si no, se cambia de sitio o se declara |
| **Q — Químico computacional (docking)** | Biblioteca, preparación de ligandos, docking, rescoring, PoseBusters, control positivo | Tabla de poses + métricas de validación del protocolo | Control positivo recuperado; ≥1 pose por compuesto pasa PoseBusters; redocking/consenso reportado |
| **D — Científico de datos / ML** | QSAR **solo si hay datos que lo sostengan**, estadística, figuras, reproducibilidad | Notebooks limpios + figuras vectoriales | Nada de AUC sobre datos que no correspondan al blanco; si no hay datos, se elimina el módulo, no se maquilla |
| **M — Especialista en dinámica molecular** | Sistema de simulación, producción, convergencia, energía libre en entorno de membrana | Trayectoria + análisis + ΔG con incertidumbre | RMSD estabilizado y demostrado; MM/PBSA con estimación de error explícita y con tratamiento de membrana correcto |
| **A — Auditor adversarial (Revisor 2)** | Buscar literatura y destrozar el trabajo antes que un revisor real | Informe de auditoría con veredicto y acciones obligatorias | Cada crítica con referencia real (PubMed/Consensus/Elicit/ScienceDirect) o marcada como "sin evidencia localizada" |
| **R — Editor científico** | Inglés científico, formato MDPI, referencias, back matter, carta de presentación | .docx listo para *submission* | Cumple plantilla MDPI; referencias en estilo MDPI; abreviaturas definidas una sola vez |

**Skills que se activan por rol:** `pipeline-blancos-sistema-estructura` (L, S, E, Q, M — arquitectura y compuertas de calidad) · `investigador-bases-datos-cientificas` (A — búsqueda y verificación, cero invención) · `escritor-revistas-cientificas` (R — formato MDPI y .docx final) · `creador-modelos-ia` (D — **solo si** finalmente se hace el módulo QSAR/ML, para reportarlo con rigor).

---

## 2. Fases, compuertas y qué se hace exactamente en Colab

Regla general: **no se pasa de fase sin cerrar su compuerta.** Cada compuerta se cierra con (a) el entregable técnico, (b) el visto bueno del líder integrador, y (c) donde está marcado, un informe de auditoría adversarial.

### FASE 0 — Encuadre editorial y blindaje de novedad
*Sin Colab. Es trabajo de escritorio y de auditoría.*

- **A** ejecuta la primera auditoría de novedad (protocolo en §4): ¿existe ya un modelo cinético del ciclo Und-P?, ¿alguien ya hizo ACM sobre biosíntesis de envoltura bacteriana?, ¿alguien ya publicó el encadenamiento sistemas → estructura → re-ranking por flujo?, ¿qué se publicó sobre inhibidores de BacA/UppP después de Jukič 2022?
- **L** redacta título + abstract de encaje y la nota de pre-submission inquiry.
- Verificar indexación real de la revista (Scopus/Scimago) y confirmar APC vigente.

**Compuerta 0 (auditoría + decisión editorial).** Se cierra con: respuesta del editor (o decisión consciente de arriesgar), veredicto de novedad, y revista de respaldo elegida. *Si la auditoría encuentra un modelo cinético del ciclo Und-P ya publicado, el proyecto cambia: se pasa a validar/extender ese modelo en vez de construirlo, y la novedad se reubica en el cierre del lazo.*

---

### FASE 1 — Curaduría de datos (el cuello de botella real del proyecto)
**Colab: Notebook N1 — "curaduría y trazabilidad".**

Qué se hace:
- Topología del ciclo desde KEGG/BioCyc/Rhea: MraY (2.7.8.13) → MurG (2.4.1.227) → MurJ (flipasa) → PBP (transglicosilación/transpeptidación) → **UppP (3.6.1.27)**, más UppS (2.5.1.31, síntesis *de novo*) y, si aplica, **quinasa de undecaprenol (2.7.1.66)**.
- Extracción de Km/kcat desde BRENDA y SABIO-RK, con su condición experimental y su cita. Concentraciones y abundancias desde PaxDb/ECMDB. Secuencia y anotación desde UniProt (B2HXY4 para UppP de *A. baumannii* ACICU, ya usado en tu trabajo previo).
- **Cada fila lleva:** valor, unidad original, unidad normalizada, organismo real, pH/T, fuente (DOI/ID), y bandera `ortologo = sí/no`.
- Salida: `parametros_cinetica.csv` + `parametros_cinetica.xlsx` (tabla suplementaria S1 del artículo).

**Rol:** B lidera, S valida unidades, A verifica que cada cita exista de verdad.

**Compuerta 1 — la decisión que define el artículo.** Contar cuántos parámetros son de *A. baumannii* y cuántos de ortólogo:
- **≥ 3 de 5 enzimas con datos rastreables (propios o de ortólogo cercano) →** modelo determinista clásico con Sobol de respaldo. Ruta prevista.
- **< 3 →** cambiar de estrategia y hacer **ACM de ensamble (ensemble MCA)**: en vez de un juego de parámetros, se muestrean miles de juegos plausibles y se reporta la **distribución** del coeficiente de control de cada enzima. Esto no es un plan B débil: es metodológicamente más honesto y más difícil de atacar en revisión, y convierte "no hay datos de *A. baumannii*" de debilidad en diseño. **Recomiendo decidir esto con los datos en la mano, no antes.**

---

### FASE 2 — Modelo de EDO, ACM y Sobol
**Colab: Notebook N2 — "modelo y control".** Es 100 % Colab, gratuito, minutos de CPU.

- Librerías: `scipy` (integración BDF/Radau), `tellurium`/`libroadrunner` (SBML), `SALib` (Sobol), `numpy/pandas/matplotlib`.
- Punto de partida: `scripts/mca_template.py` del skill `pipeline-blancos-sistema-estructura` (ya probado), reemplazando las leyes de velocidad de juguete por las reales.
- Michaelis–Menten reversible; **conservación explícita del pool total del transportador** (Und-P + Lipid I + Lipid II + Lipid II-out + Und-PP = constante) — sin esto, el reciclaje desaparece y el control se malinterpreta.
- FCC por perturbación ±1 % de cada Vmax. **Validación obligatoria: ΣC^J = 1.**
- Sobol de orden total, ±50 % en todos los parámetros, N ≈ 10 000.
- Exportar SBML (para depósito en BioModels) y figuras 1 y 2 del artículo.

**Compuerta 2 (auditoría técnica).** No se avanza si: ΣC^J ≠ 1; o si un solo C^J ≈ 0,99 (cuello de botella artificial: el modelo está mal planteado); o si el ranking se voltea bajo Sobol. Resultado esperable y creíble: control **distribuido pero dominado** por la fosfatasa. **Y si el resultado es que UppP *no* domina — se reporta igual.** Un ACM que contradice la intuición es publicable; un ACM amañado es fraude y además se detecta.

---

### FASE 3 — Preparación estructural del blanco
**Colab: Notebook N3 — "estructura y sitio"** + herramientas web (CHARMM-GUI, OPM/PDBTM, ProSA, MolProbity) fuera de Colab.

- Coordenadas: AlphaFold DB para UppP de *A. baumannii* (B2HXY4). Usar como referencia estructural las estructuras experimentales publicadas de UppP de *E. coli* y del homólogo BacA para **superposición y validación del plegamiento y de los motivos conservados** (esto responde por adelantado al revisor que pregunte "¿por qué confiar en un modelo predicho?").
- Validación: pLDDT **por residuo en el sitio de unión** (no solo el promedio global), ProSA-web, MolProbity.
- Protonación a pH 7,4; orientación en membrana con OPM/PDBTM; bicapa con CHARMM-GUI (composición tipo membrana interna de Gram-negativo: POPE/POPG/cardiolipina).
- Definición del sitio: catalítico (motivos conservados, residuos tipo Glu/Arg descritos para BacA) **y/o** el bolsillo alostérico ya validado en tu artículo de *Toxins* 2026. Documentar el criterio: es una decisión que el revisor va a mirar.

**Compuerta 3.** Se cierra con el informe de validación estructural y el sitio definido y justificado por escrito. Si el pLDDT local en el sitio es bajo, se cambia el sitio o se declara la limitación antes de gastar docking.

---

### FASE 4 — Biblioteca, docking y selección del candidato único
**Colab: Notebook N4 — "cribado".** Vina corre bien en Colab; GNINA necesita GPU (usar el runtime T4).

- **Tamaño realista de biblioteca: 2.000–10.000 compuestos, no 48.000.** Con una sola persona y Colab, una biblioteca enfocada y bien justificada vale más que una grande y superficial. Composición sugerida:
  - COCONUT (productos naturales, tu línea previa),
  - DrugBank (reposicionamiento — argumento traslacional barato y atractivo),
  - análogos del *Compound 4* de Jukič (2022) por similitud, que es tu **control positivo**,
  - bacitracina como **referencia mecanística** (aunque actúe secuestrando el sustrato, no inhibiendo la enzima — decirlo así, no como inhibidor directo).
- Preparación: RDKit (enumeración de protonación/tautómeros), `meeko`/`obabel`.
- Docking: AutoDock Vina para volumen → rescoring de los mejores con GNINA → **PoseBusters obligatorio**.
- **Validación del protocolo antes de creer en nada**: recuperar el control positivo entre los mejores rankeados; reportar el enriquecimiento. Si el protocolo no recupera el control, el protocolo está mal, no la biblioteca.

**Compuerta 4 — selección del único candidato para DM. Aquí paramos y decidimos juntos.**
Criterios de selección, en este orden: (1) pasa PoseBusters; (2) buen score en Vina **y** en GNINA (consenso, no un solo scoring); (3) contactos con residuos conservados del sitio, no con la periferia; (4) plausibilidad química (sin PAINS, sin grupos imposibles, con ruta sintética o disponibilidad comercial); (5) que el compuesto **tenga una historia que contar** en la narrativa (p. ej. producto natural, o fármaco reposicionable).

**Decisión adicional en esta compuerta: ¿QSAR/ML sí o no?**
Ojo con esto: es muy probable que ChEMBL **no tenga suficientes datos de bioactividad medida contra UppP/BacA** para entrenar un clasificador honesto. Entrenar sobre otro blanco y presentarlo como QSAR de UppP es exactamente el tipo de cosa que hunde un manuscrito en revisión. Opciones, en orden de preferencia:
1. **Eliminar el módulo QSAR** y sustituirlo por consenso de scoring + análisis de interacciones. El artículo no lo necesita: la novedad está en el lazo cerrado, no en el ML.
2. Mantenerlo **solo si** la Fase 1 encuentra un conjunto de actividad real y suficiente, y entonces reportarlo con validación externa y SHAP (aquí sí entra el skill `creador-modelos-ia`).

Menos módulos bien hechos > más módulos decorativos.

---

### FASE 5 — Dinámica molecular (la única) 
**Fuera de Colab la producción; en Colab todo el análisis (Notebook N5).**

Realidad de cómputo, sin adornos: un sistema UppP + bicapa + agua ronda 100.000–150.000 átomos. En una GPU de escritorio decente rinde ~30–60 ns/día; en una T4 de Colab, ~10–15 ns/día **y con desconexiones**. Producir 100–200 ns en Colab gratuito no es viable de forma limpia.

**Recomendación de diseño (importante, y es una decisión de experto, no un capricho):** con presupuesto para un solo sistema, **prefiere 3 réplicas cortas (3 × 60–80 ns, semillas de velocidad distintas) antes que una sola corrida de 200 ns.** Razón: MM/PBSA sin ninguna estimación de error es la crítica número uno de los revisores en 2025–2026, y tres réplicas cortas te dan desviación estándar entre réplicas; una corrida larga solo te da bloques correlacionados. Si el hardware solo permite **una** trayectoria:
- Corre 150–200 ns, descarta los primeros 50 ns como equilibración, y estima el error por **block averaging** sobre la parte estable.
- Corre además la **proteína apo** como referencia (es barato y transforma "una simulación suelta" en "una comparación"). Sin control apo, la DM no dice casi nada.

Otros puntos que el especialista M no puede pasar por alto:
- Campo de fuerza: CHARMM36m + TIP3P; parámetros del ligando por CGenFF (y reportar el *penalty score* de la parametrización — los revisores lo piden).
- **MM/PBSA en membrana:** el MM/PBSA estándar es inválido si el sitio está inmerso en la bicapa. Hay que usar `gmx_MMPBSA` con **modelo de membrana implícita** (opción de memopt) o, si eso no converge, reportar **energías de interacción MM y descomposición por residuo** en vez de un ΔG absoluto. Decir cuál se usó y por qué.
- Métricas: RMSD de Cα (convergencia), RMSF por residuo, Rg, SASA, puentes de H y mapa de contactos del sitio, ocupancia del ligando en el bolsillo a lo largo del tiempo.

**En Colab (N5):** `MDAnalysis`/`MDTraj` para RMSD, RMSF, Rg, SASA, contactos y puentes de H; `matplotlib` para figuras. Se suben solo `.xtc` recortado + `.tpr`/`.gro` (comprime la trayectoria: guarda cada 100 ps y solo los átomos que necesitas — así el archivo cabe en Drive sin dolor).

**Compuerta 5.** Se cierra si y solo si: RMSD estabilizado y demostrado gráficamente, ligando dentro del sitio al final de la corrida, y ΔG (o energía de interacción) con incertidumbre explícita. Si el ligando se sale del bolsillo, **ese es el resultado** y hay que reportarlo: obliga a revisar el candidato o el sitio, y es información real.

---

### FASE 6 — Cierre del lazo (el diferenciador del artículo)
**Colab: Notebook N6 — "afinidad → efecto sistémico".**

- ΔG → Ki (ΔG = RT ln Ki). **No uses un valor puntual:** MM/PBSA sobreestima afinidades absolutas de forma conocida. Propaga una **banda de Ki** (p. ej. ±1–2 unidades logarítmicas) y muestra que la conclusión cualitativa — inhibir el nodo de alto control colapsa el flujo antes — **se sostiene en toda la banda**. Esto blinda el resultado contra la crítica obvia.
- Reinyectar como inhibición competitiva: Vmax_efectivo = Vmax / (1 + [I]/Ki).
- Curvas de flujo residual de Lipid II vs. [I], comparando inhibición equipotente de la fosfatasa frente a enzimas de bajo control (y frente a la quinasa, si entró al modelo — ese contraste es *el* gráfico de la revista).
- Correlación docking vs. efecto sistémico. **Advertencia honesta:** con un solo candidato con DM no puedes reportar una correlación robusta sobre 4-5 puntos. Alternativas legítimas: (a) usar los ΔG de docking/rescoring de los N mejores del cribado (no de DM) para la correlación, declarando la aproximación; (b) presentar el re-ranking como **demostración conceptual con un caso trabajado en profundidad**, no como estadística. La segunda es más defendible con tus recursos.

**Compuerta 6.** Cierra con las figuras finales y con la narrativa maestra actualizada. Aquí el líder integrador comprueba que la conclusión escrita no exceda lo que los datos aguantan.

---

### FASE 7 — Manuscrito, reproducibilidad y auditoría final
- Repositorio público (GitHub) con notebooks, modelo SBML, tablas de parámetros; archivado en Zenodo con DOI. Depósito del modelo en BioModels.
- Redacción en inglés, formato MDPI (skill `escritor-revistas-cientificas`, salida .docx, texto en tinta negra, referencias en estilo MDPI).
- **Auditoría adversarial completa** (§4), simulando tres revisores: uno de biología de sistemas, uno de química computacional, uno de bioquímica de envoltura bacteriana.
- Carta de presentación que explique en dos frases por qué el artículo pertenece a *esta* revista.
- Checklist final: ORCID, contribuciones, financiación, ética (no aplica), disponibilidad de datos, conflictos de interés.

---

## 3. Resumen: qué vive en Colab y qué no

| Notebook | Fase | Qué hace | Librerías clave | Coste |
|---|---|---|---|---|
| N1 | 1 | Curaduría y trazabilidad de parámetros | pandas, openpyxl, requests (APIs UniProt/KEGG) | minutos, CPU |
| N2 | 2 | EDO + estado estacionario + FCC + Sobol + SBML | scipy, tellurium, SALib | minutos–1 h, CPU |
| N3 | 3 | Preparación estructural y análisis del modelo | biopython, pdbfixer, py3Dmol | minutos, CPU (CHARMM-GUI y OPM son web) |
| N4 | 4 | Preparación de ligandos, docking, PoseBusters, rescoring | rdkit, meeko, vina, posebusters, gnina (GPU) | horas, CPU/GPU |
| N5 | 5 | Análisis de la trayectoria de DM | MDAnalysis, MDTraj, matplotlib | 1–2 h, CPU |
| N6 | 6 | Lazo cerrado: ΔG → Ki → flujo residual → re-ranking | scipy, tellurium, matplotlib | minutos, CPU |

**Fuera de Colab:** producción de GROMACS (GPU propia, cluster institucional o Colab Pro con reinicio desde checkpoint cada ~4 h), CHARMM-GUI, OPM/PDBTM, ProSA-web, MolProbity, BRENDA/SABIO-RK (consulta manual).

---

## 4. Protocolo de la acción de auditoría (Revisor 2 interno)

Se ejecuta en las compuertas 0, 2, 4 y 7 (y en cualquier momento que lo pidas). Funciona así:

1. **Lectura del estado del proyecto**: el auditor lee lo que exista (notebooks, resultados, borrador) y la narrativa maestra.
2. **Búsqueda de literatura real** con el skill `investigador-bases-datos-cientificas`: PubMed y Consensus como base; Elicit para preguntas de síntesis; ChEMBL cuando haya compuestos; búsqueda web dirigida a ScienceDirect/editoriales para lo que no esté indexado. **Regla no negociable: cero invención.** Ningún DOI, PMID, autor, año o hallazgo que no venga literalmente de un resultado de búsqueda. Lo que no se encuentre se reporta como "sin evidencia localizada".
3. **Crítica por rúbrica**, sección por sección, con severidad de revisor estricto:

| Eje | Preguntas que dispara |
|---|---|
| Encaje con la revista | ¿Un editor de una revista de quinasas y fosfatasas ve aquí su tema, o ve un artículo de antibióticos disfrazado? |
| Novedad | ¿Alguien publicó ya este modelo, este ACM, este cierre de lazo? ¿Sigue siendo cierto hoy lo que verificamos al inicio? |
| Rigor del modelo | ΣC^J, Sobol, conservación de pools, unidades, uso de parámetros de ortólogo |
| Rigor estructural | Calidad del modelo en el sitio, justificación del sitio, control positivo, PoseBusters, docking en membrana |
| Rigor de DM | Convergencia, réplicas o block averaging, control apo, tratamiento de membrana en MM/PBSA, parametrización del ligando |
| Sobreinterpretación | ¿Alguna frase afirma más de lo que el dato sostiene? ¿Aparece "demuestra" donde debería decir "sugiere"? |
| Reproducibilidad | ¿Un tercero puede reproducirlo con lo publicado? |
| Limitaciones | ¿Están declaradas las incómodas, o solo las cómodas? |

4. **Salida del auditor**: tabla de referencias consultadas (autor/año, revista y cuartil, hallazgo parafraseado) → críticas numeradas y priorizadas (**Bloqueante / Mayor / Menor**) → veredicto simulado (rechazo / revisión mayor / revisión menor / aceptar) → lista de acciones concretas.
5. **Regla de cierre:** ninguna crítica *bloqueante* queda abierta al pasar de fase. Las *mayores* se resuelven o se convierten en limitación declarada por escrito.

---

## 5. Riesgos principales y mitigación

| Riesgo | Probabilidad | Mitigación |
|---|---|---|
| Rechazo de escritorio por alcance | **Alta** si no se reencuadra | Encuadre de ciclo quinasa/fosfatasa + pre-submission inquiry (Fase 0) |
| No hay cinética de *A. baumannii* | Alta | ACM de ensamble + Sobol; declarar ortólogos con bandera explícita |
| ChEMBL sin datos para QSAR de UppP | Alta | Eliminar el módulo ML en vez de fabricarlo |
| Una sola DM = crítica de robustez | Alta | 3 réplicas cortas si se puede; si no, block averaging + control apo + limitación declarada |
| MM/PBSA inválido en membrana | Media–alta | Membrana implícita en gmx_MMPBSA, o reportar energías de interacción y descomposición por residuo |
| Alguien ya publicó el modelo del ciclo | Media | Auditoría de Fase 0 antes de invertir; si ocurre, pivotar a validar/extender ese modelo |
| El ACM no da a UppP como dominante | Media | Se publica igual: el hallazgo negativo con método sólido es publicable; la narrativa se reescribe, no el número |
| Revista sin indexar → no suma cuartil | Media | Verificar Scopus/Scimago **antes** de pagar 1000 CHF; tener revista de respaldo decidida |

---

## 6. Cómo trabajamos entre sesiones (manejo de créditos)

Voy a parar y avisarte **al cierre de cada fase**, y también si veo que una tarea larga no cabe en lo que queda de sesión — prefiero cortar limpio en una compuerta que dejar un notebook a medias.

Para retomar sin perder contexto, al abrir una sesión nueva pégame estas cuatro líneas:

```
Proyecto: UppP / Kinases and Phosphatases
Fase cerrada: ___ (compuerta ___ cerrada el ___)
Fase actual: ___
Pendiente inmediato: ___
```

Todo entregable se guarda en el repositorio del proyecto, y la **narrativa maestra** (una página, mantenida por el líder integrador) es el documento que se relee al iniciar cada fase.

---

## 7. Siguiente paso concreto

**Fase 0, acción de auditoría.** Antes de escribir una línea de código: verificar novedad en la literatura y verificar la indexación de la revista. Con eso en la mano decidimos si el pre-submission inquiry sale con el encuadre de ciclo quinasa/fosfatasa o si cambiamos de revista desde ya.
