# PROTOCOLO DE AUDITORÍA ADVERSARIAL — Proyecto UppP

**Activación:** el usuario escribe `AUDITORÍA FASE N` o `AUDITORÍA GLOBAL` y adjunta los entregables de la fase + la bitácora.

## Regla no negociable: cero invención
Ninguna cita, DOI, PMID, valor cinético o afirmación de la literatura puede aparecer si no proviene de un resultado real de búsqueda (PubMed / Consensus / Elicit / ChEMBL / web) o del `fetch` de la fuente. Lo que no se encuentre se marca **"No disponible"**. Se parafrasea siempre; nunca se copian frases textuales largas.

## Procedimiento (4 pasos)

**1. Lectura del estado.** Entregables de la fase + bitácora + plan maestro. Se identifica qué afirmaciones son *datos*, cuáles son *inferencias* y cuáles son *supuestos heredados* del borrador ilustrativo (estos últimos son sospechosos por defecto).

**2. Verificación bibliográfica.** Búsquedas dirigidas a las afirmaciones que sostienen la narrativa, no a "el tema en general". Bases: PubMed (biomédico), Consensus (consenso entre estudios), Elicit (extracción metodológica), ChEMBL (bioactividad del blanco), ScienceDirect/Scopus vía web. Prioridad a Q1–Q3 de los últimos 10 años; si se amplía el rango, se declara.

**3. Tres revisiones independientes.** Cada una escribe *sin ver* a las otras y sin cortesía editorial:

- **R1 — Biología de sistemas y modelado cinético.** Checklist: ¿unidades homogéneas? ¿[E] conocida o Vmax asumido? ¿conservación del pool impuesta? ¿ΣC^J = 1 reportado? ¿Sobol sobre el rango declarado? ¿los valores de ortólogo están marcados uno por uno? ¿el ACM se usa donde tiene sentido o se fuerza? ¿el SBML reproduce el resultado?
- **R2 — Estructural, docking y dinámica molecular.** Checklist: ¿pLDDT local del sitio, no solo el promedio? ¿comparación con la estructura experimental del homólogo? ¿protonación justificada? ¿PoseBusters aplicado y reportado? ¿control positivo y señuelos? ¿la MD converge y con qué criterio? ¿réplica única declarada como limitación? ¿MM/PBSA con membrana implícita? ¿se sobreinterpreta el ΔG como afinidad absoluta? ¿la red alostérica se sostiene con el muestreo disponible?
- **R3 — Microbiología de RAM y decisión editorial.** Checklist: ¿la cepa y su relevancia clínica están justificadas? ¿la esencialidad de UppP en *A. baumannii* está respaldada con cita verificada o se extrapola de *E. coli*? ¿la novedad resiste frente a lo publicado en 2024–2026? ¿el trabajo encaja en el alcance de la revista? ¿las limitaciones están declaradas o escondidas? ¿las figuras se entienden sin leer el texto? ¿el título promete más de lo que el artículo entrega?

**4. Salida.**

| # | Revisor | Comentario | Severidad | Sección afectada | Acción correctiva | Estado |
|---|---|---|---|---|---|---|

Más: **recomendación editorial simulada** (Aceptar / Revisión menor / Revisión mayor / Rechazar) con una frase de justificación, y la **lista priorizada de arreglos** (lo que hay que corregir antes de pasar de fase).

## Los tres comentarios que casi seguro llegarán en revisión real
Preparar la respuesta desde ahora, no en la carta de respuesta:
1. *"Una sola réplica de MD no permite conclusiones estadísticas."* → análisis por bloques, criterio de convergencia, apo como referencia, declaración explícita, y oferta de réplicas si el editor las exige.
2. *"Los parámetros cinéticos son de organismos ortólogos."* → tabla de trazabilidad con flag por fila + Sobol global mostrando que el ranking del nodo de control sobrevive a ±50 % de incertidumbre.
3. *"El Ki derivado de MM/PBSA es aproximado."* → se declara como aproximación de orden de magnitud; el argumento del artículo no depende del valor absoluto sino del **reordenamiento relativo** de candidatos.
