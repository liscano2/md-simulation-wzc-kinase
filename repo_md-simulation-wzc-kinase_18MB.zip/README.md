# Wzb/Wzc phosphorylation cycle in *Acinetobacter baumannii*: data, code and coordinates

Supporting material for the manuscript *ATP-Site-Directed Inhibition of the Wzc Tyrosine Kinase in
the Wzb/Wzc Phosphorylation Cycle of Acinetobacter baumannii* (submitted to *Kinases and
Phosphatases*).

This repository holds the inputs, intermediate files, coordinates and scripts behind every figure
and table of the article, so that each one can be traced back to the file it came from and
regenerated.

---

## How to read this repository

Folders follow the order in which the work was done. The complete record of what was done, when,
and why is in `00_bitacora/BITACORA_MAESTRA.md`, including the errors found during the project and
how each was corrected.

| Folder | Contents |
|---|---|
| `00_bitacora/` | Project log and the adversarial-audit protocol used at each phase |
| `01_plan/` | Study plan |
| `02_fase1_curaduria/` | Systematic identification of kinetic, structural and pharmacological parameters; PRISMA counts and extraction tables |
| `03_fase2_modelo/` | Kinetic model of the Wzb/Wzc cycle, control analysis and sensitivity |
| `04_fase3_estructura/` | AlphaFold3 model of Wzc, the 3LA6 template, and the superposition |
| `05_fase4_docking/` | Ligand library, ADP redocking controls, receptor files and docking results |
| `06_fase5_dinamica_molecular/` | GROMACS system, run parameters, run script and trajectory-analysis notebook |
| `07_fase6_cierre_lazo/` | Closing notes |
| `08_fase7_manuscrito/` | Figures, supplementary tables and manuscript drafts |
| `scripts_figuras/` | Verification and figure-generation scripts added for the revised version |

---

## Where each figure and table comes from

| Item in the article | Produced by | From |
|---|---|---|
| Figure 1 (PRISMA) | `02_fase1_curaduria/revision_sistematica/generar_prisma.py` | `_conteo_prisma.py`, `tabla_extraccion.csv` |
| Figure 2 (breakpoint) | `03_fase2_modelo/notebooks/N2_modelo_ciclo_WzbWzc.ipynb` | Table 1 parameters |
| Figure 3 (model confidence) | `04_fase3_estructura/notebooks/` | `AF3_Wzc_fulllength_raw/` (pLDDT, PAE) |
| Figure 4A (superposition) | `08_fase7_manuscrito/.../figuras/render_figura4.pml` (PyMOL) | `3LA6.pdb`, `AF3_Abaumannii_superpuesto_a_3LA6.pdb` |
| Figure 4B (pocket inset) | `scripts_figuras/make_figure4_inset.py` | same two coordinate files |
| Figure 5 (chemical space) | `05_fase4_docking/notebooks/N4b_propiedades_seleccion.ipynb` | `biblioteca_con_adme.csv` |
| Figure 6 (docking results) | `05_fase4_docking/notebooks/` | `top10_completo.csv`, `resultados_docking_final/` |
| Figures 7 and 8, Figure S1 | `06_fase5_dinamica_molecular/N6_analisis_MD_v2_auditado.ipynb` | trajectory and energy series |
| Table 1 | `02_fase1_curaduria/tablas/tabla_S1_curaduria.csv` | cited sources, traced row by row |
| Table 2 | `05_fase4_docking/resultados_docking_final/top10_completo.csv` | docking runs |
| Tables 3–6 | `06_fase5_dinamica_molecular/N6_analisis_MD_v2_auditado.ipynb` | trajectory |
| Tables S1–S6 | `08_fase7_manuscrito/.../tablas_suplementarias_ingles/` | as listed in each file |

### Verification scripts

`scripts_figuras/verify_ligand_identity.py` compares the molecular graph of a ligand in a
coordinate file (heavy atoms: elements plus connectivity) against a reference structure built from
its SMILES, and reports whether the two graphs are isomorphic. Molecular depictions in the article
were checked with it before rendering.

```
python scripts_figuras/verify_ligand_identity.py <archivo.pdb> <resname> ADP
```

`scripts_figuras/make_figure4_inset.py` builds the ADP-binding-pocket inset of Figure 4 from the
coordinates. Residue names and numbers are read from the PDB records, contacts are computed
geometrically, and the ligand connectivity is checked against ADP before anything is drawn. It also
writes the contact list that backs the figure.

```
python scripts_figuras/make_figure4_inset.py \
    04_fase3_estructura/modelos/3LA6.pdb \
    04_fase3_estructura/modelos/AF3_Abaumannii_superpuesto_a_3LA6.pdb \
    Figure4B_pocket_inset
```

---

## Notes on the files

**Compressed files.** The AlphaFold3 paired multiple-sequence alignment is stored gzipped
(`msas/*.a3m.gz`) because the original exceeds the per-file limit of the GitHub web uploader.
Decompress with `gunzip` before use.

**Distances in the Figure 4 inset.** The A. baumannii model is rigidly superposed on the 3LA6
crystal and was not energy-minimised against the crystal ADP. Most N/O pairs fall in the normal
hydrogen-bond range and are drawn as such; a small number fall below 2.4 Å and are marked
separately as superposition overlaps rather than as contacts.

**Residue numbering.** Positions refer to the full-length A. baumannii Wzc sequence. The modelled
kinase domain spans residues 451–700.

---

**Files not included.** To keep the deposit small, the MD trajectory (`.xtc`), run-time binaries,
the unpaired AlphaFold3 alignment, four of the five AlphaFold3 `full_data` JSON files (seeds 1–4; seed 0 is included), and the Word
drafts of the manuscript are not part of this repository. The trajectory and topology files are
available from the corresponding authors on request.

## Licence

Code is released under the MIT licence (`LICENSE`). Data and coordinate files are released under
CC BY 4.0. Third-party files keep their original terms: PDB 3LA6 is from the RCSB Protein Data
Bank, and the compound library derives from ChEMBL and COCONUT, each under its own licence.

## Citation

See `CITATION.cff`.
