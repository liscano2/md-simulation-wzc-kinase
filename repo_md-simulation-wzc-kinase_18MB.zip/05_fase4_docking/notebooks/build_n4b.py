import nbformat as nbf

nb = nbf.v4.new_notebook()
cells = []

def md(text): cells.append(nbf.v4.new_markdown_cell(text))
def code(text): cells.append(nbf.v4.new_code_cell(text))

md("""# N4b — Propiedades fisicoquímicas (SwissADME local) y selección de representantes
### Fase 4, sobre `biblioteca_final.csv` (2.346 compuestos: 2.322 COCONUT + 24 ChEMBL)

**Sobre SwissADME real (swissadme.ch):** no tiene API pública -- es un formulario web
(sketcher + campo de SMILES + botón "Run"). Hay reportes reales de usuarios bloqueados por
"demasiados cálculos" al enviar lotes grandes. Con 2.346 compuestos, intentar automatizarlo
fallaría o sería mal uso de un servicio académico gratuito no pensado para eso.

**Lo que sí se hace aquí:** las 5 reglas de drug-likeness que SwissADME reporta (Lipinski,
Ghose, Veber, Egan, Muegge) son fórmulas matemáticas públicas y bien documentadas -- se calculan
localmente con RDKit, sin depender de ningún servidor, sin límite de compuestos.

**Recomendación para el final del proyecto:** una vez el docking dé un ranking de los mejores
candidatos (unos pocos, no miles), esos sí súbelos manualmente a swissadme.ch -- ahí obtienes el
perfil completo (BOILED-Egg, inhibición de CYP, accesibilidad sintética) que va más allá de las
5 reglas, y es exactamente la escala para la que esa herramienta está pensada.
""")

code("""!pip install rdkit scikit-learn matplotlib pandas -q
import pandas as pd, numpy as np
from rdkit import Chem
from rdkit.Chem import Descriptors, Crippen, rdMolDescriptors
""")

md("## 1. Cargar la biblioteca real de N4")

code("""df = pd.read_csv("biblioteca_final.csv")
print(f"Compuestos cargados: {len(df)}")
print(df["fuente"].value_counts())
""")

md("""## 2. Las 5 reglas de drug-likeness (mismas que SwissADME), calculadas localmente

Fórmulas verificadas contra la documentación pública de cada regla (Lipinski 1997, Ghose 1999,
Veber 2002, Egan 2000, Muegge 2001) -- no se adivinaron.
""")

code('''def reglas_druglikeness(smiles):
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return pd.Series({"lipinski_ok": None, "ghose_ok": None, "veber_ok": None,
                           "egan_ok": None, "muegge_ok": None, "n_reglas_pasa": None,
                           "tpsa": None, "mr": None})

    mw = Descriptors.MolWt(mol)
    logp = Crippen.MolLogP(mol)
    hbd = Descriptors.NumHDonors(mol)
    hba = Descriptors.NumHAcceptors(mol)
    tpsa = Descriptors.TPSA(mol)
    rotb = Descriptors.NumRotatableBonds(mol)
    mr = Crippen.MolMR(mol)
    n_atoms = mol.GetNumHeavyAtoms()
    n_rings = rdMolDescriptors.CalcNumRings(mol)
    n_carbon = sum(1 for a in mol.GetAtoms() if a.GetSymbol() == "C")

    # Lipinski (Rule of Five): permite 1 violación
    viol_lip = sum([mw > 500, logp > 5, hbd > 5, hba > 10])
    lipinski_ok = viol_lip <= 1

    # Ghose
    ghose_ok = (160 <= mw <= 480) and (-0.4 <= logp <= 5.6) and (40 <= mr <= 130) and (20 <= n_atoms <= 70)

    # Veber
    veber_ok = (rotb <= 10) and (tpsa <= 140)

    # Egan
    egan_ok = (logp <= 5.88) and (tpsa <= 131.6)

    # Muegge
    muegge_ok = (200 <= mw <= 600) and (-2 <= logp <= 5) and (tpsa <= 150) and (n_rings <= 7) and \\
                (n_carbon > 4) and (hba <= 10) and (hbd <= 5) and (rotb <= 15)

    n_pasa = sum([lipinski_ok, ghose_ok, veber_ok, egan_ok, muegge_ok])
    return pd.Series({"lipinski_ok": lipinski_ok, "ghose_ok": ghose_ok, "veber_ok": veber_ok,
                       "egan_ok": egan_ok, "muegge_ok": muegge_ok, "n_reglas_pasa": n_pasa,
                       "tpsa": tpsa, "mr": mr})

print("Calculando las 5 reglas para cada compuesto (puede tardar 1-2 min sobre miles)...")
resultado = df["smiles_canonico"].apply(reglas_druglikeness)
df = pd.concat([df, resultado], axis=1)

print("\\nCuántas de las 5 reglas pasa cada compuesto:")
print(df["n_reglas_pasa"].value_counts().sort_index())
print(f"\\nPasan 5/5: {(df['n_reglas_pasa']==5).sum()}  |  Pasan >=4/5: {(df['n_reglas_pasa']>=4).sum()}")

df.to_csv("biblioteca_con_adme.csv", index=False)
print("\\nGuardado: biblioteca_con_adme.csv")
''')

md("""## 3. Espacio químico: PCA + K-means, mismo enfoque que ya usaste en el proyecto de *Elizabethkingia*

Se calcula el codo real sobre nuestros propios datos, no se asume el mismo k del otro proyecto.
""")

code("""from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt

df_candidatos = df[df["n_reglas_pasa"] >= 4].copy().reset_index(drop=True)
print(f"Candidatos para clustering (>=4/5 reglas): {len(df_candidatos)}")

descriptores = df_candidatos[["mw", "logp", "hbd", "hba", "tpsa", "rotb"]].dropna()
df_candidatos = df_candidatos.loc[descriptores.index].reset_index(drop=True)
descriptores = descriptores.reset_index(drop=True)

X = StandardScaler().fit_transform(descriptores)

wcss = []
rango_k = range(2, 21)
for k in rango_k:
    km = KMeans(n_clusters=k, random_state=42, n_init=10)
    km.fit(X)
    wcss.append(km.inertia_)

def encontrar_codo(rango_k, wcss):
    puntos = np.array(list(zip(rango_k, wcss)))
    inicio, fin = puntos[0], puntos[-1]
    linea = fin - inicio
    linea_norm = linea / np.linalg.norm(linea)
    distancias = [np.linalg.norm((p-inicio) - np.dot(p-inicio, linea_norm)*linea_norm) for p in puntos]
    return list(rango_k)[np.argmax(distancias)]

k_codo = encontrar_codo(list(rango_k), wcss)
print(f"Codo matemático: k={k_codo} (referencia; el k práctico para diversidad de cribado se fija abajo)")

fig, ax = plt.subplots(figsize=(6,4))
ax.plot(list(rango_k), wcss, "o-")
ax.axvline(k_codo, color="red", linestyle="--", label=f"Codo (k={k_codo})")
ax.set_xlabel("k"); ax.set_ylabel("WCSS (inercia)")
ax.set_title("Método del codo -- datos reales de este proyecto")
ax.legend()
plt.tight_layout()
plt.savefig("metodo_codo.png", dpi=150)
print("Figura guardada: metodo_codo.png")
""")

code('''# k PRÁCTICO -- mismo valor de referencia que en tu proyecto anterior (k=50), ajustable.
# No es el codo matemático (que suele ser bajo): es una decisión de cuánta diversidad
# química se quiere cubrir en el cribado, sopesada contra el costo de dockear cada uno.
K_PRACTICO = 50

pca = PCA(n_components=2, random_state=42)
X_pca = pca.fit_transform(X)
print(f"Varianza explicada: PC1={pca.explained_variance_ratio_[0]*100:.1f}%, "
      f"PC2={pca.explained_variance_ratio_[1]*100:.1f}% "
      f"(total: {sum(pca.explained_variance_ratio_)*100:.1f}%)")

km = KMeans(n_clusters=K_PRACTICO, random_state=42, n_init=10)
clusters = km.fit_predict(X)
df_candidatos["cluster"] = clusters

# Representante = compuesto REAL más cercano al centroide (no el centroide matemático)
representantes = []
for c in range(K_PRACTICO):
    idx_cluster = np.where(clusters == c)[0]
    centroide = km.cluster_centers_[c]
    distancias = np.linalg.norm(X[idx_cluster] - centroide, axis=1)
    representantes.append(idx_cluster[np.argmin(distancias)])

df_representantes = df_candidatos.iloc[representantes].copy()
print(f"\\nRepresentantes seleccionados: {len(df_representantes)}")
print(df_representantes["fuente"].value_counts())

fig, ax = plt.subplots(figsize=(8,6))
ax.scatter(X_pca[:,0], X_pca[:,1], c=clusters, cmap="tab20", s=12, alpha=0.5)
ax.scatter(X_pca[representantes,0], X_pca[representantes,1], marker="*", s=200,
           c="gold", edgecolor="black", linewidth=0.8, label=f"Representantes (n={K_PRACTICO})")
ax.set_xlabel(f"PC1 ({pca.explained_variance_ratio_[0]*100:.1f}% varianza)")
ax.set_ylabel(f"PC2 ({pca.explained_variance_ratio_[1]*100:.1f}% varianza)")
ax.set_title("Espacio químico de candidatos -- representantes seleccionados")
ax.legend()
plt.tight_layout()
plt.savefig("espacio_quimico_representantes.png", dpi=150)
print("Figura guardada: espacio_quimico_representantes.png")

df_representantes.to_csv("representantes_para_docking.csv", index=False)
''')

md("""## 4. AVISO IMPORTANTE: por qué NO se usa solo el resultado del paso 3

Con k=50, la selección por clustering da abrumadoramente representantes de COCONUT (el 98,7%
de los candidatos son de esa fuente, por el volumen de entrada) y prácticamente ningún ChEMBL --
justo la fuente que se armó específicamente para traer quimiotipos de inhibidor de quinasa
(sitio de ATP). Perder eso sería perder la justificación original de incluir ChEMBL.

**Solución: selección híbrida.** Se incluyen TODOS los compuestos de ChEMBL que pasan el filtro
de drug-likeness (no solo los que el clustering eligió como representantes) + los representantes
de diversidad química de COCONUT. Esto preserva ambos ángulos: diversidad de productos naturales
Y cobertura del quimiotipo de sitio de ATP.
""")

code("""chembl_candidatos = df[(df["fuente"]=="ChEMBL") & (df["n_reglas_pasa"]>=4)]
print(f"ChEMBL con >=4/5 reglas (se incluyen TODOS): {len(chembl_candidatos)}")

coconut_representantes = df_representantes[df_representantes["fuente"]=="COCONUT"]
print(f"Representantes COCONUT (diversidad, de PCA/K-means): {len(coconut_representantes)}")

df_final_hibrido = pd.concat([chembl_candidatos, coconut_representantes], ignore_index=True)
df_final_hibrido = df_final_hibrido.drop_duplicates(subset="smiles_canonico")

print(f"\\nBIBLIOTECA HÍBRIDA FINAL para docking: {len(df_final_hibrido)} compuestos")
print(df_final_hibrido["fuente"].value_counts())

df_final_hibrido.to_csv("biblioteca_hibrida_para_docking.csv", index=False)
print("\\nGuardado: biblioteca_hibrida_para_docking.csv -- este es el archivo que se usa en N5 (docking)")
""")

md("""## Pendientes / decisiones para confirmar

- [ ] **Confirmar K_PRACTICO=50** -- o ajustarlo según cuánto tiempo de docking sea razonable
      (66 compuestos totales con la selección híbrida actual es una carga de cómputo manejable
      para docking rígido con AutoDock Vina).
- [ ] Cuando el docking (N5) dé el ranking final, subir manualmente los mejores 5-10 candidatos
      a swissadme.ch para el perfil ADME completo (BOILED-Egg, CYP, síntesis) -- ahí sí tiene
      sentido usar la herramienta real, a esa escala pequeña.
- [ ] PubChem Drug-Names.tsv.gz (503 del servidor de NCBI, ver auditoría anterior) sigue sin
      poder confirmarse -- no bloquea este paso, la biblioteca ya está cerrada sin esa fuente.
""")

nb['cells'] = cells
nbf.write(nb, "N4b_propiedades_seleccion.ipynb")
print("N4b escrito.")
