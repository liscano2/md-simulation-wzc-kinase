import nbformat as nbf

nb = nbf.v4.new_notebook()
cells = []

def md(text):
    cells.append(nbf.v4.new_markdown_cell(text))

def code(text):
    cells.append(nbf.v4.new_code_cell(text))

md("""# N4 — Biblioteca de compuestos para el cribado (ChEMBL + DrugBank + COCONUT)
### Fase 4, Kinases and Phosphatases — dominio quinasa de Wzc

**Estado de la decisión metodológica (auditoría 003):** el sitio de docking ya está definido por
homología estructural (RMSD 1,72 Å / 0,72 Å validación cruzada, Fase 3) — este notebook NO busca
validar el sitio, busca construir la biblioteca de candidatos. Los puntajes de Vina se usarán para
**ranking relativo**, no como prueba de modo de unión exacto (limitación ya declarada).

**Objetivo de tamaño:** 2.000–10.000 compuestos, biblioteca enfocada, no una descarga masiva sin
criterio.

**Regla del proyecto (cero invención):** cada fuente se documenta con su ruta de acceso real. Donde
la API exacta no se pudo verificar sin ejecutar JavaScript (COCONUT), se usa la descarga masiva
confirmada en vez de adivinar endpoints.
""")

code("""!pip install chembl_webresource_client rdkit requests pandas -q
from chembl_webresource_client.new_client import new_client
from rdkit import Chem
from rdkit.Chem import Descriptors, Draw
from rdkit.Chem.FilterCatalog import FilterCatalog, FilterCatalogParams
import pandas as pd, requests, os, time

os.makedirs("biblioteca", exist_ok=True)
""")

md("""## 1. ChEMBL — inhibidores de quinasas con perfil drug-like

**Justificación de la estrategia de búsqueda:** ChEMBL casi con certeza NO tiene bioactividad
anotada contra Wzc/BY-quinasas específicamente (confirmado en la auditoría de novedad: nadie ha
publicado inhibidores de molécula pequeña contra este sitio). Por eso la búsqueda se hace por
**clase de mecanismo** (inhibidores de quinasas en general, competitivos de ATP), no por
bioactividad contra el blanco exacto -- es una biblioteca "enriquecida en quimiotipo de sitio de
ATP", no una biblioteca con actividad confirmada contra Wzc.

Se usa el cliente oficial `chembl_webresource_client` (no URLs armadas a mano) porque maneja
cambios de la API internamente y es la vía recomendada por el propio EMBL-EBI.
""")

code("""def buscar_chembl_por_mecanismo(palabra_clave, limite=3000):
    \"\"\"Busca compuestos cuyo mecanismo de acción anotado contenga la palabra clave
    (ej. 'kinase inhibitor'). Devuelve SMILES + chembl_id.\"\"\"
    mecanismo = new_client.mechanism
    resultados = mecanismo.filter(mechanism_of_action__icontains=palabra_clave)
    chembl_ids = list(set(r["molecule_chembl_id"] for r in resultados[:limite] if r.get("molecule_chembl_id")))
    print(f"'{palabra_clave}': {len(chembl_ids)} moléculas únicas encontradas")
    return chembl_ids

# Tres términos de búsqueda, cubriendo el espacio de quimiotipos de sitio de ATP
terminos = ["kinase inhibitor", "protein kinase inhibitor", "tyrosine kinase inhibitor"]
ids_chembl = set()
for termino in terminos:
    ids_chembl.update(buscar_chembl_por_mecanismo(termino))

print(f"\\nTotal ChEMBL IDs únicos (antes de traer estructuras): {len(ids_chembl)}")
""")

code("""def traer_estructuras_chembl(chembl_ids, lote=50):
    \"\"\"Trae SMILES + propiedades en lotes (la API de ChEMBL limita consultas grandes).\"\"\"
    molecula = new_client.molecule
    filas = []
    ids_lista = list(chembl_ids)
    for i in range(0, len(ids_lista), lote):
        sublote = ids_lista[i:i+lote]
        try:
            resultados = molecula.filter(molecule_chembl_id__in=sublote).only(
                ["molecule_chembl_id", "molecule_structures", "molecule_properties"])
            for r in resultados:
                estructuras = r.get("molecule_structures")
                if not estructuras or not estructuras.get("canonical_smiles"):
                    continue
                filas.append({
                    "chembl_id": r["molecule_chembl_id"],
                    "smiles": estructuras["canonical_smiles"],
                    "fuente": "ChEMBL",
                })
        except Exception as e:
            print(f"  [aviso] lote {i}-{i+lote} falló: {e}")
        if i % 500 == 0:
            print(f"  procesados {i}/{len(ids_lista)}...")
    return pd.DataFrame(filas)

df_chembl = traer_estructuras_chembl(ids_chembl)
print(f"\\nEstructuras ChEMBL recuperadas: {len(df_chembl)}")
df_chembl.to_csv("biblioteca/chembl_crudo.csv", index=False)
""")

md("""## 2. DrugBank — reposicionamiento (SIN atajos: requiere tu propia descarga)

**Realidad técnica, sin adornos:** DrugBank NO tiene una API pública de descarga masiva gratuita.
El acceso a `structures.sdf` completo requiere una cuenta académica gratuita (registro en
https://go.drugbank.com/releases/latest, uso no comercial) y descarga manual -- no hay forma de
automatizar esto sin tus credenciales. Esto no es una limitación de este notebook, es una
condición real de la fuente de datos.

**Justificación de por qué vale la pena el paso manual:** el antecedente directo de este proyecto
(Rational targeting of Wzb-Wzc interaction, 2020, PMID 32402850) usó exactamente una biblioteca de
fármacos aprobados y encontró candidatos reales (Labetalol, entre otros) contra este mismo sistema
biológico -- hay precedente concreto de que esta fuente rinde resultados aquí.

**Pasos:**
1. Ve a https://go.drugbank.com/releases/latest, crea una cuenta académica (gratis, aprobación
   en 1-2 días hábiles normalmente).
2. Descarga "All structures" (`structures.sdf`).
3. Súbelo a esta carpeta de Colab y corre la celda siguiente.

**Mientras tanto (opción abierta, sin registro):** la celda de abajo también trae el subconjunto de
fármacos aprobados por la FDA desde PubChem (totalmente abierto, sin licencia), como sustituto
parcial mientras se gestiona el acceso a DrugBank -- no es lo mismo (PubChem no tiene las mismas
anotaciones curadas de mecanismo/indicación que DrugBank), pero cubre el ángulo de "químico ya
aprobado" sin bloquear el avance.
""")

code("""# --- Opción A: si ya tienes structures.sdf de DrugBank subido ---
ruta_drugbank = "structures.sdf"  # cambia si lo nombraste distinto al subir

if os.path.exists(ruta_drugbank):
    suppl = Chem.SDMolSupplier(ruta_drugbank)
    filas = []
    for mol in suppl:
        if mol is None:
            continue
        try:
            smiles = Chem.MolToSmiles(mol)
            filas.append({"drugbank_id": mol.GetProp("DRUGBANK_ID") if mol.HasProp("DRUGBANK_ID") else "NA",
                          "smiles": smiles, "fuente": "DrugBank"})
        except Exception:
            continue
    df_drugbank = pd.DataFrame(filas)
    print(f"DrugBank: {len(df_drugbank)} estructuras cargadas desde tu archivo local.")
else:
    print("PENDIENTE: 'structures.sdf' de DrugBank no encontrado en esta carpeta.")
    print("Sigue las instrucciones de arriba, o continúa con la opción B (PubChem, abierta).")
    df_drugbank = pd.DataFrame(columns=["drugbank_id", "smiles", "fuente"])
""")

code("""# --- Opción B: PubChem, fármacos aprobados por la FDA (abierto, sin registro) ---
def traer_aprobados_pubchem(max_compuestos=1500):
    \"\"\"PubChem tiene una lista curada de compuestos con estado 'FDA Approved'.
    Se consulta vía PUG REST, con paginación para no exceder límites de la API.\"\"\"
    url = "https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/xref/RegistryID/FDA%20Approved%20Drugs/cids/JSON"
    # NOTA: si este endpoint específico cambia, PubChem también permite bajar el listado
    # curado "Drug and Medication Information" desde su portal de descargas -- verificar
    # en https://pubchem.ncbi.nlm.nih.gov/docs/downloads si esta consulta falla.
    try:
        r = requests.get(url, timeout=30)
        r.raise_for_status()
        cids = r.json()["IdentifierList"]["CID"][:max_compuestos]
    except Exception as e:
        print(f"[aviso] Consulta directa falló ({e}) -- PENDIENTE: verificar endpoint actual "
              f"de PubChem para listas de fármacos aprobados, la API pública cambia con el tiempo.")
        return pd.DataFrame(columns=["pubchem_cid", "smiles", "fuente"])

    filas = []
    for i in range(0, len(cids), 100):
        lote = cids[i:i+100]
        ids_str = ",".join(map(str, lote))
        url_smiles = f"https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/{ids_str}/property/CanonicalSMILES/JSON"
        try:
            r = requests.get(url_smiles, timeout=30)
            datos = r.json()["PropertyTable"]["Properties"]
            for d in datos:
                filas.append({"pubchem_cid": d["CID"], "smiles": d["CanonicalSMILES"], "fuente": "PubChem_FDA"})
        except Exception as e:
            print(f"  [aviso] lote {i} falló: {e}")
        time.sleep(0.3)  # respetar el límite de tasa de PubChem
    return pd.DataFrame(filas)

df_pubchem_fda = traer_aprobados_pubchem()
print(f"PubChem (fármacos aprobados, sustituto abierto): {len(df_pubchem_fda)} estructuras")
""")

md("""## 3. COCONUT — productos naturales (descarga masiva, no API adivinada)

La página de documentación de la API usa Swagger dinámico (no se pudo leer sin ejecutar
JavaScript). En vez de adivinar rutas de consulta, se usa la **descarga masiva confirmada**
(SDF/CSV, ver https://coconut.naturalproducts.net/download) y se filtra localmente -- más lento
mos pero verificable.

**PENDIENTE que debes resolver en Colab:** el enlace exacto de descarga puede cambiar entre
versiones de COCONUT. Antes de correr la celda siguiente, entra a
https://coconut.naturalproducts.net/download y copia el enlace real del archivo SDF/CSV completo
(o de un subconjunto, si ofrecen descarga filtrada) -- pégalo en `URL_COCONUT` abajo.
""")

code("""URL_COCONUT = ""  # <-- PEGAR AQUÍ el enlace real de descarga, verificado en el sitio

if URL_COCONUT:
    print("Descargando COCONUT (puede tardar varios minutos, el archivo completo es grande)...")
    r = requests.get(URL_COCONUT, stream=True, timeout=300)
    with open("biblioteca/coconut_completo.sdf", "wb") as f:
        for chunk in r.iter_content(chunk_size=8192):
            f.write(chunk)
    print("Descarga completa.")

    # Filtrar localmente por peso molecular razonable para docking (150-600 Da) y
    # submuestrear aleatoriamente si el archivo es muy grande (COCONUT tiene >700,000 entradas)
    import random
    random.seed(42)
    suppl = Chem.SDMolSupplier("biblioteca/coconut_completo.sdf")
    filas = []
    for mol in suppl:
        if mol is None:
            continue
        try:
            mw = Descriptors.MolWt(mol)
            if 150 <= mw <= 600:
                filas.append({"smiles": Chem.MolToSmiles(mol), "fuente": "COCONUT", "mw": mw})
        except Exception:
            continue
        if len(filas) >= 20000:  # tope de seguridad antes de submuestrear
            break
    df_coconut = pd.DataFrame(filas)
    if len(df_coconut) > 3000:
        df_coconut = df_coconut.sample(3000, random_state=42)
    print(f"COCONUT (filtrado por MW + submuestreo): {len(df_coconut)} estructuras")
else:
    print("PENDIENTE: pega la URL real de descarga de COCONUT antes de correr esta celda.")
    df_coconut = pd.DataFrame(columns=["smiles", "fuente", "mw"])
""")

md("""## 4. Combinar, deduplicar, filtrar por PAINS y drug-likeness

**Filtro PAINS: obligatorio, no opcional** (establecido desde el plan original). Se usa el
catálogo PAINS integrado en RDKit (FilterCatalog), sin dependencias externas.
""")

code("""# --- Combinar todas las fuentes ---
partes = [df for df in [df_chembl, df_drugbank, df_pubchem_fda, df_coconut] if len(df) > 0]
if not partes:
    raise SystemExit("PENDIENTE: ninguna fuente trajo datos todavía -- resuelve al menos una "
                      "sección (1-3) antes de continuar.")

df_todo = pd.concat(partes, ignore_index=True)
print(f"Total combinado (antes de deduplicar): {len(df_todo)}")

# --- Deduplicar por SMILES canónico real (no por string crudo) ---
def canonizar(smiles):
    mol = Chem.MolFromSmiles(smiles)
    return Chem.MolToSmiles(mol) if mol else None

df_todo["smiles_canonico"] = df_todo["smiles"].apply(canonizar)
df_todo = df_todo.dropna(subset=["smiles_canonico"])
df_todo = df_todo.drop_duplicates(subset=["smiles_canonico"])
print(f"Tras deduplicar (por estructura real, no por texto): {len(df_todo)}")
""")

code("""# --- Filtro PAINS (RDKit, catálogo integrado) ---
params = FilterCatalogParams()
params.AddCatalog(FilterCatalogParams.FilterCatalogs.PAINS)
catalogo_pains = FilterCatalog(catalogo := params)

def tiene_pains(smiles):
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return True  # si no se puede parsear, se descarta por seguridad
    return catalogo_pains.HasMatch(mol)

print("Aplicando filtro PAINS (puede tardar varios minutos sobre miles de compuestos)...")
df_todo["es_pains"] = df_todo["smiles_canonico"].apply(tiene_pains)
n_pains = df_todo["es_pains"].sum()
print(f"Compuestos descartados por PAINS: {n_pains} ({100*n_pains/len(df_todo):.1f}%)")
df_limpio = df_todo[~df_todo["es_pains"]].copy()
""")

code("""# --- Filtro de drug-likeness básico (Lipinski/Veber, con margen razonable para docking) ---
def propiedades(smiles):
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return pd.Series({"mw": None, "logp": None, "hbd": None, "hba": None, "rotb": None})
    return pd.Series({
        "mw": Descriptors.MolWt(mol),
        "logp": Descriptors.MolLogP(mol),
        "hbd": Descriptors.NumHDonors(mol),
        "hba": Descriptors.NumHAcceptors(mol),
        "rotb": Descriptors.NumRotatableBonds(mol),
    })

props = df_limpio["smiles_canonico"].apply(propiedades)
df_limpio = pd.concat([df_limpio, props], axis=1)

filtro = (
    (df_limpio["mw"].between(150, 650)) &
    (df_limpio["logp"].between(-2, 6)) &
    (df_limpio["hbd"] <= 6) &
    (df_limpio["hba"] <= 12) &
    (df_limpio["rotb"] <= 12)
)
df_final = df_limpio[filtro].copy()
print(f"Tras filtro de drug-likeness: {len(df_final)}")

# --- Tope al tamaño objetivo (2,000-10,000), submuestreo estratificado por fuente si hace falta ---
OBJETIVO_MAX = 8000
if len(df_final) > OBJETIVO_MAX:
    df_final = df_final.groupby("fuente", group_keys=False).apply(
        lambda x: x.sample(min(len(x), OBJETIVO_MAX // df_final["fuente"].nunique()), random_state=42)
    )
print(f"\\nBIBLIOTECA FINAL: {len(df_final)} compuestos")
print(df_final["fuente"].value_counts())

df_final.to_csv("biblioteca/biblioteca_final.csv", index=False)
print("\\nGuardado: biblioteca/biblioteca_final.csv")
""")

md("""## 5. Verificación de cordura: ¿el ADP/ATP y su análogo aparecen o quedan cerca en el espacio químico?

No es un requisito duro, pero es una señal útil: si la biblioteca tiene compuestos con propiedades
fisicoquímicas parecidas a nucleótidos (referencia de lo que sabemos que ocupa este sitio), hay
más probabilidad de que el cribado tenga sentido. Esto NO reemplaza el filtro de PAINS/drug-
likeness, es solo un chequeo adicional.
""")

code("""adp_smiles = "Nc1ncnc2c1ncn2[C@@H]1O[C@H](COP(=O)(O)OP(=O)(O)O)[C@@H](O)[C@H]1O"
adp_mol = Chem.MolFromSmiles(adp_smiles)
print(f"ADP -- MW: {Descriptors.MolWt(adp_mol):.1f}, LogP: {Descriptors.MolLogP(adp_mol):.2f} "
      f"(fuera del rango típico drug-like por su carácter muy polar -- normal para un nucleótido, "
      f"no se espera que la biblioteca general se parezca mucho a esto)")

print(f"\\nRango de MW de la biblioteca final: {df_final['mw'].min():.0f} - {df_final['mw'].max():.0f}")
print(f"Mediana de MW: {df_final['mw'].median():.0f}")
""")

md("""## Pendientes explícitos de este notebook (no resueltos aquí, quedan marcados)

- [ ] **DrugBank real**: requiere que hayas conseguido `structures.sdf` con tu cuenta académica.
      Sin eso, la Sección 2 corre solo con el sustituto de PubChem (abierto pero menos curado).
- [ ] **URL de descarga de COCONUT**: hay que pegarla a mano tras verificarla en el sitio -- las
      APIs y enlaces de descarga cambian de versión a versión.
- [ ] Verificar que el endpoint de PubChem para "FDA Approved Drugs" siga vigente (marcado en el
      código con manejo de error explícito si falla).
- [ ] Preparar los ligandos finales para docking (protonación, tautómeros, PDBQT) -- notebook
      siguiente (N4b), una vez la biblioteca esté cerrada.
""")

nb['cells'] = cells
nbf.write(nb, "N4_biblioteca_compuestos.ipynb")
print("N4 escrito.")
