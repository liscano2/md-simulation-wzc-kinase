# AUDITORÍA 003 — Fase 4, validación del protocolo de docking (redocking del ADP)

**Fecha:** 1 de agosto de 2026. Corrido íntegramente por Claude (Meeko + AutoDock Vina instalados
vía pip en el sandbox), sin pasar por Colab, con `3LA6.pdb` y el modelo AF3 ya subidos por el
usuario.

## 1. Qué se hizo

1. Se extrajo el dominio quinasa de *A. baumannii* (451-700) ya superpuesto a 3LA6 (RMSD 1,72 Å,
   auditoría 002) como receptor.
2. Se extrajo el ADP de la cadena A de 3LA6 en su pose cristalográfica real como ligando de
   referencia — se le asignó el orden de enlace correcto (verificado contra la fórmula real del
   ADP, C10H15N5O10P2) mientras se preservaban las coordenadas cristalográficas exactas.
3. Se preparidentificaron receptor y ligando con Meeko (PDBQT), caja de 25×25×25 Å centrada en
   el centroide real del ADP.
4. Se corrió AutoDock Vina (exhaustividad 16, 9 poses) en dos escenarios:
   - **(A) Redocking cruzado**: ligando → nuestro modelo de *A. baumannii*.
   - **(B) Redocking de control**: el mismo ligando → el receptor cristalográfico REAL de 3LA6
     (autoverificación del pipeline, no del modelo).

## 2. Resultados — honestos, sin maquillar

| Escenario | RMSD de la mejor pose vs. pose cristalográfica | Veredicto |
|---|---|---|
| **(B) Control — receptor real de 3LA6** | **0,77 Å** | Éxito claro (<2 Å) |
| **(A) Cruzado — receptor de A. baumannii (AF3, rígido)** | **4,08 Å** (mejor pose de las 9: 2,30 Å, pero no es la de mayor afinidad) | **No pasa el criterio estándar** |

## 3. Diagnóstico

El experimento de control (B) aísla la causa: **el pipeline (Meeko + Vina, preparación de
ligando, definición de caja) funciona correctamente** — con el receptor cristalográfico real,
recupera la pose nativa casi a la perfección. El problema es específico del escenario (A).

**Causa más probable:** el modelo de AlphaFold3 predijo la conformación *apo* (sin ligando) del
dominio de *A. baumannii*. El esqueleto (backbone) coincide muy bien con el cristal (RMSD 1,72 Å),
pero las cadenas laterales del bolsillo pueden estar en rotámeros distintos a los que adoptan
cuando el ADP está realmente presente — un modelo generativo no "sabe" que ahí va a unirse un
ligando. Esto es un fenómeno ampliamente documentado al hacer *cross-docking* contra estructuras
predichas por IA en vez de contra la estructura exacta que originó el ligando (*self-docking*),
que es sistemáticamente más fácil y no representa la dificultad real de un cribado prospectivo.

**Segunda causa posible, no descartada:** el docking se hizo sobre ADP **sin el ion Mg²⁺** que
normalmente coordina los fosfatos en el sitio activo real. Su ausencia puede desplazar la
electrostática de la pose óptima predicha por Vina.

## 4. Intento de corrección — cadenas laterales flexibles

Se intentó permitir flexibilidad en las cadenas laterales del bolsillo durante el docking (el
remedio estándar para este problema). **Resultado: no concluyente por limitación de recursos**,
no por un fallo del método:
- Con las 15 cadenas laterales del bolsillo flexibles simultáneamente: el proceso fue terminado
  por el sistema (sin memoria suficiente en este sandbox, 3,9 GB de RAM total).
- Con las 5 más cercanas al ADP (≤3 Å) y exhaustividad reducida: se agotó el tiempo (240 s) sin
  producir una salida utilizable.

**Esto no es un resultado negativo del método — es una limitación de recursos computacionales de
este entorno específico**, exactamente el tipo de tarea para la que Colab (con más RAM/GPU) o el
entorno de producción del usuario son más apropiados.

## 5. Bloqueantes / hallazgos

| # | Hallazgo | Severidad | Estado |
|---|---|---|---|
| 1 | Redocking rígido cruzado falla el criterio de <2 Å (da 4,08 Å) | **Mayor** | Diagnosticado, no resuelto todavía |
| 2 | Pipeline Meeko+Vina validado como correcto en sí mismo (control 0,77 Å) | — | Resuelto — descarta error metodológico propio |
| 3 | Sin Mg²⁺ en el docking del ADP | Menor-mayor | No probado en esta sesión |
| 4 | Docking flexible no completado por límite de recursos del sandbox | Mayor (bloquea validación completa) | Requiere Colab o más recursos |

## 6. Opciones para seguir (requieren decisión del usuario)

1. **Aceptar el resultado rígido con la limitación declarada explícitamente** en el manuscrito, y
   usar la posición del sitio **definida por homología estructural** (el mapeo de residuos ya
   validado con RMSD 1,72 Å, auditoría 002) como la fuente de verdad de dónde está el bolsillo —
   en vez de depender de que el redocking "redescubra" la posición por sí solo. El cribado de
   compuestos seguiría centrado en ese bolsillo definido estructuralmente.
2. **Repetir el docking flexible en Colab**, con más RAM/GPU disponible — el código ya está
   escrito y probado en su lógica (falló solo por recursos, no por diseño).
3. **Añadir Mg²⁺ explícito** a la preparación del ligando/receptor antes de repetir.
4. **Relajar brevemente el bolsillo del modelo de A. baumannii** con el ADP ya colocado en la
   pose transferida por homología (una minimización local corta, no una MD completa) antes de
   usarlo como receptor definitivo — un "ajuste inducido" ligero.

## 8. Corrida independiente del usuario (Vina local, 2026-08-01) — actualización

El usuario corrió el mismo docking rígido en su propia máquina (mismo `config.txt`, semilla
aleatoria distinta: -379403264). Resultado:

| Métrica | Valor |
|---|---|
| Afinidad de la mejor pose | -8,0 kcal/mol (consistente con nuestra corrida: -8,03) |
| **RMSD vs. pose cristalográfica real** | **5,76 Å** (peor que nuestra corrida, 4,08 Å, pero misma categoría de fallo) |

**Esto confirma de forma independiente (otra máquina, otra semilla) que el docking rígido no es
reproducible respecto a la pose cristalográfica real** — no fue un problema de una corrida
particular.

**Hallazgo nuevo y valioso, vía la tabla de interacciones (Discovery Studio Visualizer):**

| Residuo | Distancia | Tipo | ¿En el bolsillo de 18 residuos ya definido? |
|---|---|---|---|
| Glu543 (NH) | 2,41 Å | Puente H con fosfato | Sí (Walker A) |
| Lys546 (NH) | 2,28 Å | Puente H con fosfato | Sí (Walker A) |
| Ser547 | 2,44 Å | Puente H con fosfato | Sí (Walker A) |
| Gln487 | 2,06 Å | Puente H con ribosa (el más fuerte) | Sí |
| Ala672 (backbone) | 2,23 Å | Puente H | **No** |
| Ile700 (backbone) | 3,02 Å | Puente H | **No — último residuo del dominio recortado** |
| Arg673 | 4,34 Å | Pi-Alquilo | **No** |

**Interpretación:** el extremo de fosfatos del ADP sí ancla correctamente en los residuos reales
del motivo Walker A (contactos backbone-NH-fosfato, químicamente correctos para un P-loop). El
extremo de adenina, en cambio, se desplaza hacia residuos fuera del bolsillo original definido
por homología — y uno de ellos (Ile700) es exactamente el límite C-terminal de nuestro recorte
del dominio. **Esto sugiere revisar si el límite de 700 fue demasiado conservador**, aunque esa
región tenía pLDDT bajo en el modelo de AlphaFold3 (ver auditoría 002, §3) — haría falta
sopesar ambas señales antes de decidir extenderlo.

**No cambia el veredicto de la §7** (seguir necesitando docking flexible o relajación local antes
de confiar en puntajes absolutos), pero añade una pista concreta y accionable: si el docking
flexible en curso también empuja la adenina hacia la región 670-700, es una señal consistente de
que el sitio real de unión al ADP en *A. baumannii* podría ser ligeramente distinto en geometría
al de *E. coli* en esa subregión — no necesariamente un error del modelo.

## 10. Cierre de la investigación de docking flexible (2026-08-01)

**Decisión del usuario: no continuar con docking flexible.** Se documenta la causa técnica exacta
del fallo antes de cerrar esta línea, para que quede como diagnóstico y no como un fallo sin
explicación.

**Tres intentos de docking flexible, todos con causa identificada:**

| Intento | Dónde | Resultado | Causa |
|---|---|---|---|
| 1 | Sandbox de Claude (15 residuos flexibles) | Proceso terminado (sin memoria) | Límite de RAM del sandbox (3,9 GB) |
| 2 | Sandbox de Claude (5 residuos, exhaustividad reducida) | Tiempo agotado | Mismo límite de recursos |
| 3 | Máquina local del usuario, Vina nativo, 18 residuos | "No conformations completely within the search space" | **Causa exacta calculada**: los átomos móviles de los 18 residuos flexibles se extienden hasta 22,7 Å del centro de la caja (rango real: 31×21×15 Å), mientras la caja definida (25×25×25 Å) solo cubre 12,5 Å de radio. Habría hecho falta una caja de ≈41×31×25 Å para contener todo el movimiento posible. |

**Por qué no se insiste con una caja más grande:** agrandar la caja a ese tamaño convierte la
búsqueda en semi-ciega (deja de estar enfocada en el sitio) y dispara el costo computacional
-- muy probablemente hubiera vuelto a fallar por recursos, como los intentos 1 y 2. La opción
quirúrgica (reducir a los 6 residuos más cercanos al ADP: 575, 547, 548, 484, 544, 482, que caben
en una caja razonable) quedó identificada pero no se ejecutó, por decisión explícita de cerrar
esta línea de investigación.

## 11. Estrategia aceptada para seguir con docking RÍGIDO

Dado que (a) el sitio de unión está validado por homología estructural con evidencia fuerte
(RMSD 1,72 Å, identidad del bolsillo 50%, auditoría 002) y (b) el problema del redocking rígido
es conocido, diagnosticado y consistente en 2 corridas independientes (4,08 Å y 5,76 Å, ambas
con el extremo de fosfatos correctamente anclado en Walker A), se adopta el siguiente criterio
metodológico para el resto del proyecto:

- **El sitio de docking lo define la homología estructural (Fase 3), no el redocking.** El
  redocking del ADP no se usa como prueba de que el protocolo "encuentra" el sitio correcto --
  eso ya se estableció independientemente por alineamiento de secuencia y superposición 3D.
- **Los puntajes de Vina se usan para RANKING relativo entre compuestos candidatos, no como
  prueba de modo de unión exacto.** Esta es una práctica estándar y defendible en cribado
  virtual: no se necesita redocking perfecto de un ligando conocido para que el ranking relativo
  de docking rígido sea informativo dentro de un sitio ya validado por otras vías.
- **Limitación a declarar explícitamente en el manuscrito** (no ocultar): el redocking rígido del
  ADP no reproduce su pose cristalográfica exacta (RMSD >4 Å en 2 corridas independientes),
  probablemente por diferencias de rotámero en el bolsillo del modelo *apo* de AlphaFold3 respecto
  a la conformación con ligando. El docking flexible, que podría corregir esto, no se completó por
  limitaciones de recursos computacionales -- se documenta como dirección futura, no como intento
  fallido silencioso.

## 12. Veredicto final

**Investigación de docking flexible cerrada por decisión del usuario, con causa técnica
diagnosticada (no un fallo sin explicación).** Se sigue con docking rígido para el resto del
proyecto, bajo la estrategia metodológica de la §11: el sitio lo define la homología estructural
(ya validada, RMSD 1,72 Å), y los puntajes de Vina se usan para ranking relativo de compuestos,
no como prueba de modo de unión exacto. La limitación del redocking (RMSD >4 Å en 2 corridas
independientes) se declara explícitamente en el manuscrito, junto con el hallazgo parcial de que
el extremo de fosfatos del ADP sí ancla correctamente en los residuos reales de Walker A en ambas
corridas rígidas — evidencia de que el bolsillo, aunque no reproduce la pose completa, sí es
químicamente activo y coherente en su mitad más conservada. **Fase 4 puede avanzar al armado de
la biblioteca de compuestos.**
