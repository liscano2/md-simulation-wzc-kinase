# 05_fase4_docking

**Estado: pendiente.** Esta carpeta se llena al llegar a esa fase del plan
(ver `../01_plan/PLAN_v2_WzbWzc_KinasesPhosphatases.md`). No crear archivos aquí manualmente;
se generan como entregables de la sesión de Claude correspondiente.
