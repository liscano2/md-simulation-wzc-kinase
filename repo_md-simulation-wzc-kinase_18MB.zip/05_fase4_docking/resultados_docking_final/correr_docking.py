import pandas as pd, os, time, csv, sys

CENTRO = [12.760, 3.512, -58.336]
CAJA = [25, 25, 25]
SEMILLAS = [111, 222, 333]
ARCHIVO_RESULTADOS = "resultados_docking.csv"
MAX_CORRIDAS_ESTE_BLOQUE = int(sys.argv[1]) if len(sys.argv) > 1 else 25

from vina import Vina

df = pd.read_csv("biblioteca_con_id.csv")

# Qué combos ya están hechos (leyendo lo que haya en disco, línea por línea)
combos_hechos = set()
if os.path.exists(ARCHIVO_RESULTADOS):
    with open(ARCHIVO_RESULTADOS) as f:
        lector = csv.DictReader(f)
        for fila in lector:
            combos_hechos.add((fila["ligando_id"], int(fila["semilla"])))

# Si el archivo no existe, crearlo con encabezado
if not os.path.exists(ARCHIVO_RESULTADOS):
    with open(ARCHIVO_RESULTADOS, "w", newline="") as f:
        csv.writer(f).writerow(["ligando_id", "semilla", "afinidad_kcal_mol", "tiempo_s"])

hechos_este_bloque = 0
for _, fila in df.iterrows():
    if hechos_este_bloque >= MAX_CORRIDAS_ESTE_BLOQUE:
        break
    lig_id = fila["ligando_id"]
    pdbqt = f"ligandos/{lig_id}.pdbqt"
    if not os.path.exists(pdbqt):
        continue
    for semilla in SEMILLAS:
        if hechos_este_bloque >= MAX_CORRIDAS_ESTE_BLOQUE:
            break
        if (lig_id, semilla) in combos_hechos:
            continue
        t0 = time.time()
        try:
            v = Vina(sf_name='vina', cpu=0, seed=semilla, verbosity=0)
            v.set_receptor('receptor_Ab.pdbqt')
            v.compute_vina_maps(center=CENTRO, box_size=CAJA)
            v.set_ligand_from_file(pdbqt)
            v.dock(exhaustiveness=2, n_poses=3)
            afinidad = v.energies(n_poses=3)[0][0]
            dt = time.time() - t0
        except Exception as e:
            afinidad, dt = "", ""
            print(f"{lig_id} semilla={semilla}: ERROR -- {str(e)[:120]}", flush=True)

        # ESCRITURA INMEDIATA -- se guarda apenas termina esta corrida, no al final del bloque
        with open(ARCHIVO_RESULTADOS, "a", newline="") as f:
            csv.writer(f).writerow([lig_id, semilla, afinidad, dt])

        if afinidad != "":
            print(f"{lig_id} semilla={semilla}: {afinidad:.2f} kcal/mol ({dt:.0f}s)", flush=True)
        combos_hechos.add((lig_id, semilla))
        hechos_este_bloque += 1

total_combos = len(df) * len(SEMILLAS)
print(f"\n=== Este bloque: {hechos_este_bloque} corridas nuevas. Total acumulado: "
      f"{len(combos_hechos)}/{total_combos} ===", flush=True)
