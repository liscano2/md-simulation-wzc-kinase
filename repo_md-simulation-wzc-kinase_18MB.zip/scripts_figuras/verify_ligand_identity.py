# -*- coding: utf-8 -*-
"""Verifica que el ligando depositado en un PDB es la molecula que el manuscrito
dice que es, comparando el grafo molecular de atomos pesados (elemento +
conectividad) contra el grafo de una estructura de referencia construida desde
su SMILES. No usa ordenes de enlace, que el formato PDB no almacena, asi que la
comparacion es de topologia y composicion, que es lo que se puede afirmar con
rigor a partir de coordenadas.

Uso:
    python verify_ligand_identity.py data/adp_docked_pose.pdb UNL ADP
"""
import sys
import networkx as nx
from rdkit import Chem

REFERENCIAS = {
    # ADP: adenina + ribosa + difosfato
    "ADP": "Nc1ncnc2c1ncn2[C@@H]1O[C@H](COP(=O)(O)OP(=O)(O)O)[C@@H](O)[C@H]1O",
}


def grafo_desde_pdb(ruta, resname):
    """Grafo de atomos pesados leyendo coordenadas y registros CONECT."""
    elementos, serie_a_idx = {}, {}
    with open(ruta) as fh:
        lineas = fh.readlines()
    for ln in lineas:
        if ln.startswith(("ATOM", "HETATM")) and ln[17:20].strip() == resname:
            serial = int(ln[6:11])
            el = ln[76:78].strip() or ln[12:16].strip()[0]
            elementos[serial] = el
    pesados = {s: e for s, e in elementos.items() if e != "H"}
    G = nx.Graph()
    for s, e in pesados.items():
        G.add_node(s, element=e)
    for ln in lineas:
        if ln.startswith("CONECT"):
            campos = [ln[i:i + 5].strip() for i in range(6, len(ln.rstrip()), 5)]
            campos = [int(c) for c in campos if c]
            if not campos:
                continue
            a = campos[0]
            for b in campos[1:]:
                if a in pesados and b in pesados:
                    G.add_edge(a, b)
    return G


def grafo_desde_smiles(smiles):
    mol = Chem.MolFromSmiles(smiles)
    G = nx.Graph()
    for at in mol.GetAtoms():
        G.add_node(at.GetIdx(), element=at.GetSymbol())
    for bd in mol.GetBonds():
        G.add_edge(bd.GetBeginAtomIdx(), bd.GetEndAtomIdx())
    return G


def formula(G):
    from collections import Counter
    c = Counter(d["element"] for _, d in G.nodes(data=True))
    return " ".join(f"{e}{n}" for e, n in sorted(c.items()))


def main(ruta, resname, nombre_ref):
    G1 = grafo_desde_pdb(ruta, resname)
    G2 = grafo_desde_smiles(REFERENCIAS[nombre_ref])
    coincide_elemento = nx.algorithms.isomorphism.categorical_node_match("element", None)
    iso = nx.is_isomorphic(G1, G2, node_match=coincide_elemento)
    print(f"Archivo            : {ruta}  (residuo {resname})")
    print(f"Referencia         : {nombre_ref}")
    print(f"Atomos pesados     : depositado {G1.number_of_nodes()} | referencia {G2.number_of_nodes()}")
    print(f"Enlaces pesados    : depositado {G1.number_of_edges()} | referencia {G2.number_of_edges()}")
    print(f"Composicion        : depositado [{formula(G1)}] | referencia [{formula(G2)}]")
    print(f"Grafos isomorfos   : {iso}")
    if iso:
        print(f"\nRESULTADO: la pose depositada es {nombre_ref}: misma composicion de "
              f"atomos pesados y misma conectividad, atomo por atomo y enlace por enlace.")
    else:
        print("\nRESULTADO: NO coincide. Revisar el archivo antes de usarlo en una figura.")
    return 0 if iso else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1], sys.argv[2], sys.argv[3]))
