# -*- coding: utf-8 -*-
"""
Figura 4, recuadro de detalle del sitio de union de ADP, generado desde las
coordenadas reales y no dibujado.

Entradas (ambas en el mismo marco de coordenadas, verificado):
    3LA6.pdb                              cristal de E. coli con ADP
    AF3_Abaumannii_superpuesto_a_3LA6.pdb modelo de A. baumannii superpuesto

Todo lo que aparece rotulado se lee de los registros del PDB: el nombre y el
numero de cada residuo salen del propio archivo, y los contactos se calculan por
geometria. La conectividad del ADP se deriva por distancia entre atomos pesados
y se contrasta contra la estructura de referencia de ADP antes de dibujar.
"""
import sys
import itertools
from collections import Counter

import numpy as np
import networkx as nx
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

CRISTAL = sys.argv[1] if len(sys.argv) > 1 else "3LA6.pdb"
MODELO = sys.argv[2] if len(sys.argv) > 2 else "AF3_Abaumannii_superpuesto_a_3LA6.pdb"
SALIDA = sys.argv[3] if len(sys.argv) > 3 else "Figure4B_pocket_inset"

BOLSILLO_S26 = [481, 482, 483, 484, 487, 488, 496, 498, 499,
                541, 542, 543, 544, 545, 546, 547, 548, 575]
ADP_SMILES = "Nc1ncnc2c1ncn2[C@@H]1O[C@H](COP(=O)(O)OP(=O)(O)O)[C@@H](O)[C@H]1O"
CORTE, POLAR_MIN, POLAR_MAX = 4.5, 2.40, 3.50
T31 = {"ALA": "Ala", "ARG": "Arg", "ASN": "Asn", "ASP": "Asp", "CYS": "Cys",
       "GLN": "Gln", "GLU": "Glu", "GLY": "Gly", "HIS": "His", "ILE": "Ile",
       "LEU": "Leu", "LYS": "Lys", "MET": "Met", "PHE": "Phe", "PRO": "Pro",
       "SER": "Ser", "THR": "Thr", "TRP": "Trp", "TYR": "Tyr", "VAL": "Val"}
RADIO_COV = {"C": 0.77, "N": 0.75, "O": 0.73, "P": 1.10, "S": 1.03}


def leer(ruta, filtro):
    out = []
    for ln in open(ruta):
        if ln.startswith(("ATOM", "HETATM")):
            try:
                resi = int(ln[22:26])
            except ValueError:
                continue
            d = dict(nombre=ln[12:16].strip(), resn=ln[17:20].strip(), ch=ln[21],
                     resi=resi, el=(ln[76:78].strip() or ln[12:16].strip()[0]).upper(),
                     xyz=np.array([float(ln[30:38]), float(ln[38:46]), float(ln[46:54])]))
            if d["el"] != "H" and filtro(d):
                out.append(d)
    return out


adp = leer(CRISTAL, lambda d: d["resn"] == "ADP" and d["ch"] == "A")
prot = leer(MODELO, lambda d: d["resn"] in T31)
if not adp:
    sys.exit("No se encontro ADP en la cadena A del cristal.")

# ---- conectividad del ADP por radio covalente y cotejo contra ADP de referencia
G = nx.Graph()
for i, a in enumerate(adp):
    G.add_node(i, element=a["el"])
for i, j in itertools.combinations(range(len(adp)), 2):
    d = np.linalg.norm(adp[i]["xyz"] - adp[j]["xyz"])
    lim = RADIO_COV.get(adp[i]["el"], 0.8) + RADIO_COV.get(adp[j]["el"], 0.8) + 0.45
    if d < lim:
        G.add_edge(i, j)
from rdkit import Chem
ref = Chem.MolFromSmiles(ADP_SMILES)
R = nx.Graph()
for at in ref.GetAtoms():
    R.add_node(at.GetIdx(), element=at.GetSymbol())
for bd in ref.GetBonds():
    R.add_edge(bd.GetBeginAtomIdx(), bd.GetEndAtomIdx())
iso = nx.is_isomorphic(G, R,
                       node_match=nx.algorithms.isomorphism.categorical_node_match("element", None))
comp = " ".join(f"{e}{n}" for e, n in sorted(Counter(a["el"] for a in adp).items()))
print(f"ADP del cristal: {len(adp)} atomos pesados, {G.number_of_edges()} enlaces, "
      f"composicion {comp}, isomorfo a ADP: {iso}")
if not iso:
    sys.exit("El ligando del cristal no coincide con ADP; no se dibuja.")

# ---- contactos reales
L = np.array([a["xyz"] for a in adp])
P = np.array([a["xyz"] for a in prot])
D = np.linalg.norm(P[:, None, :] - L[None, :, :], axis=2)
por_res = {}
for i, j in zip(*np.where(D < CORTE)):
    pa, la = prot[i], adp[j]
    d = float(D[i, j])
    tipo = "vdW"
    if pa["el"] in "NO" and la["el"] in "NO":
        tipo = "polar" if POLAR_MIN <= d <= POLAR_MAX else ("solape" if d < POLAR_MIN else "vdW")
    por_res.setdefault((pa["resi"], pa["resn"]), []).append(
        dict(ap=pa, al=la, d=d, tipo=tipo))

orden = sorted(por_res.items(), key=lambda kv: min(f["d"] for f in kv[1]))
with open(f"{SALIDA}_contacts.csv", "w") as fh:
    fh.write("resi,resn,atomo_modelo,atomo_ADP,distancia_A,tipo,en_conjunto_S2.6\n")
    for (resi, resn), fs in orden:
        for f in sorted(fs, key=lambda x: x["d"]):
            fh.write(f"{resi},{resn},{f['ap']['nombre']},{f['al']['nombre']},"
                     f"{f['d']:.2f},{f['tipo']},"
                     f"{'si' if resi in BOLSILLO_S26 else 'no'}\n")

# ---- proyeccion 2D sobre el plano principal del ligando
centro = L.mean(axis=0)
_, _, vt = np.linalg.svd(L - centro)
e1, e2 = vt[0], vt[1]
pr = lambda x: np.array([(x - centro) @ e1, (x - centro) @ e2])

COL = {"C": "#36454f", "N": "#2b6cb0", "O": "#c53030", "P": "#dd6b20"}
fig, ax = plt.subplots(figsize=(7.6, 7.2))
for i, j in G.edges():
    p1, p2 = pr(adp[i]["xyz"]), pr(adp[j]["xyz"])
    ax.plot([p1[0], p2[0]], [p1[1], p2[1]], "-", color="#20272e", lw=2.6,
            zorder=3, solid_capstyle="round")
for a in adp:
    p = pr(a["xyz"])
    ax.scatter(*p, s=145, c=COL.get(a["el"], "#777"), zorder=4,
               edgecolors="white", linewidths=1.2)

radio = max(np.linalg.norm(pr(a["xyz"])) for a in adp) + 4.6
anclas = []
for (resi, resn), fs in orden:
    mejor = min(fs, key=lambda f: f["d"])
    a = pr(mejor["ap"]["xyz"]); anclas.append(np.arctan2(a[1], a[0]))
idx = np.argsort(anclas)
orden = [orden[i] for i in idx]
ang = np.sort(np.array(anclas))
ang = np.linspace(ang[0], ang[0] + 2*np.pi, len(orden), endpoint=False)
for ((resi, resn), fs), th in zip(orden, ang):
    mejor = min(fs, key=lambda f: f["d"])
    anc = pr(mejor["ap"]["xyz"])
    etq = np.array([radio * np.cos(th), radio * np.sin(th)])
    tipos = {f["tipo"] for f in fs}
    polar = "polar" in tipos
    solape = (not polar) and "solape" in tipos
    ax.plot([anc[0], etq[0]], [anc[1], etq[1]], ls="--" if polar else ("-." if solape else ":"),
            color="#2f855a" if polar else ("#b7791f" if solape else "#b4bcc6"),
            lw=1.5 if polar else (1.3 if solape else 1.1), zorder=2)
    en = resi in BOLSILLO_S26
    txt = f"{T31.get(resn, resn)}{resi}"
    if polar:
        dmin = min(f["d"] for f in fs if f["tipo"] == "polar")
        txt += f"\n{dmin:.2f} Å"
    elif solape:
        txt += "\noverlap"
    ax.text(etq[0], etq[1], txt, ha="center", va="center", fontsize=8.6,
            fontweight="bold" if en else "normal",
            color="#1a202c" if en else "#718096", linespacing=1.25,
            bbox=dict(boxstyle="round,pad=0.30", fc="#f0fff4" if polar else ("#fffaf0" if solape else "white"),
                      ec="#2f855a" if polar else ("#b7791f" if solape else "#cbd5e0"), lw=1.1))

ax.set_aspect("equal")
ax.axis("off")
ax.set_xlim(-radio - 3.2, radio + 3.2)
ax.set_ylim(-radio - 2.6, radio + 2.6)
ax.legend(handles=[
    Line2D([], [], ls="--", color="#2f855a", lw=1.5, label=f"N/O pair {POLAR_MIN:.1f}\u2013{POLAR_MAX:.1f} Å"),
    Line2D([], [], ls="-.", color="#b7791f", lw=1.3,
           label=f"N/O pair < {POLAR_MIN:.1f} Å (rigid-superposition overlap)"),
    Line2D([], [], ls=":", color="#b4bcc6", lw=1.1, label=f"heavy-atom contact < {CORTE} Å"),
    Line2D([], [], ls="none", marker="s", color="#1a202c", markersize=0,
           label="bold: residue of the 18-member set (Section 2.6)")],
    loc="lower center", bbox_to_anchor=(0.5, -0.085), ncol=2,
    frameon=False, fontsize=8, handlelength=2.4)
fig.tight_layout()
fig.savefig(f"{SALIDA}.png", dpi=600, bbox_inches="tight")
fig.savefig(f"{SALIDA}.pdf", bbox_inches="tight")

dentro = [r for (r, _), _ in orden if r in BOLSILLO_S26]
fuera = [r for (r, _), _ in orden if r not in BOLSILLO_S26]
print(f"Residuos en contacto: {len(orden)}  | del conjunto de la Seccion 2.6: "
      f"{len(dentro)} {sorted(dentro)}  | fuera: {sorted(fuera)}")
print(f"Generados: {SALIDA}.png/.pdf y {SALIDA}_contacts.csv")
