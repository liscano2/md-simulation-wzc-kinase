# AUDITORÍA 005 — Sección de Resultados (Fases 1–5)
**Fecha:** 2026-08-05
**Objeto auditado:** borrador `RESULTS_v1_draft.md` (§3.1–3.14 + pies de figura/tabla)
**Método:** revisión adversarial simulada por tres perfiles de revisor, seguida de verificación
directa de cada afirmación contra las figuras finales (Figure7/8/S1, 600 dpi) y las tablas reales
(TableS7/S8/S9). Toda afirmación no verificable se marcó para corrección o eliminación.

---

## REVISOR 1 — Biólogo estructural

### R1.1 — ERROR FACTUAL CONFIRMADO (crítico)
**Afirmación del borrador (§3.11):** *"the pocket-forming residues remained among the least mobile
in the domain"*, citando la Figura 7C.

**Verificación:** se inspeccionó directamente el panel C de `Figure7_structural_stability.tiff`. Las
barras rojas (residuos del bolsillo) NO son homogéneamente bajas. Se distinguen dos subconjuntos:
- Residuos **481–499**: RMSF ≈ 2.5–4.0 Å — están entre los MÁS móviles del dominio, no los menos.
- Residuos **541–548 y 575**: RMSF < 1 Å — efectivamente los menos móviles.

**Veredicto:** la afirmación es falsa tal como está escrita. **CORREGIR.**

**Hallazgo derivado (no estaba en el borrador):** esta estratificación de movilidad es
**anticorrelacionada con la ocupación de contacto** de la Tabla 4:
| Subconjunto | RMSF (Fig. 7C) | Ocupación (Tabla 4) |
|---|---|---|
| 541–548, 575 (excepto 541, 546) | < 1 Å | 72–100% |
| 481–499 | 2.5–4.0 Å | 0.05–76% (mediana ≈ 9%) |

Es una validación cruzada interna entre dos análisis independientes: la rigidez local predice la
persistencia del contacto. **AÑADIR como hallazgo.**

### R1.2 — SOBRESIMPLIFICACIÓN CONFIRMADA
**Afirmación del borrador (§3.11):** *"Four independent structural observables changed in the same
time window"* → transición "concertada" a ~70 ns.

**Verificación panel por panel:**
- Panel B (RMSD ligando): sube desde t = 0, meseta ≈ 70–75 ns.
- Panel A (RMSD proteína): escalón nítido a **45–55 ns** (con un mínimo local a ~40 ns).
- Paneles D y E (R_g y SASA): escalón a **~70 ns**.

Los cuatro NO cambian en la misma ventana: hay un **orden temporal** (ligando → proteína →
compactación). Llamarlo "concertado" borra justamente lo más informativo del dato.

**Veredicto:** **CORREGIR** a una descripción secuencial. El orden observado refuerza la
interpretación de ajuste inducido en lugar de debilitarla.

### R1.3 — DATO IMPRECISO
**Afirmación:** *"The radius of gyration decreased from approximately 18.4 Å"*.
**Verificación:** el R_g **aumenta primero** (pico ≈ 18.85 Å a ~30 ns) y solo después desciende.
Describirlo como un descenso monótono omite la expansión transitoria previa. **CORREGIR.**

### R1.4 — ERROR DE TIEMPO
**Afirmación (§3.13):** *"Tyr579 maintained π–π stacking from 15 ns onward"*.
**Verificación (heatmap, Fig. 8C):** Tyr579 participa 0–15 ns, **se pierde entre ~15 y ~45 ns**, y
solo desde ~45 ns es continuo. **CORREGIR.** Igualmente, Tyr575 presenta un hueco ~115–125 ns no
mencionado.

---

## REVISOR 2 — Químico computacional

### R2.1 — DISCREPANCIA NO ABORDADA (importante)
El §3.9 reporta **5 puentes de hidrógeno** en la pose acoplada (PLIP), pero el §3.13 y la Figura 8C
indican **cero puentes de hidrógeno clasificados en el primer fotograma de producción (0 ns)**.
El borrador presenta ambos sin reconciliarlos, lo que un revisor leerá como contradicción interna.

**Explicación real (verificada contra el flujo de trabajo del proyecto):** el fotograma de 0 ns de
producción NO es la pose acoplada. Entre ambos median una minimización de energía y una
equilibración restringida de 125 ps. Además, PLIP y la herramienta de perfilado dinámico aplican
criterios geométricos distintos. Ambas causas son plausibles y no son mutuamente excluyentes.

**Veredicto:** **AÑADIR una aclaración explícita.** No afirmar cuál de las dos causas domina, dado
que no se hizo el experimento que lo distinguiría.

### R2.2 — MÉTRICAS TRATADAS COMO EQUIVALENTES SIN SERLO
La ocupación de contacto (Tabla 4; criterio: cualquier átomo pesado ≤ 4.5 Å) y la clasificación de
interacciones (Fig. 8C; criterios geométricos por tipo) miden cosas distintas. Ejemplo concreto que
lo demuestra: **Ser547 tiene 72.0% de ocupación de contacto pero solo un episodio breve
(~75–85 ns) de interacción clasificada.** Sin aclarar la diferencia, esto parece un error.

**Veredicto:** **AÑADIR una frase que distinga ambas métricas** como complementarias, no redundantes.

### R2.3 — INTERPRETACIÓN INSUFICIENTEMENTE RESPALDADA (resuelto con R1.1)
La afirmación central del §3.12 (el ligando se reorienta, no se disocia) descansaba únicamente en la
ocupación de contacto. Con el hallazgo de R1.1 incorporado, pasa a tener dos líneas de evidencia
independientes (ocupación + rigidez local del subsitio que lo retiene). **REFORZAR.**

### R2.4 — CORRECTO, SIN CAMBIOS
La declaración de que `SD_between_blocks` no es desviación entre réplicas está presente en el §3.14,
en el pie de la Tabla 3 y en la nota de auditoría. Es adecuada y no se presta a confusión.

---

## REVISOR 3 — Editor / lector no especialista

### R3.1 — CORRECTO
Todas las figuras y tablas (principales y suplementarias) están citadas al menos una vez en el
cuerpo del texto. Verificado uno por uno: Tablas 1–4, Figuras 1–8, Tablas S1–S5, Figuras S1–S2.

### R3.2 — CORRECTO
Abreviaturas definidas en su primera aparición en el cuerpo y no redefinidas después. Los pies de
figura y tabla incluyen su propia lista de abreviaturas, como exige la convención de la revista
(cada elemento debe ser interpretable sin leer el texto completo).

### R3.3 — MEJORABLE
Varias oraciones superan las 45 palabras con incisos anidados, lo que dificulta la lectura sin
aportar precisión. **CORREGIR** dividiendo las más largas.

### R3.4 — OBSERVACIÓN DE FONDO (no es un defecto, es una fortaleza a preservar)
La sección reporta sistemáticamente resultados que van en contra de la hipótesis cómoda: el
redocking falló, el candidato elegido no era el de mejor puntaje, el ligando se desplazó 7.4 Å, uno
de los dos anclajes de Walker A se perdió, y solo hay una trayectoria en vez de un triplicado.
Mantener esa transparencia; es lo que hace defendible el resto.

---

## RESUMEN DE CORRECCIONES APLICADAS

| # | Origen | Corrección |
|---|---|---|
| 1 | R1.1 | Corregida la afirmación falsa sobre RMSF; añadida la anticorrelación movilidad–ocupación como hallazgo nuevo |
| 2 | R1.2 | "Transición concertada" → descripción secuencial con el orden temporal real |
| 3 | R1.3 | Añadida la expansión transitoria del R_g previa al descenso |
| 4 | R1.4 | Corregido el tiempo de Tyr579 (45 ns, no 15 ns); añadido el hueco de Tyr575 |
| 5 | R2.1 | Añadida la reconciliación PLIP (pose acoplada) vs. 0 ns de producción |
| 6 | R2.2 | Añadida la distinción entre ocupación de contacto y clasificación de interacciones |
| 7 | R2.3 | Reforzado el §3.12 con la segunda línea de evidencia |
| 8 | R3.3 | Divididas las oraciones más largas |

**Estado tras corrección:** ninguna afirmación del texto final carece de respaldo verificable en las
figuras o tablas del propio proyecto. Las tres discrepancias internas detectadas (RMSF, timing,
PLIP vs. 0 ns) quedan resueltas o declaradas explícitamente.
