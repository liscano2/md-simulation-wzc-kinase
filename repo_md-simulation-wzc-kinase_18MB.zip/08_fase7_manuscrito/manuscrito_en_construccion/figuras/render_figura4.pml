load 3LA6.pdb, cristal_3LA6
load AF3_Abaumannii_superpuesto_a_3LA6.pdb, Ab_modelo

# Quedarnos solo con la cadena A del cristal (es un octámero, 16 cadenas)
remove cristal_3LA6 and not chain A
remove Ab_modelo and not (resi 451-700)

hide everything
bg_color white
set ray_opaque_background, 0

show cartoon, cristal_3LA6
show cartoon, Ab_modelo
color gray70, cristal_3LA6
color skyblue, Ab_modelo

# ADP como referencia
show sticks, cristal_3LA6 and resn ADP
color yellow, cristal_3LA6 and resn ADP and elem C

# Bolsillo de docking en A. baumannii
select bolsillo, Ab_modelo and resi 481+482+483+484+487+488+496+498+499+541+542+543+544+545+546+547+548+575
show sticks, bolsillo and not name C+N+O
color orange, bolsillo and elem C

set cartoon_transparency, 0.15, cristal_3LA6
set stick_radius, 0.18
set cartoon_fancy_helices, 1

orient Ab_modelo
zoom Ab_modelo, 5

set ray_trace_mode, 1
set antialias, 2
ray 1400, 1100
png Figura4_superposicion_3D.png, dpi=200

print("RMSD reportado por PyMOL (referencia cruzada, alineamiento por estructura):")
align Ab_modelo, cristal_3LA6
