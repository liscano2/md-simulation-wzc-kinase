# FIGURE & TABLE INDEX — living document
### Keeps track of what exists, what's still needed, and where the source data lives, so nothing
### has to be reconstructed from memory when assembling the final submission package.

**Status: as of 2026-08-01, covers Phases 1–4 (validation sub-step).**

---

## Main-text figures

| # | Title (working) | Status | File | Source data |
|---|---|---|---|---|
| 1 | PRISMA flow diagram (systematic search, n=14) | ✅ Done | `figuras/prisma_diagrama.png` (copy from `02_fase1_curaduria/revision_sistematica/`) | `_conteo_prisma.py`, `generar_prisma.py` |
| 2 | Breakpoint analysis: C^J_kinase vs. k_cat,kin | ✅ Done | `figuras/Figura2_breakpoint_analysis.png` (+ .svg) | Regenerated from N2 model parameters, this session |
| 3 | Structural confidence of the AF3 model (pLDDT/PAE) | ✅ Done | `figuras/Figura3_confianza_estructural.png` (+ .svg) | `04_fase3_estructura/modelos/AF3_Wzc_fulllength_raw/` |
| 4 | 3D superposition, A. baumannii domain vs. 3LA6 | ✅ Done | `figuras/Figura4_superposicion_3D.png` | PyMOL render, this session — **recommend visual QC by user before final use, camera angle not manually verified** |
| 5 | Chemical space characterization and ligand library curation (4-panel composite) | ✅ Done | `figuras/Figura5_espacio_quimico_compuesta.png` (+ .svg) | `05_fase4_docking/notebooks/N4b_propiedades_seleccion.ipynb`, real functional-group SMARTS analysis added 2026-08-02 |
| 6 | Docking interaction diagram (2D), ADP in the A. baumannii pocket | ✅ Have from user | `05_fase4_docking/corridas_usuario/interacciones.png` — **user-generated (Discovery Studio), verify licensing/reproducibility before using directly in the manuscript; may need to regenerate in an open tool** | — |
| — | Model schematic of the Wzb/Wzc phosphorylation cycle (Eqs. 1–4 as a diagram) | ⬜ Not started | — | Conceptual — candidate for the Visualizer or a simple drawn schematic. Figure numbering (7, 8, this one, S-Stability) still needs final ordering before submission |
| 7 | MD structural stability panel (RMSD protein/ligand, RMSF+pocket, Rg, SASA, PCA) | ⬜ Pending — simulation running (200 ns target) | — | 6-panel composite planned, see `06_fase5_dinamica_molecular/plan_analisis_MD.md` |
| 8 | Key interactions panel: H-bond persistence, per-residue binding energy, key-contact distances, pocket occupancy (4-panel, confirmed) | ⬜ Pending — same status | — | Connects to Table S5 (PLIP) and Fase 4 pocket-contact analysis. Panel B requires `gmx_MMPBSA` (confirmed in scope) |
| S-Stability | Thermodynamic stability panel (T, P, density, potential energy) | ⬜ Pending — same status | — | Supplementary, 4-panel. Standard reviewer request for MD papers |
| — | Per-residue binding energy decomposition ("hot spots", gmx_MMPBSA) | ⬜ Pending decision — in/out of scope | — | Not plain GROMACS; needs separate install. Decide once trajectory is available |

## Supplementary tables

| # | Title | Status | File |
|---|---|---|---|
| S1 | Master curation table (25 rows, all parameters with source and approximation flag) | ✅ Done | `tablas_suplementarias/TableS1_master_curation.csv` |
| S2 | Systematic review extraction table (18 rows, F01–F18) | ✅ Done | `tablas_suplementarias/TableS2_extraction.csv` |
| S3 | Risk-of-bias / quality assessment (adapted 7-domain checklist) | ✅ Done | `tablas_suplementarias/TableS3_risk_of_bias.csv` |
| S4 | Docking interaction distances (rigid redocking, independent user run) | ✅ Done | `tablas_suplementarias/TableS4_docking_interactions.xlsx` |
| S-Docking-1 | Flexible-docking troubleshooting log (3 attempts, causes diagnosed) | ⬜ Not yet written as a standalone table — currently narrative in `AUDITORIA_003_redocking_validacion.md` §10 | Convert before submission |

## Supplementary methods

| # | Title | Status | File |
|---|---|---|---|
| S1 | Full systematic review protocol (PECO, search strings, inclusion/exclusion, screening flow) | ✅ Done | `02_fase1_curaduria/revision_sistematica/protocolo_revision_sistematica.md` |

## Pending figure/table work (tracked so it isn't lost)

1. **Figure 5** (cycle schematic) — not started. Low computational cost, mostly a design decision
   (matplotlib/schematic vs. Visualizer tool).
2. **Figure 6 licensing** — the 2D interaction diagram came from the user's own Discovery Studio
   Visualizer session. Before submission, confirm this is acceptable to reproduce, or regenerate
   with an open-source tool (e.g., PLIP, ProLIF) from the same docking pose for a fully
   reproducible, license-clean figure.
3. **Table S-Docking-1** — formalize the narrative troubleshooting account into a proper
   supplementary table (attempt #, parameters, outcome, diagnosed cause) — content already exists,
   just needs reformatting from prose to table.
4. Once Phase 4 screening (compound library + candidate docking) and Phase 5 (MD) begin, this
   index gets new rows — update in the same session those results are produced, not retroactively.
