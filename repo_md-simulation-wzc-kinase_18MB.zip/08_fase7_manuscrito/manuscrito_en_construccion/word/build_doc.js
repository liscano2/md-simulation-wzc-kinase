const fs = require("fs");
const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, ImageRun, Table, TableRow,
  TableCell, WidthType, ShadingType, AlignmentType, BorderStyle, PageOrientation,
  PageBreak, Header, Footer, PageNumber, ExternalHyperlink, VerticalAlign
} = docx = require("docx");

const PAGE_W_PORTRAIT = 12240, PAGE_H_PORTRAIT = 15840; // US Letter, DXA

function leerJSON(path) { return JSON.parse(fs.readFileSync(path, "utf8")); }

// ---------- Helpers ----------
function h(text, level) {
  return new Paragraph({ text, heading: level, spacing: { before: 300, after: 150 } });
}
function p(text, opts = {}) {
  return new Paragraph({
    children: [new TextRun({ text, ...opts })],
    spacing: { after: 120 },
  });
}
function pRuns(runs, opts = {}) {
  return new Paragraph({ children: runs, spacing: { after: 120 }, ...opts });
}
function bold(text) { return new TextRun({ text, bold: true }); }
function italic(text) { return new TextRun({ text, italics: true }); }
function plain(text) { return new TextRun({ text }); }

function figuraImagen(rutaImagen, anchoEmu, altoEmu) {
  const data = fs.readFileSync(rutaImagen);
  return new Paragraph({
    children: [new ImageRun({ data, transformation: { width: anchoEmu, height: altoEmu }, type: "png" })],
    alignment: AlignmentType.CENTER,
    spacing: { before: 200, after: 100 },
  });
}

function celda(texto, opts = {}) {
  return new TableCell({
    width: { size: opts.width || 1000, type: WidthType.DXA },
    shading: opts.header ? { type: ShadingType.CLEAR, fill: "D9E2F3" } : undefined,
    verticalAlign: VerticalAlign.CENTER,
    children: [new Paragraph({
      children: [new TextRun({ text: String(texto), bold: !!opts.header, size: opts.size || 16 })],
      alignment: opts.center ? AlignmentType.CENTER : AlignmentType.LEFT,
    })],
  });
}

function tablaDesdeJSON(rutaJSON, anchoColDXA, tamanoFuente = 15) {
  const datos = leerJSON(rutaJSON);
  const cols = datos.columnas;
  const anchoTotal = anchoColDXA * cols.length;
  const filaEncabezado = new TableRow({
    tableHeader: true,
    children: cols.map(c => celda(c, { header: true, width: anchoColDXA, size: tamanoFuente, center: true })),
  });
  const filasDatos = datos.filas.map(fila => new TableRow({
    children: fila.map(v => {
      let texto = v;
      if (typeof v === "number") texto = Number.isInteger(v) ? v : v.toFixed(3);
      return celda(texto, { width: anchoColDXA, size: tamanoFuente });
    }),
  }));
  return new Table({
    width: { size: anchoTotal, type: WidthType.DXA },
    columnWidths: cols.map(() => anchoColDXA),
    rows: [filaEncabezado, ...filasDatos],
  });
}

// ================= CONTENIDO =================
const children = [];

// ---- Portada ----
children.push(
  new Paragraph({ text: "Supplementary Compendium of Figures, Tables, and Methodological References",
    heading: HeadingLevel.TITLE, alignment: AlignmentType.CENTER, spacing: { after: 200 } }),
  new Paragraph({ children: [italic("Control-guided identification and structure-based virtual screening of a kinase-domain inhibitor targeting the Wzb/Wzc phosphorylation cycle in Acinetobacter baumannii")],
    alignment: AlignmentType.CENTER, spacing: { after: 400 } }),
  p("This document compiles all figures and tables generated to date, organized by their place in the manuscript narrative (main text vs. supplementary), each with its caption, legend, and a short analysis paragraph. Abbreviation lists and the methodology reference list close the document, followed by the recommended next steps for molecular dynamics system preparation."),
  new Paragraph({ children: [new PageBreak()] }),
);

// ================= MAIN TEXT FIGURES =================
children.push(h("Main-Text Figures", HeadingLevel.HEADING_1));

// --- Figure 1 ---
children.push(h("Figure 1", HeadingLevel.HEADING_2));
children.push(figuraImagen("figuras/prisma_diagrama.png", 560, 663));
children.push(pRuns([bold("Figure 1. "), italic("PRISMA 2020 flow diagram of the systematic search for Wzb/Wzc kinetic, structural, and pharmacological parameters."), plain(" Records were identified across five bibliographic platforms and one structural database (11 search queries), screened by title/abstract and then full text against pre-specified inclusion criteria (§2.2).")]));
children.push(pRuns([bold("Legend: "), plain("n = number of records at each PRISMA stage. \"Excluded (off-topic)\" = records sharing only genus/species or superficial keyword overlap, verified individually before exclusion.")]));
children.push(pRuns([bold("Analysis: "), plain("Of 80 records identified, 14 met inclusion criteria through the formal search (Table S2, entries F01\u2013F14), spanning identity/genomic data, structure, kinetics, pharmacology, and a direct computational antecedent. Four further sources (F15\u2013F18) were added later through mechanisms distinct from this formal search (a targeted follow-up search and opportunistic identification via AlphaFold3 template selection) and are intentionally excluded from this diagram to avoid overstating the systematic search's apparent yield \u2014 they are documented narratively and in Table S2 instead.")]));

// --- Figure 2 ---
children.push(h("Figure 2", HeadingLevel.HEADING_2));
children.push(figuraImagen("figuras/Figura2_breakpoint_analysis.png", 560, 395));
children.push(pRuns([bold("Figure 2. "), italic("Breakpoint analysis of flux-control robustness to uncertainty in the kinase turnover number (k"), plain("cat,kin"), italic(")."), plain(" The flux-control coefficient of the kinase (C\u1d36J_kinase) is plotted against kcat,kin, swept over a wide multiplicative range; the literature-derived value and the breakpoint where control becomes evenly shared (C\u1d36J = 0.5) are marked.")]));
children.push(pRuns([bold("Legend: "), plain("Red line/point: literature value (kcat,kin \u2248 0.015 s\u207b\u00b9, from Soulat et al., 2007). Green line/point: breakpoint (kcat,kin = 1.53 s\u207b\u00b9, \u2248102-fold higher).")]));
children.push(pRuns([bold("Analysis: "), plain("A conventional \u00b150% Sobol sensitivity analysis cannot meaningfully stress-test a control asymmetry this large (C\u1d36J_kinase = 0.997). The breakpoint analysis shows that a two-order-of-magnitude error in the literature-derived kinase turnover number would be required to overturn the qualitative conclusion that the kinase dominates flux control \u2014 a far more demanding robustness criterion than the asymmetry itself, and one the available approximation errors are very unlikely to reach.")]));

// --- Figure 3 ---
children.push(h("Figure 3", HeadingLevel.HEADING_2));
children.push(figuraImagen("figuras/Figura3_confianza_estructural.png", 560, 505));
children.push(pRuns([bold("Figure 3. "), italic("Structural confidence of the AlphaFold3 model of A. baumannii Wzc."), plain(" (A) Per-residue pLDDT across the full-length protein, with transmembrane helices, the retained kinase domain, Walker A, Walker B, and the excluded tyrosine-rich tail annotated. (B) Predicted Aligned Error (PAE) heatmap. (C) Mean pLDDT by functional region.")]));
children.push(pRuns([bold("Legend: "), plain("pLDDT: predicted local distance difference test (0\u2013100, higher = more confident). PAE: predicted aligned error in \u00c5 (lower = more confident in relative position).")]));
children.push(pRuns([bold("Analysis: "), plain("The moderate global pTM (0.76) of the full-length model reflects uncertain relative orientation between the cytoplasmic kinase domain and the transmembrane/periplasmic region (inter-domain PAE 9.8\u201315.9 \u00c5) rather than poor intra-domain fold quality (intra-domain PAE 4.8 \u00c5; Walker A/B region PAE 1.7 \u00c5). This is consistent with the biologically expected mobility of the kinase domain, required for octamer disassembly (Yang et al., 2021). The catalytic Walker A/B region is among the most confidently predicted in the entire structure (mean pLDDT 95.9 and 96.4, respectively); the excluded C-terminal tyrosine-rich tail is correctly predicted with low confidence (mean pLDDT 63.3), consistent with its expected intrinsic disorder.")]));

// --- Figure 4 ---
children.push(h("Figure 4", HeadingLevel.HEADING_2));
children.push(figuraImagen("figuras/Figura4_superposicion_3D.png", 560, 440));
children.push(pRuns([bold("Figure 4. "), italic("Structural superposition of the A. baumannii Wzc kinase domain (blue) onto the isolated E. coli kinase-domain crystal structure PDB 3LA6 (gray, transparent), with ADP shown as sticks and pocket residues in orange."), plain(" ")]));
children.push(pRuns([bold("Legend: "), plain("3LA6 is the catalytically inactive Walker-A K540M mutant, crystallized to trap ADP without turnover; the corresponding A. baumannii residue (Lys546) is intact in the present model.")]));
children.push(pRuns([bold("Analysis: "), plain("Sequence-alignment-guided C\u03b1 superposition gave RMSD = 1.72 \u00c5 over 234 aligned pairs (46.6% sequence identity); an independent cross-check using PyMOL's iterative all-atom alignment (outlier rejection) converged to RMSD = 0.72 \u00c5 over a best-fit core \u2014 two independent methods agreeing that the fold is well conserved. The ADP-contacting pocket is more conserved (50% identity, 9/18 residues) than the domain average (46.6%), consistent with functional conservation under purifying selection at the catalytic site.")]));

// --- Figure 5 ---
children.push(h("Figure 5", HeadingLevel.HEADING_2));
children.push(figuraImagen("figuras/Figura5_espacio_quimico_compuesta.png", 560, 493));
children.push(pRuns([bold("Figure 5. "), italic("Chemical space characterization and ligand library curation."), plain(" (A) Correlation matrix of seven molecular descriptors. (B) Elbow method for k-means (mathematical elbow vs. practical k). (C) PCA chemical space with the 50 cluster representatives marked. (D) Functional-group composition of the 50 representatives.")]));
children.push(pRuns([bold("Legend: "), plain("MW: molecular weight. HBD/HBA: hydrogen-bond donors/acceptors. TPSA: topological polar surface area. Cluster ID: k-means cluster assignment (k=50).")]));
children.push(pRuns([bold("Analysis: "), plain("Panel A shows strong correlation between TPSA and HBA (r=0.84), justifying PCA before clustering. Panel D shows a composition dominated by ether (38/50), hydroxyl (30/50), and aromatic-ring-containing (27/50) scaffolds, with no halogenated compounds \u2014 consistent with the library's natural-product-dominated composition (COCONUT), unlike synthetic/drug-like libraries where halogenation is common. Because raw clustering output under-represented the ChEMBL-derived kinase-inhibitor chemotype (only 2/50 representatives), a hybrid selection (all ChEMBL compounds passing \u22654/5 drug-likeness rules + the 48 COCONUT cluster representatives) was used for the final 66-compound docking library instead (\u00a73.8).")]));

// --- Figure 6 ---
children.push(h("Figure 6", HeadingLevel.HEADING_2));
children.push(figuraImagen("figuras/Figura6_resultados_docking.png", 560, 419));
children.push(pRuns([bold("Figure 6. "), italic("Docking screening results for the 66-compound hybrid candidate library."), plain(" (A) Top-10 compounds ranked by mean rigid-docking affinity (3 replicates; error bars = SD); lig_012 highlighted. (B) Affinity vs. real structural pocket engagement (marker size = Walker A/B residues contacted /8; color = QED). (C) 2D structure of the selected lead, lig_012 (ChEMBL CHEMBL4297643). (D) PLIP-detected interaction distances for the docked pose of lig_012.")]));
children.push(pRuns([bold("Legend: "), plain("QED: quantitative estimate of drug-likeness (0\u20131, higher = more drug-like). SA score: synthetic accessibility (1\u201310, lower = easier to synthesize). PLIP: Protein\u2013Ligand Interaction Profiler.")]));
children.push(pRuns([bold("Analysis: "), plain("The top-ranked compound by affinity (lig_042, \u221210.24 kcal/mol) contacted only 11/18 validated pocket residues and 4/8 Walker A/B residues. lig_012, ranked 10th by affinity (\u22129.02 \u00b1 0.09 kcal/mol), was the only top-10 compound to fully engage the Walker A/B motif (8/8) with the most extensive overall pocket contact (14/18), and was selected as the lead candidate on this combined structural and physicochemical basis rather than by affinity alone. PLIP identified 5 hydrogen bonds, 3 hydrophobic contacts, and 1 \u03c0-stacking interaction; two of the hydrogen-bonding residues (Glu543, Lys546) are the same Walker A backbone-amide residues independently engaged during ADP redocking validation (\u00a73.7), providing convergent evidence that this subsite is consistently and correctly engaged.")]));

fs.writeFileSync("/tmp/parte1_ok.txt", "ok");
console.log("Parte 1 (figuras principales) preparada, children:", children.length);

// ================= MAIN TEXT TABLES =================
children.push(new Paragraph({ children: [new PageBreak()] }));
children.push(h("Main-Text Tables", HeadingLevel.HEADING_1));

// --- Table 1 (kinetic parameters, hardcoded -- small table) ---
children.push(h("Table 1", HeadingLevel.HEADING_2));
const t1header = ["Parameter","Enzyme","Value","Basis","Source"].map(c=>celda(c,{header:true,center:true,width:2000}));
const t1rows = [
  ["K_m","Wzb (phosphatase)","1 mM (pNPP)","Direct","Vincent et al. 1999"],
  ["k_cat","Wzb (phosphatase)","1.46 s\u207b\u00b9","Derived (Vmax + MW)","Vincent et al. 1999"],
  ["K_D (ATP)","Wzc (kinase)","1.1 mM","Direct","Soulat et al. 2007"],
  ["k_cat","Wzc (kinase)","\u22480.015 s\u207b\u00b9","Derived, multiple approximation layers","Soulat et al. 2007"],
].map(f => new TableRow({ children: f.map(v=>celda(v,{width:2000})) }));
children.push(new Table({ width:{size:10000,type:WidthType.DXA}, columnWidths:[2000,2000,2000,2000,2000], rows:[new TableRow({children:t1header}),...t1rows] }));
children.push(pRuns([bold("Table 1. "), italic("Kinetic parameters of the Wzb/Wzc phosphorylation cycle used in the ordinary differential equation model (Eqs. 1\u20136)."), plain(" ")]));
children.push(pRuns([bold("Analysis: "), plain("The 97-fold difference in turnover number between the phosphatase and kinase (1.46 vs. 0.015 s\u207b\u00b9) is the central quantitative input driving the flux-control asymmetry reported in \u00a73.4 (C\u1d36J_kinase = 0.997) and is robust to substantial parameter uncertainty (Figure 2).")]));

// --- Table 2 (top 10 docking) ---
children.push(h("Table 2", HeadingLevel.HEADING_2));
children.push(tablaDesdeJSON("datos_table2.json", 1200, 15));
children.push(pRuns([bold("Table 2. "), italic("Top-10 candidates from rigid docking of the 66-compound hybrid library against the validated Wzc kinase-domain pocket, ranked by mean binding affinity (n=3 independent replicates)."), plain(" ")]));
children.push(pRuns([bold("Analysis: "), plain("lig_012 (rank 10, ChEMBL) was selected as the lead candidate despite its lower affinity rank because it uniquely combines complete Walker A/B pocket engagement (8/8) with the most extensive real structural contact with the validated pocket (14/18) \u2014 see Figure 6B and \u00a73.9 for full justification.")]));

// ================= SUPPLEMENTARY FIGURES =================
children.push(new Paragraph({ children: [new PageBreak()] }));
children.push(h("Supplementary Figures", HeadingLevel.HEADING_1));
children.push(p("No figures have been formally designated as supplementary at this stage of the project. All six figures produced so far (Figures 1\u20136 above) support the main narrative and are presented as main-text figures. A user-generated 2D protein\u2013ligand interaction diagram (Discovery Studio Visualizer output, file interacciones.png) exists from an earlier exploratory analysis; it is not included here because (a) it was produced with third-party licensed software of unconfirmed redistribution terms, and (b) Figure 6D (PLIP, open-source) already provides an equivalent, fully reproducible interaction analysis for the same candidate class. If additional supplementary figures are produced in later sessions (e.g., a schematic of the Wzb/Wzc cycle, currently pending), they should be appended to this section, not inserted into the main-text figure sequence above."));


// ================= SUPPLEMENTARY TABLES =================
children.push(new Paragraph({ children: [new PageBreak()] }));
children.push(h("Supplementary Tables", HeadingLevel.HEADING_1));

children.push(h("Table S1", HeadingLevel.HEADING_2));
children.push(p("(Master curation table \u2014 25 entries, wide format; see landscape section at end of document for the full table.)"));
children.push(pRuns([bold("Table S1. "), italic("Master curation table: every kinetic, structural, and pharmacological parameter used in this study, with organism, source citation, ortholog flag, and approximation-level status for each entry."), plain(" ")]));
children.push(pRuns([bold("Analysis: "), plain("This table is the single source of truth for parameter provenance across the whole project; every number used in the ODE model (Table 1) and structural pipeline traces back to a row here.")]));

children.push(h("Table S2", HeadingLevel.HEADING_2));
children.push(p("(Systematic review extraction table \u2014 18 entries F01\u2013F18, wide format; see landscape section at end of document.)"));
children.push(pRuns([bold("Table S2. "), italic("Extraction table of the systematic review and subsequent targeted searches, documenting inclusion pathway (formal search vs. targeted follow-up vs. opportunistic identification) for each of the 18 sources."), plain(" ")]));
children.push(pRuns([bold("Analysis: "), plain("Entries F01\u2013F14 came from the formal PRISMA-guided search (Figure 1); F15\u2013F18 (Soulat et al. 2007, Doublet et al. 1999, PDB 3LA6, PDB 3CIO) were added later through distinct, explicitly documented mechanisms, as detailed in \u00a73.1.")]));

children.push(h("Table S3", HeadingLevel.HEADING_2));
children.push(p("(Risk-of-bias / quality assessment, 7-domain adapted checklist \u2014 18 entries, wide format; see landscape section at end of document.)"));
children.push(pRuns([bold("Table S3. "), italic("Adapted 7-domain risk-of-bias assessment for each of the 18 sources, since no single validated risk-of-bias tool was identified as appropriate for this mixed kinetic/structural/pharmacological evidence base."), plain(" ")]));
children.push(pRuns([bold("Analysis: "), plain("Domain 5 (directness/ortholog distance) was the most frequently \u201cHigh\u201d risk domain, reflecting that most kinetic parameters come from E. coli or A. johnsonii orthologs rather than A. baumannii directly \u2014 a limitation declared explicitly throughout rather than minimized.")]));

children.push(h("Table S4", HeadingLevel.HEADING_2));
children.push(p("(Docking interaction distances \u2014 user-generated, Discovery Studio Visualizer output, rigid docking pose. Provided as .xlsx; not reproduced as an in-document table here because it originates from licensed third-party software of unconfirmed redistribution terms \u2014 see file TableS4_docking_interactions.xlsx.)"));
children.push(pRuns([bold("Table S4. "), italic("Interaction distances for an early rigid-docking pose (independent user-run validation), reported for cross-reference with the PLIP-based analysis of the final candidate (Table S5)."), plain(" ")]));
children.push(pRuns([bold("Analysis: "), plain("This table corresponds to the redocking validation phase (\u00a73.7), not the final candidate \u2014 it is retained as a historical cross-check that the phosphate-binding subsite (Walker A backbone amides) was consistently engaged even before the final 66-compound screen.")]));

children.push(h("Table S5", HeadingLevel.HEADING_2));
children.push(tablaDesdeJSON("datos_tableS5.json", 2500, 16));
children.push(pRuns([bold("Table S5. "), italic("PLIP-detected protein\u2013ligand interactions for the docked pose of the selected lead candidate, lig_012 (CHEMBL4297643), with residue, interaction type, distance, and angle (where applicable)."), plain(" ")]));
children.push(pRuns([bold("Analysis: "), plain("Glu543 and Lys546 \u2014 the same Walker A backbone-amide residues engaged during ADP redocking validation (\u00a73.7) \u2014 recur here as hydrogen-bond partners, providing convergent evidence across independent docking experiments that this subsite is consistently and correctly engaged.")]));

children.push(h("Table S6", HeadingLevel.HEADING_2));
children.push(p("(Full docking results, all 66 compounds \u2014 wide format; see landscape section at end of document.)"));
children.push(pRuns([bold("Table S6. "), italic("Complete rigid-docking results for all 66 compounds of the hybrid candidate library: ranking, source, mean affinity, standard deviation, best-hit affinity, number of drug-likeness rules passed, and physicochemical descriptors."), plain(" ")]));
children.push(pRuns([bold("Analysis: "), plain("Mean affinities ranged from \u22124.9 to \u221210.2 kcal/mol (median \u22127.7 kcal/mol); replicate standard deviations were generally small (0.005\u20130.29 kcal/mol), indicating stable convergence of the rigid search even under the reduced exhaustiveness used for full-library screening (\u00a72.10).")]));


// ================= ABBREVIATIONS =================
children.push(new Paragraph({ children: [new PageBreak()] }));
children.push(h("Abbreviations", HeadingLevel.HEADING_1));

children.push(h("Abbreviations used in Figures", HeadingLevel.HEADING_2));
const abrevFig = [
 ["ADP / ATP","Adenosine di-/triphosphate"],
 ["FCC / CCC","Flux-control coefficient / concentration-control coefficient"],
 ["HBA / HBD","Hydrogen-bond acceptor / donor"],
 ["MW","Molecular weight"],
 ["PAE","Predicted Aligned Error (AlphaFold3 confidence metric)"],
 ["PC1 / PC2","First / second principal component"],
 ["PCA","Principal component analysis"],
 ["pLDDT","Predicted local distance difference test (AlphaFold per-residue confidence, 0\u2013100)"],
 ["PLIP","Protein\u2013Ligand Interaction Profiler"],
 ["PRISMA","Preferred Reporting Items for Systematic Reviews and Meta-Analyses"],
 ["QED","Quantitative Estimate of Drug-likeness"],
 ["RMSD","Root-mean-square deviation"],
 ["SA score","Synthetic accessibility score"],
 ["SD","Standard deviation"],
 ["TPSA","Topological polar surface area"],
 ["WCSS","Within-cluster sum of squares (k-means inertia)"],
].map(([a,b])=>new TableRow({children:[celda(a,{width:2500}),celda(b,{width:7500})]}));
children.push(new Table({width:{size:10000,type:WidthType.DXA}, columnWidths:[2500,7500],
  rows:[new TableRow({children:[celda("Abbreviation",{header:true,width:2500}),celda("Definition",{header:true,width:7500})]}), ...abrevFig]}));

children.push(h("Abbreviations used in Tables", HeadingLevel.HEADING_2));
const abrevTab = [
 ["ΔG","Gibbs free energy (used loosely here for Vina binding-affinity score, kcal/mol)"],
 ["CGenFF","CHARMM General Force Field"],
 ["ChEMBL","Chemical database of bioactive molecules (EMBL-EBI)"],
 ["COCONUT","COlleCtion of Open Natural prodUcTs"],
 ["HBA / HBD","Hydrogen-bond acceptor / donor"],
 ["LogP","Octanol\u2013water partition coefficient (lipophilicity)"],
 ["MW","Molecular weight (Da)"],
 ["PDB","Protein Data Bank"],
 ["QED","Quantitative Estimate of Drug-likeness"],
 ["SA score","Synthetic accessibility score (1\u201310, lower = easier to synthesize)"],
 ["SD","Standard deviation"],
 ["TPSA","Topological polar surface area (\u00c5\u00b2)"],
].map(([a,b])=>new TableRow({children:[celda(a,{width:2500}),celda(b,{width:7500})]}));
children.push(new Table({width:{size:10000,type:WidthType.DXA}, columnWidths:[2500,7500],
  rows:[new TableRow({children:[celda("Abbreviation",{header:true,width:2500}),celda("Definition",{header:true,width:7500})]}), ...abrevTab]}));

// ================= REFERENCES =================
children.push(new Paragraph({ children: [new PageBreak()] }));
children.push(h("References (Methodology)", HeadingLevel.HEADING_1));
children.push(p("Citations for data sources, software, and methodological frameworks used in this study. Bibliographic details reflect what was verified during the project (journal, volume, pages, and PMID/DOI where confirmed); exact author lists and titles should be cross-checked against the original source before final submission where marked \u201c(verify full citation)\u201d.", {italics:true}));

const referencias = [
"Alphonse, S., Djemil, A., Piserchio, A., & Ghose, R. (2022). Structural basis of Wzb\u2013Wzc recognition in the bacterial tyrosine phosphorylation cycle. Proceedings of the National Academy of Sciences, 119, e2201800119.",
"Bechet, E., et al. Identification of structural and molecular determinants of the tyrosine-kinase Wzc (PDB 3LA6). (verify full citation)",
"Bickerton, G. R., Paolini, G. V., Besnard, J., Muresan, S., & Hopkins, A. L. (2012). Quantifying the chemical beauty of drugs. Nature Chemistry, 4, 90\u201398.",
"Doublet, P., Vincent, C., Grangeasse, C., Cozzone, A. J., & Duclos, B. (1999). On the binding of ATP to the autophosphorylating protein, Ptk, of the bacterium Acinetobacter johnsonii. FEBS Letters, 445, 137\u2013143.",
"Ertl, P., & Schuffenhauer, A. (2009). Estimation of synthetic accessibility score of drug-like molecules. Journal of Cheminformatics, 1, 8.",
"Hamidian, M., et al. (2019). Genome analysis reveals the accessory genome flexibility of Acinetobacter baumannii AB307-0294. Microbial Genomics, 5, e000298.",
"Page, M. J., et al. (2021). The PRISMA 2020 statement: an updated guideline for reporting systematic reviews. BMJ, 372, n71.",
"Schake, P., Bolz, S. N., et al. (2025). PLIP 2025: introducing protein\u2013protein interactions to the Protein\u2013Ligand Interaction Profiler. Nucleic Acids Research, gkaf361.",
"Soulat, D., Jault, J. M., Geourjon, C., Gouet, P., Cozzone, A. J., & Grangeasse, C. (2007). Tyrosine-kinase Wzc from Escherichia coli possesses an ATPase activity regulated by autophosphorylation. FEMS Microbiology Letters, 274, 252\u2013259.",
"Standish, A. J., et al. (2012). Chemical inhibition of a bacterial protein tyrosine phosphatase suppresses capsule production. PLoS ONE, 7, e36312.",
"Tomaras, A. P., et al. (2010). Attachment and biofilm-related properties of Acinetobacter baumannii AB307-0294 and the role of ptk/ptp. Infection and Immunity, 78, 3993. PMID 20643860. (verify full citation)",
"Trott, O., & Olson, A. J. (2010). AutoDock Vina: improving the speed and accuracy of docking with a new scoring function, efficient optimization, and multithreading. Journal of Computational Chemistry, 31, 455\u2013461.",
"Vincent, C., Doublet, P., Grangeasse, C., Vaganay, E., Cozzone, A. J., & Duclos, B. (1999). Cells of Escherichia coli contain a protein-tyrosine kinase, Wzc, and a phosphotyrosine-protein phosphatase, Wzb. Journal of Bacteriology, 181, 3472\u20133477.",
"Yang, et al. (2021). Cryo-EM structure of the bacterial tyrosine kinase Wzc reveals octamer disassembly upon autophosphorylation. Nature Communications, 12, 4349. (verify full citation)",
"Rational targeting of the Wzb\u2013Wzc protein\u2013protein interaction in Acinetobacter baumannii. (2020). PMID 32402850. (verify full citation \u2014 direct computational antecedent, discussed in Introduction)",
"Classic metabolic control analysis summation-theorem reference. PMID 3996393. (verify full citation \u2014 supports Eqs. 7\u20138)",
"RDKit: Open-source cheminformatics software, https://www.rdkit.org (v2026.03.4 used in this study).",
"Pedregosa, F., et al. (2011). Scikit-learn: Machine Learning in Python. Journal of Machine Learning Research, 12, 2825\u20132830 (v1.8.0 used in this study).",
"Abramson, J., et al. (2024). Accurate structure prediction of biomolecular interactions with AlphaFold3. Nature, 630, 493\u2013500.",
];
referencias.forEach((r,i)=>{ children.push(p(`${i+1}. ${r}`)); });

fs.writeFileSync("/tmp/parte3_ok.txt","ok");
console.log("Abreviaturas y referencias añadidas. children:", children.length);

// ================= NEXT STEPS =================
children.push(new Paragraph({ children: [new PageBreak()] }));
children.push(h("Recommended Next Steps: CHARMM-GUI System Preparation", HeadingLevel.HEADING_1));

children.push(p("The complex file complejo_lig012_receptor.pdb (chain A = Wzc kinase domain, chain B = ligand lig_012/CHEMBL4297643, docked pose with corrected bond orders) is ready to upload. Module names below were verified against current CHARMM-GUI documentation and publications (2023\u20132024) before recommending them."));

children.push(h("Step 1 \u2014 Ligand parameterization", HeadingLevel.HEADING_2));
children.push(p("Go to charmm-gui.org \u2192 Input Generator \u2192 Ligand Reader & Modeler (charmm-gui.org/input/ligandrm). Upload the ligand alone (extract chain B, or paste the SMILES: Cc1cccc(/C=N/Nc2cc(N3CCOCC3)nc(OCCc3ccccn3)n2)c1). This generates CHARMM General Force Field (CGenFF) parameters. Check the CGenFF penalty scores carefully \u2014 the hydrazone/imine linkage flagged by the BRENK filter (see perfil_candidato_final.json) is an atypical functional group and may return a moderate-to-high penalty on some atoms/dihedrals; if so, those parameters warrant manual inspection or restraint during equilibration, not blind use."));

children.push(h("Step 2 \u2014 Protein + ligand complex processing", HeadingLevel.HEADING_2));
children.push(p("Go to Input Generator \u2192 PDB Reader & Manipulator. Upload complejo_lig012_receptor.pdb directly (this module can identify the non-standard HETATM ligand and either auto-generate CGenFF parameters or accept the ones generated in Step 1). Use the \u201cCheck/Correct PDB Format\u201d option if it flags anything. Since chain A is a soluble cytoplasmic domain (no transmembrane region \u2014 already excluded during structural modeling, \u00a72.6), do NOT route this through Membrane Builder."));

children.push(h("Step 3 \u2014 Solvation and system building", HeadingLevel.HEADING_2));
children.push(p("From the PDB Reader & Manipulator output, proceed to Solution Builder (not Membrane Builder, for the reason above). Recommended parameters, standard for a soluble globular protein\u2013ligand complex:"));
[
 "Water model: TIP3P (standard pairing with the CHARMM36m protein force field).",
 "Box type: rectangular or octahedral; edge distance \u2248 10\u201312 \u00c5 from the solute surface (enough to avoid self-interaction across periodic images without an excessive water count).",
 "Ions: NaCl at physiological concentration (\u2248 0.15 M), neutralizing system charge first.",
 "Force field: CHARMM36m (protein) + CGenFF (ligand, from Step 1).",
 "Output: select GROMACS as the target MD engine when prompted (CHARMM-GUI supports GROMACS, NAMD, AMBER, OpenMM, and others \u2014 make sure GROMACS is explicitly selected).",
].forEach(t => children.push(new Paragraph({ text: t, bullet: { level: 0 }, spacing: { after: 80 } })));

children.push(h("Step 4 \u2014 Equilibration and production", HeadingLevel.HEADING_2));
children.push(p("CHARMM-GUI's Solution Builder auto-generates a standard equilibration protocol (energy minimization \u2192 NVT \u2192 NPT with position restraints, gradually released) and production input files (.mdp for GROMACS). Use these as provided unless there is a specific reason to deviate; the restraint-release schedule is well-validated for this class of system."));

children.push(h("Things to bring back for the next session", HeadingLevel.HEADING_2));
[
 "The downloaded CHARMM-GUI archive (topology, coordinates, .mdp files) or at least a note of which options were selected at each step.",
 "The CGenFF penalty score report for the ligand (Step 1) \u2014 needed to assess parameter confidence before production runs.",
 "Confirmation of which MD engine output was generated (should be GROMACS, per project convention).",
].forEach(t => children.push(new Paragraph({ text: t, bullet: { level: 0 }, spacing: { after: 80 } })));

// ================= ANEXO: TABLAS ANCHAS EN LANDSCAPE =================
const landscapeChildren = [];
landscapeChildren.push(h("Appendix: Full-Width Supplementary Tables (Landscape)", HeadingLevel.HEADING_1));

landscapeChildren.push(h("Table S1 (full)", HeadingLevel.HEADING_2));
landscapeChildren.push(tablaDesdeJSON("datos_tableS1.json", 1350, 12));

landscapeChildren.push(new Paragraph({ children: [new PageBreak()] }));
landscapeChildren.push(h("Table S2 (full)", HeadingLevel.HEADING_2));
landscapeChildren.push(tablaDesdeJSON("datos_tableS2.json", 1400, 12));

landscapeChildren.push(new Paragraph({ children: [new PageBreak()] }));
landscapeChildren.push(h("Table S3 (full)", HeadingLevel.HEADING_2));
landscapeChildren.push(tablaDesdeJSON("datos_tableS3.json", 1290, 11));

landscapeChildren.push(new Paragraph({ children: [new PageBreak()] }));
landscapeChildren.push(h("Table S6 (full)", HeadingLevel.HEADING_2));
landscapeChildren.push(tablaDesdeJSON("datos_tableS6.json", 1550, 13));

// ================= DOCUMENTO FINAL =================
const doc = new Document({
  sections: [
    {
      properties: { page: { size: { width: PAGE_W_PORTRAIT, height: PAGE_H_PORTRAIT } } },
      headers: { default: new Header({ children: [new Paragraph({ children:[new TextRun({text:"Wzb/Wzc Wzc-kinase inhibitor \u2014 Supplementary Compendium", size:16, italics:true})], alignment: AlignmentType.RIGHT })] }) },
      footers: { default: new Footer({ children: [new Paragraph({ children:[new TextRun({children:[PageNumber.CURRENT]})], alignment: AlignmentType.CENTER })] }) },
      children: children,
    },
    {
      properties: { page: { size: { width: PAGE_H_PORTRAIT, height: PAGE_W_PORTRAIT }, orientation: PageOrientation.LANDSCAPE } },
      children: landscapeChildren,
    },
  ],
});

Packer.toBuffer(doc).then(buffer => {
  fs.writeFileSync("Compendio_Figuras_Tablas_WzbWzc.docx", buffer);
  console.log("Documento final escrito: Compendio_Figuras_Tablas_WzbWzc.docx");
});
