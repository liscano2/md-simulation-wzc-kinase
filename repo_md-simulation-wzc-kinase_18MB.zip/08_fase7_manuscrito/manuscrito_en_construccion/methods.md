# METHODS — living document
### Updated incrementally as each phase closes. Do not renumber sections once a phase is closed
### and audited; append new subsections instead, to keep cross-references in Results stable.

**Status: covers Phases 1–4 (validation sub-step) as of 2026-08-01.**

---

## 2. Materials and Methods

### 2.1. Target selection and study design

*[Carry-over from Compuerta 0/4, plan v2 — condense to 1 paragraph when finalizing]*

*Acinetobacter baumannii* strain AB307-0294 (revised genome assembly GenBank CP001172.2) was
selected because it is the only strain in which the capsule-regulatory tyrosine kinase/phosphatase
pair Wzc/Ptk (locus *ptk*) and Wzb/Ptp (locus *ptp*) has been functionally characterized, including
a transposon-insertion phenotype linking kinase activity to capsule production and virulence
[Tomaras et al., 2010]. A control-guided framework was used to determine, from first principles
rather than by assumption, which of the two enzymes — the kinase or the phosphatase — exerts
dominant control over the phosphorylation cycle, and to use that result to prioritize the
structural target for downstream virtual screening. The decision rule for assigning the
structural/docking target was pre-specified before the control-analysis result was obtained
(§2.5), to avoid post hoc rationalization of target choice.

### 2.2. Systematic identification of kinetic, structural, and pharmacological parameters

A scoping search, adapted from PRISMA 2020 guidance for a data-curation (not clinical) review
question, was conducted across five literature platforms (PubMed/PMC, ScienceDirect, PLOS One,
Nature/Nature Communications, PNAS) and one structural database (RCSB PDB/PDBe). Search terms
combined ("Wzb" OR "Wzc" OR "protein tyrosine phosphatase" OR "BY-kinase" OR "bacterial tyrosine
kinase" OR "low molecular weight protein tyrosine phosphatase") AND ("Acinetobacter baumannii" OR
"Escherichia coli" OR "Vibrio vulnificus" OR "Bacillus subtilis" OR capsul* OR exopolysaccharide OR
"colanic acid") AND (kinetics OR Km OR kcat OR structure OR crystal OR "solution structure" OR
"cryo-EM" OR inhibitor OR IC50 OR Ki), with no language or date restriction.

Records were screened by title/abstract, then by full text, against pre-specified inclusion
criteria: (i) numerical kinetic parameters (Km, kcat, or Vmax) for Wzb/Wzc or a direct family
ortholog, with stated assay conditions; (ii) a PDB-deposited 3D structure of Wzb, Wzc, or a direct
homolog; (iii) a chemical inhibitor with quantified potency against Wzb/Wzc or the functional
family; or (iv) molecular identity data for the *A. baumannii* Wzb/Wzc system. Reviews without
primary data, studies without extractable numerical or structural data, and duplicate reports of
the same dataset were excluded. The full protocol, search strings, screening flow with counts, and
a seven-domain adapted risk-of-bias/quality checklist are provided in **Supplementary Methods S1**
and **Table S1** (extraction table). A limitation is stated explicitly: searches were conducted via
a general web search engine directed at the platforms above rather than each platform's native
Boolean interface; Scopus, Web of Science, and Embase were not queried directly.

### 2.3. Molecular identity and sequence retrieval

Protein sequences for Ptp/Wzb and Ptk/Wzc of *A. baumannii* AB307-0294 were retrieved from NCBI
(accessions ATY45834.1 and ATY45835.1, respectively) by locus-tag and gene/product keyword
matching against the revised genome assembly, since the original locus tags reported by Tomaras et
al. (2010; ABBFA003460/ABBFA003461) were superseded by re-annotation (Hamidian et al., 2019) to
ABBFA_03430/ABBFA_03431. Catalytic motifs were located by pattern matching against the literature
consensus sequences rather than assumed positionally: the LMW-PTP active-site motif CX₅R for Wzb,
and the Walker A motif [AG]X₅GK[ST] and Walker B motif [hydrophobic]₄D for Wzc.

### 2.4. Kinetic model of the Wzb/Wzc phosphorylation cycle

Unlike a linear metabolic pathway, the Wzb/Wzc system is a two-state covalent-modification cycle
with a conserved moiety: Wzc interconverts between a non-phosphorylated form (*W*) and a
phosphorylated form (*Wp*), with **[*W*] + [*Wp*] = *Wzc*ₜₒₜₐₗ** held constant (Eq. 1), since no
synthesis or degradation occurs on the timescale of the phosphorylation cycle.

Letting *x* = [*Wp*] / *Wzc*ₜₒₜₐₗ denote the phosphorylated fraction, the autophosphorylation
(kinase) and dephosphorylation (phosphatase) rates were each modeled with pseudo-Michaelis–Menten
kinetics:

> **v_kin(x) = (V_max,kin · (1 − x) · Wzc_total) / (K_m,kin + (1 − x) · Wzc_total)**  — (Eq. 2)

> **v_phos(x) = (V_max,phos · x · Wzc_total) / (K_m,phos + x · Wzc_total)**  — (Eq. 3)

with the net rate of change:

> **dx/dt = v_kin(x) − v_phos(x)**  — (Eq. 4)

The steady state *x** was obtained by numerical integration of Eq. 4 to long time (SciPy
`solve_ivp`, BDF method, rtol = 1×10⁻⁹) rather than solved algebraically, so that non-convergence
or bistability would be detected rather than assumed away. At steady state, by definition,
v_kin(x*) = v_phos(x*) = **J**, the cycling flux (Eq. 5), which was verified numerically to agree
between the two rate expressions to within 1×10⁻⁶ in every reported result.

Parameters were sourced as follows (full trace in **Table S1**): the phosphatase parameters
(K_m,phos = 1 mM, k_cat,phos = 1.46 s⁻¹) were obtained directly from the full text of Vincent et al.
(1999), who report Km = 1 mM and Vmax = 4.6 µmol·min⁻¹·mg⁻¹ for *E. coli* Wzb against pNPP at pH
6.5, 37 °C, and state explicitly that this value equals that measured for the *A. johnsonii*
ortholog Ptp; k_cat was derived from Vmax and the reported 19-kDa mass of the His₆-Wzb fusion (Eq.
6: k_cat = V_max · MW / 60). The kinase parameters (K_m,kin = 1.1 mM, k_cat,kin ≈ 0.015 s⁻¹) were
obtained from Soulat et al. (2007): the apparent K_D for ATP binding to the *E. coli* Wzc
cytoplasmic domain (Ser447–Lys720) was reported directly (1.1 mM, identical for the phosphorylated
and non-phosphorylated forms); k_cat,kin was derived from the wild-type ATPase specific activity
(~30 nmol Pi·mg⁻¹·min⁻¹, read from a bar graph, not a printed value) and an estimated construct
mass of 30 kDa (274 residues × 110 Da). This derivation carries declared uncertainty (§4,
Limitations): it uses total ATP-hydrolysis activity as a proxy for productive
autophosphorylation, since the source study reports that Wzc is, *in vitro*, a more efficient
ATPase than kinase — a bias that, if present, would only strengthen the direction of the result
reported in §3.4, not weaken it. Doublet et al. (1999), the most direct kinetic study of the *A.
johnsonii* Ptk ortholog, was consulted specifically to seek a more direct value; it was found to
report only qualitative ATP-binding/autophosphorylation assays (Walker A/B mutagenesis), not
Michaelis–Menten constants, and is cited instead as independent confirmation that Walker A/B (not
the eukaryotic-kinase-like subdomain) is the functional ATP-binding site — consistent with the
mechanism established for *E. coli* Wzc.

### 2.5. Control analysis of the phosphorylation cycle

Flux-control coefficients (FCC) over the cycling flux *J*, and concentration-control coefficients
(CCC) over the steady-state level *x**, were computed for both enzymes by symmetric finite
perturbation (±1%) of each V_max in turn:

> **C^J_i = [ln J(1+δ) − ln J(1−δ)] / [ln(1+δ) − ln(1−δ)]**  — (Eq. 7, flux-control coefficient)

> **C^x_i = [x*(1+δ) − x*(1−δ)] / (2δ · x*₀)**  — (Eq. 8, concentration-control coefficient,
> non-logarithmic form, since x* can approach zero)

For a two-enzyme moiety-conserved interconversion cycle, two distinct summation theorems apply and
were verified numerically rather than assumed: **ΣC^J_i = 1** over the flux (as in a classical
linear pathway) and **ΣC^x_i = 0** over the level (the standard scaling-invariance property of a
conserved-moiety cycle: proportionally scaling both V_max values leaves x* unchanged). Global
sensitivity of the flux- and level-control ranking to parameter uncertainty was assessed by
Sobol total-order indices (SALib, N = 256–1024, ±50% bounds on each V_max/K_m).

Because the resulting flux-control asymmetry (§3.4) was large, a **breakpoint analysis** was
additionally performed: k_cat,kin was swept over a wide multiplicative range and the value at which
C^J_kinase = 0.5 (i.e., control equally shared) was located by root-finding (Brent's method) on
C^J_kinase(k_cat,kin) − 0.5 (Eq. 9). This was done because a ±50% global sensitivity analysis cannot,
by construction, test robustness to an asymmetry of the magnitude observed; the breakpoint
expresses instead how large an error in the literature-derived k_cat,kin would have to be to
overturn the qualitative conclusion.

A pre-specified decision rule (fixed before the control-analysis result was obtained) assigned the
structural/docking target: if C^J_kinase − C^J_phosphatase ≥ 0.15, the kinase's cytoplasmic domain
was selected; if ≤ −0.15, the phosphatase; otherwise, both, with the final choice made on
docking-pose quality (Phase 4).

### 2.6. Structural modeling of the Wzc kinase domain

The full-length Wzc sequence (727 residues, ATY45835.1) was submitted to AlphaFold Server
(AlphaFold3) as a single chain. Because AlphaFold Server's output terms of use prohibit use of the
resulting model "in connection with any automated system that predicts the binding or interaction
of the protein with ligands or peptides, including, but not limited to, Glide or AutoDock," the
model reported here is used only for domain boundary definition, quality assessment, and structural
superposition (§2.7); a separate, unrestricted structure (obtained independently, see §2.7) is used
as the actual docking receptor where required by that restriction. Model quality was assessed from
the per-residue pLDDT (Cα B-factor field of the output mmCIF) and the full predicted aligned error
(PAE) matrix, not from the global pTM alone, since pTM for a multi-domain protein connected by a
flexible linker conflates intra-domain fold confidence with inter-domain orientation uncertainty;
both were therefore examined separately for the transmembrane region, the periplasmic region, and
the cytoplasmic kinase domain.

The cytoplasmic kinase domain was excised from the full-length model using a boundary defined by
literature precedent rather than heuristic truncation: Yang et al. (2021) define the *E. coli* Wzc
kinase domain as residues Arg452–Lys701, with the Walker A lysine (Lys540) 88 residues downstream
of the domain start and 161 upstream of its end. The Walker A motif of the *A. baumannii* sequence
was located independently by pattern search (§2.3; found at position 539, motif GPSPEVGKS — note a
spacer correction from an initial X₄ to the literature-correct X₅ pattern), and the same relative
offsets were applied (539 − 88 = 451; 539 + 161 = 700), yielding a 250-residue domain (451–700).
The C-terminal tyrosine-rich tail (701–727), predicted with low confidence (mean pLDDT 63.3 vs.
93.5 for the retained domain), was excluded from the docking receptor, consistent with its
expected intrinsic flexibility as the site of interphosphorylation.

### 2.7. Structural validation against experimental templates

AlphaFold3 reported four structural templates used during modeling: the *E. coli* Wzc cryo-EM
octamer (PDB 7NHR and a related entry, 7NI2) and, unexpectedly, two crystal structures not
previously identified in the Phase 1 search — PDB 3LA6 (the isolated *E. coli* Wzc kinase domain,
residues 447–720, crystallized as the catalytically-inactive Walker-A K540M mutant in complex with
ADP) and PDB 3CIO (Etk, the *E. coli* K30 Wzc homolog). 3LA6 is itself the homology template Yang et
al. (2021) used to build the kinase-domain portion of 7NHR, establishing an independent, mutually
consistent chain of structural evidence across three sources.

The *A. baumannii* kinase domain (451–700) was superimposed onto 3LA6 chain A by first performing a
global pairwise sequence alignment (Biopython `PairwiseAligner`, BLOSUM62, affine gap penalties
−10/−0.5), then superimposing only the Cα atom pairs the alignment identified as ungapped
correspondences (Biopython `Superimposer`) — residue numbers were deliberately not used directly for
correspondence, since the two proteins differ in length and numbering. The ADP-contacting pocket in
3LA6 was defined as all protein residues with any atom within 4.5 Å of any ADP atom
(`Bio.PDB.NeighborSearch`), then mapped onto the corresponding *A. baumannii* residues via the same
alignment-derived correspondence, yielding the docking-site residue list used in §2.8/§3.

### 2.8. Molecular docking protocol and validation

Docking was performed with AutoDock Vina, with receptor and ligand prepared by Meeko. A search box
of 25×25×25 Å centered on the ADP centroid (in the coordinate frame established by the §2.7
superposition) was used throughout. Protocol validity was assessed by redocking the native ADP
ligand (bond orders assigned from its canonical SMILES via
`AllChem.AssignBondOrdersFromTemplate`, applied to the crystallographic coordinates so the native
pose was preserved) into two receptors: (i) the actual 3LA6 crystal structure, as a positive
control isolating ligand-preparation and search-algorithm correctness from receptor-model
accuracy; and (ii) the *A. baumannii* homology/AlphaFold-derived kinase domain, the actual
cross-docking test of interest. Success was defined by the standard criterion of heavy-atom RMSD
< 2 Å between the top-scoring pose and the native crystallographic pose.

Redocking into the *A. baumannii* receptor failed this criterion in two independent runs (RMSD =
4.08 Å and 5.76 Å; different machines, different random seeds), while redocking into the native
3LA6 receptor succeeded (RMSD = 0.77 Å), isolating the source of discrepancy to the receptor model
rather than to ligand preparation or the search algorithm. Receptor flexibility (Vina flexible
side chains for all 18 pocket residues) was attempted as a remedy but could not be completed: an
adequately sized search box for the full spatial extent of the flexible side chains (calculated
post hoc at ≈41×31×25 Å, versus the 25×25×25 Å box used) exceeded the computational resources
available, and the investigation of flexible redocking was closed by decision, with the cause
documented rather than left unresolved (**Table S-Docking-1**, Supplementary Methods).

Given this, the following accepted strategy was adopted for all subsequent docking, and is stated
here as an explicit methodological choice rather than discovered post hoc: **the docking site is
defined by the structural-homology mapping of §2.7, independently of redocking performance**, and
rigid-receptor Vina scores are used for **relative ranking among candidate compounds**, not as
evidence of exact binding-mode recovery — a standard and defensible practice in virtual screening
when the site itself is independently validated. In support of this, both independent rigid
redocking runs correctly anchored the ADP phosphate moiety on the literature-identified Walker A
backbone amides (Glu543, Lys546, Ser547; H-bond distances 2.2–2.4 Å), while the adenine moiety
displaced toward residues outside the homology-mapped pocket (Ala672, Ile700, Arg673) — indicating
partial, chemically coherent recovery of the conserved phosphate-binding subsite even where the
full pose was not reproduced. This discrepancy is stated as a limitation in §4 and is not
presented as resolved.

Functional-group composition of the 50 cluster representatives was assessed by SMARTS
substructure matching (RDKit): hydroxyl ([#6][OX2H1]), halogen ([F,Cl,Br,I]), carboxylic acid
([CX3](=O)[OX2H1]), amine ([NX3] excluding amide, imine, nitrile, and diazo nitrogens), ether
([#6][OX2][#6]), and amide ([NX3][CX3](=[OX1])) were matched by pattern; aromatic ring content
was assessed via RDKit's aromatic-ring count rather than a SMARTS pattern, for robustness across
fused/heteroaromatic systems.

### 2.10. Rigid-receptor docking of the candidate library

Following the accepted docking strategy (§2.8), all 66 compounds of the hybrid candidate library
(§3.8) were docked as rigid ligands against the fixed receptor and box already used for
protocol validation (center 12.760, 3.512, −58.336 Å; 25×25×25 Å), using AutoDock Vina v1.2.7
via its Python API, with ligands prepared by Meeko v0.7.1 (3D embedding: RDKit ETKDG, randomSeed=42;
geometry optimization: MMFF94). Three compounds (4.5%) initially failed ligand preparation due to
multi-fragment structures (counter-ions/salts); the largest fragment by heavy-atom count was
retained for these three prior to re-preparation, a standard salt-stripping step before docking.

Each of the 66 ligands was docked in three independent replicates (exhaustiveness=2, 3 poses per
run; independent Vina objects instantiated with distinct random seeds 111/222/333 — reduced
exhaustiveness relative to the exhaustiveness=16 used for protocol validation redocking, §2.8, was
necessary for computational tractability across 198 total runs, and is declared as a limitation:
absolute affinity values should be interpreted as a coarse relative ranking, not as converged
estimates). Mean binding affinity and standard deviation across the three replicates were computed
per compound; the single most favorable pose across replicates ("best hit") was also recorded.

An additional structural-relevance filter, beyond affinity ranking alone, was applied to the top 10
compounds by mean affinity: the docked pose from the best-scoring replicate of each was analyzed
for direct contact (any heavy atom within 4.5 Å) with the 18-residue pocket defined by
structural homology (§3.6), and specifically with the 8-residue Walker A/B subset. This step was
motivated by the redocking finding (§3.7) that binding affinity alone does not guarantee that a
pose engages the validated catalytic site. Quantitative estimate of drug-likeness (QED) (Bickerton
et al., 2012) and synthetic accessibility score (SA score) (Ertl & Schuffenhauer, 2009) were
computed for the top 10 as secondary, drug-development-relevant criteria (RDKit `QED` module;
`sascorer.py`, RDKit Contrib). Structural alerts were additionally screened against RDKit's
built-in PAINS, BRENK, NIH, and ZINC filter catalogs for the final selected candidate.

Protein–ligand interactions for the selected candidate's docked pose were characterized with the
Protein–Ligand Interaction Profiler (PLIP) v3.0.1 (Schake et al., 2025), applied to the docked
complex (receptor + best-pose ligand, both as explicit heavy atoms with corrected bond orders
transferred from the canonical SMILES via `AllChem.AssignBondOrdersFromTemplate`, preserving the
docked 3D coordinates).

**Software versions and access dates** (for reproducibility): AutoDock Vina v1.2.7; Meeko v0.7.1;
RDKit v2026.03.4; scikit-learn v1.8.0; PLIP v3.0.1; pandas v3.0.2; matplotlib v3.10.8. ChEMBL data
accessed via `chembl_webresource_client` on 2026-08-01. COCONUT data (version "August 2026", lite
2D SDF release) downloaded 2026-08-01 from coconut.naturalproducts.net/download. PubChem
Drug-Names.tsv.gz (ftp.ncbi.nlm.nih.gov/pubchem/Compound/Extras/) was unavailable at time of
assembly (persistent HTTP 503) and did not contribute to the final library. DrugBank academic
bulk downloads were suspended platform-wide as of 2026-08-01 (confirmed by direct inspection of
go.drugbank.com/releases/latest) and did not contribute to the final library.

---
## Change log (for internal tracking, remove before submission)
- 2026-08-01: Initial version. §2.1–2.5 drafted from Phases 1–2. §2.6–2.8 pending Phase 3–4 content.
- 2026-08-01 (later): §2.6–2.8 completed from Phase 3 (AlphaFold3 modeling, structural
  superposition, pocket definition) and Phase 4 validation sub-step (rigid/flexible redocking,
  accepted docking strategy).
- 2026-08-02: Added functional-group SMARTS methodology (§2.9, supporting Figure 5, panel D).
- 2026-08-02 (later): §2.10 added — full candidate library docking (66 compounds, 3 replicates),
  structural-relevance filter, QED/SA scoring, PLIP interaction analysis, and full software
  version/access-date reporting.
