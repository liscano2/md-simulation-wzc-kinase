# RESULTS — living document
### Cross-references assume the equation/table numbers in methods.md. Figure numbers below are
### provisional (assigned in order of first appearance) — do not renumber until the figure set is
### final; append new figures at the end of the sequence instead.

**Status: covers Phases 1–4 (validation sub-step) as of 2026-08-01.**

---

## 3. Results

### 3.1. Systematic identification of parameters yielded 14 primary sources across five categories

Of 80 records identified across 11 search queries, 22 duplicates were removed, 58 were screened by
title/abstract, and 30 were excluded as off-topic after verification (unrelated crystal structures
sharing only genus/species, patents, unrelated strain genome announcements). Of 28 full-text
reports assessed, **14 met inclusion criteria** through the formal systematic search (**Figure 1,
PRISMA flow diagram; Table S1, extraction table, entries F01–F14**), spanning identity/genomic data
(n=2), structure (n=6), kinetics (n=4), pharmacology (n=1), and a direct computational antecedent
(n=1).

Four further sources were identified during Phases 2–3 through mechanisms distinct from, and
reported separately from, the formal search above, to avoid overstating the systematic search's
apparent yield: two (Soulat et al., 2007; Doublet et al., 1999 — extraction table entries F15–F16)
were located by a targeted follow-up search after the formal review left the kinase turnover number
unresolved (§3.2); two (PDB 3LA6, 3CIO — entries F17–F18) were identified opportunistically via
AlphaFold3's own template selection during structural modeling (§3.5) and were not products of the
literature search process depicted in Figure 1. The complete, 18-entry extraction table (**Table
S1**) documents provenance and inclusion pathway for every entry.

*[FIGURE 1 → prisma_diagrama.png — depicts only the 14-source formal search (F01–F14); F15–F18 are
correctly excluded from this diagram and described narratively above and in Table S1]*

### 3.2. Kinetic parameters: direct measurements for the phosphatase, a single indirect proxy for the kinase

**Table 1** summarizes the kinetic parameters used in the model of §2.4, with provenance and
approximation level stated for each. The phosphatase parameters (K_m = 1 mM, k_cat = 1.46 s⁻¹) are
a direct literature measurement, explicitly reported as identical between the *E. coli* and *A.
johnsonii* orthologs. The kinase parameters combine one direct measurement (apparent K_D for ATP,
1.1 mM) with one multiply-approximated derived value (k_cat ≈ 0.015 s⁻¹, from ATPase proxy
activity, graph-read source value, and an estimated construct mass) — a 97-fold difference in
turnover number between the two enzymes that is the central quantitative input to §3.4.

**[TABLE 1 — Kinetic parameters of the Wzb/Wzc phosphorylation cycle]**

| Parameter | Enzyme | Value | Basis | Source |
|---|---|---|---|---|
| K_m | Wzb (phosphatase) | 1 mM (pNPP) | Direct | Vincent et al. 1999 |
| k_cat | Wzb (phosphatase) | 1.46 s⁻¹ | Derived from Vmax + MW (Eq. 6) | Vincent et al. 1999 |
| K_D (ATP) | Wzc (kinase) | 1.1 mM | Direct | Soulat et al. 2007 |
| k_cat | Wzc (kinase) | ≈0.015 s⁻¹ | Derived, multiple approximation layers (§2.4) | Soulat et al. 2007 |

### 3.3. Molecular identity of Wzb/Wzc in *A. baumannii* AB307-0294

Sequences were resolved by keyword matching after locus-tag matching failed (§2.3), revealing that
genome re-annotation (Hamidian et al., 2019) had changed the locus tag format and numbering from
the values reported by Tomaras et al. (2010) (ABBFA003460/003461 → ABBFA_03430/03431). The
resolved proteins are Ptp/Wzb (ATY45834.1, 142 aa) and Ptk/Wzc (ATY45835.1, 727 aa). The LMW-PTP
catalytic motif (CX₅R) was confirmed present in Wzb by direct sequence inspection (C10-I-G-N-I-C15-
R16).

### 3.4. Control analysis identifies the kinase, not the phosphatase, as the dominant flux-controlling node

At steady state, the model (Eqs. 1–6) predicts a phosphorylated fraction x* = 0.0049 (≈0.5% of
total Wzc phosphorylated) and cycling flux J = 0.0071 (arbitrary units, normalized Wzc_total = 1).
Flux-control coefficients (Eq. 7) were **C^J_kinase = +0.997, C^J_phosphatase = +0.003** (ΣC^J =
1.0000, confirming Eq. 7's summation theorem numerically). Concentration-control coefficients over
the level (Eq. 8) were **C^x_kinase = +1.002, C^x_phosphatase = −1.002** (ΣC^x = −0.0001,
confirming the conserved-moiety summation theorem). Sobol total-order indices under ±50%
parameter uncertainty were consistent with the point estimate for flux control (ST_kinase = 1.000,
ST_phosphatase = 0.000) and markedly less asymmetric for level control (ST_kinase = 0.461,
ST_phosphatase = 0.576) — flux control and level control diverge for this cycle, consistent with
H3 (a mechanistic hypothesis stated *a priori*, §2.1 of the working plan: that the biologically
regulated quantity may be the cycling flux rather than the steady-state phosphorylation level).

Because this asymmetry (C^J_kinase ≈ 0.997) lies far outside what a ±50% Sobol analysis can
meaningfully stress-test, a breakpoint analysis (Eq. 9) was performed: control becomes evenly
shared (C^J_kinase = 0.5) only when k_cat,kin is increased **≈102-fold**, to 1.53 s⁻¹ — i.e., a
two-order-of-magnitude error in the literature-derived kinase turnover number would be required to
overturn the qualitative conclusion (**Figure 2**). Independent qualitative support is noted: Yang
et al. (2021) describe *E. coli* Wzc as expected to "constantly cycle between phosphorylated
monomers and dephosphorylated octamers," consistent with a phosphatase-dominated resting state and
a kinase-limited transition — matching the low predicted x* independently of the quantitative model.

Per the pre-specified decision rule (§2.5), C^J_kinase − C^J_phosphatase = +0.995 ≥ 0.15 assigns the
kinase's cytoplasmic domain as the structural/docking target for Phases 3–4.

*[FIGURE 2 → to be generated: breakpoint sweep plot, C^J_kinase vs. k_cat,kin multiplier, log-x
axis, with the literature value and the breakpoint marked]*

### 3.5. AlphaFold3 model of the Wzc kinase domain: high local confidence at the catalytic site despite moderate global pTM

The full-length AlphaFold3 model (pTM = 0.76, uniform across 5 generated models, no steric clashes)
showed a global confidence metric substantially lower than warranted by the region of interest: PAE
analysis attributed this to uncertain relative orientation between the cytoplasmic kinase domain
and the transmembrane/periplasmic region (inter-domain PAE 9.8–15.9 Å) rather than to poor
intra-domain fold quality (intra-kinase-domain PAE = 4.8 Å; Walker A/B region PAE = 1.7 Å) —
consistent with the biologically expected flexibility of this linker, since kinase-domain mobility
relative to the rest of Wzc is mechanistically required for octamer disassembly (Yang et al.,
2021). Per-residue pLDDT within the retained 250-residue domain (451–700) averaged 93.5 (96% of
residues > 70), with the catalytic Walker A (mean 95.9, min 91.9) and Walker B (mean 96.4, min
93.7) regions among the most confidently predicted in the entire structure; the excluded
C-terminal tyrosine-rich tail (701–727) averaged 63.3, consistent with its expected intrinsic
disorder (**Figure 3**).

*[FIGURE 3 → to be generated/assembled: (A) full-length model colored by pLDDT; (B) PAE heatmap
with domain boundaries annotated; (C) per-region pLDDT bar summary — source data in
04_fase3_estructura/]*

### 3.6. The *A. baumannii* kinase domain conserves the *E. coli* fold, with the ADP pocket more conserved than the domain average

Structural superposition against the isolated *E. coli* kinase-domain crystal structure (PDB 3LA6)
yielded **RMSD = 1.72 Å over 234 aligned Cα pairs**, at 46.6% sequence identity in the aligned
region — within the range considered reliable for structure-based docking of a homology/AI-derived
model. Of the 20 3LA6 residues contacting ADP (≤4.5 Å), 18 mapped within the aligned region,
defining the *A. baumannii* docking-site residue set: **481, 482, 483, 484, 487, 488, 496, 498,
499, 541, 542, 543, 544, 545, 546, 547, 548, 575**. Sequence identity within this pocket (50%, 9/18
residues identical) exceeded the domain-wide average (46.6%), consistent with functional
conservation of the catalytic site under purifying selection (**Figure 4**). PDB 3LA6 was noted to
be the Walker-A K540M catalytically-inactive mutant (used to trap ADP crystallographically without
turnover); the corresponding *A. baumannii* residue (Lys546) is intact in the present model, which
was predicted from the wild-type sequence.

*[FIGURE 4 → Figura4_superposicion_3D.png, rendered — A. baumannii domain (blue) superimposed on
3LA6 chain A (gray, transparent), ADP shown as sticks, pocket residues in orange]*

As an independent cross-check using a different algorithm, PyMOL's iterative all-atom structural
alignment (`align`, with outlier rejection over 5 cycles) converged to RMSD = 0.72 Å over a
best-fit core of 1168/1557 atoms — consistent with, and lower than, the sequence-alignment-guided
Cα-only RMSD (1.72 Å, 234 pairs, no outlier exclusion) reported above; the lower value reflects
exclusion of peripheral, more poorly-superimposing loop regions, as expected. Both methods agree
that the fold is well conserved.

### 3.7. Rigid-receptor redocking recovers the phosphate subsite but not the adenine subsite; flexible redocking was not computationally tractable

Redocking of the native ADP ligand failed the RMSD < 2 Å success criterion when docked into the
*A. baumannii* model in two independent runs (RMSD = 4.08 Å, this study; RMSD = 5.76 Å, independent
run, different machine/seed), while succeeding when docked into the native 3LA6 receptor as a
positive control (RMSD = 0.77 Å), isolating the discrepancy to receptor-model side-chain geometry
rather than to docking-protocol validity. In both independent *A. baumannii* redocking runs, the
ADP phosphate moiety correctly engaged the literature-predicted Walker A backbone amides (Glu543,
Lys546, Ser547; H-bond distances 2.2–2.4 Å in the user-run interaction analysis), while the
adenine moiety displaced toward Ala672, Ile700, and Arg673 — residues outside the homology-mapped
pocket, with Ile700 at the C-terminal boundary of the modeled domain (**Table 2**). Flexible-
side-chain redocking, attempted as a remedy, could not be completed: the spatial extent required
for the 18 mobile side chains (≈41×31×25 Å) exceeded the fixed 25×25×25 Å search box, and available
computational resources did not permit the larger box; this line of investigation was closed by
decision, with cause documented (Supplementary Methods, **Table S-Docking-1**) rather than left
unexplained. The accepted docking strategy for subsequent candidate screening (§2.8) follows from
this result.

**[TABLE 2 — ADP redocking interactions in the *A. baumannii* rigid receptor (independent user run)]**

| Residue | Distance (Å) | Interaction type | In homology-mapped pocket? |
|---|---|---|---|
| Gln487 | 2.06 | H-bond (ribose) | Yes |
| Lys546 (backbone NH) | 2.28 | H-bond (phosphate) | Yes |
| Ala672 (backbone) | 2.23 | H-bond | No |
| Glu543 (backbone NH) | 2.41 | H-bond (phosphate) | Yes |
| Ser547 | 2.44 | H-bond (phosphate) | Yes |
| Ile700 (backbone) | 3.02 | H-bond | No — domain C-terminal boundary |
| Arg673 | 4.34 | Pi-alkyl | No |

### 3.8. Compound library assembly and representative candidate selection

The screening library was assembled from ChEMBL (mechanism-of-action search for kinase
inhibitors, yielding 29 unique compounds, 25 with retrievable structures) and COCONUT (natural
products, filtered to the 150–600 Da range and randomly subsampled to 3,000 entries prior to
downstream filtering); DrugBank was unavailable throughout data collection (platform-wide pause
of academic downloads, confirmed by direct inspection of the DrugBank release page), and PubChem's
curated drug-name cross-reference (Drug-Names.tsv.gz) could not be retrieved due to a persistent
server-side error (HTTP 503) at the time of assembly. After deduplication by canonical structure
(not by text string) and PAINS filtering (260 compounds removed, 8.6%), the combined library
comprised 2,346 compounds (2,322 COCONUT, 24 ChEMBL).

Compounds were further evaluated against five independent drug-likeness rule sets (Lipinski,
Ghose, Veber, Egan, Muegge), computed locally from RDKit descriptors rather than submitted to the
SwissADME web service, since the latter has no public API and is not designed for bulk
programmatic submission of thousands of compounds (a documented limitation confirmed in user
reports of the service rejecting large batch submissions). Of the 2,346 compounds, 1,261 (53.7%)
passed all five rules and 1,878 (80.1%) passed at least four.

To reduce the 1,878-compound candidate set to a computationally tractable, chemically
representative subset for docking, principal component analysis (PCA; six standardized
descriptors: MW, LogP, HBD, HBA, TPSA, rotatable bonds) followed by k-means clustering was applied,
following the same approach used in a related study by the authors on efflux-pump inhibitors in
*Elizabethkingia anophelis*. The mathematical elbow occurred at k=7; a practical value of k=50 was
used instead to prioritize chemical space coverage over strict elbow-optimality, consistent with
that precedent. The two leading principal components explained 71.7% of total variance (PC1
47.4%, PC2 24.3%). For each cluster, the real compound closest to the centroid (not the
mathematical centroid itself) was retained as the representative.

Because the input imbalance (2,322 COCONUT vs. 24 ChEMBL) propagated into the clustering result —
only 2 of 50 cluster representatives were of ChEMBL origin — a hybrid selection was used instead of
the clustering output alone: **all** ChEMBL compounds passing ≥4/5 drug-likeness rules (n=18) were
retained regardless of cluster assignment, combined with the 48 COCONUT cluster representatives,
yielding a final **66-compound** candidate set for Phase 4 docking. This preserves both the natural
product chemical diversity (via clustering) and the ATP-pocket-focused kinase-inhibitor chemotype
coverage that motivated the ChEMBL search in the first place — a rationale that would have been
lost had the clustering output alone been used as the final candidate set (**Figure 5**).

*[FIGURE 5 → Figura5_espacio_quimico_compuesta.png — four-panel composite: (A) correlation
matrix of seven molecular descriptors (MW, LogP, HBD, HBA, TPSA, rotatable bonds, ring count);
(B) elbow method on the real project data (mathematical elbow k=7, practical k=50 marked); (C)
PCA chemical space (PC1 47.4%, PC2 24.3% variance) with the 50 cluster representatives marked;
(D) functional-group composition of the 50 representatives]*

Panel A shows the expected strong correlation between TPSA and HBA (r=0.84, consistent with
polar-surface area being driven largely by heteroatom hydrogen-bond acceptors), justifying the
use of PCA to remove redundancy before clustering. Functional-group analysis of the 50
representatives (**Figure 5D**) shows a composition dominated by ether (38/50), hydroxyl (30/50),
and aromatic-ring-containing (27/50) scaffolds, with amide (17/50) and amine (8/50) groups less
frequent, a carboxylic acid group in a minority (5/50), and **no halogenated compounds** — a
profile consistent with the library's natural-product-dominated composition (COCONUT), in
contrast to synthetic/drug-like libraries where halogenation is common.

### 3.9. Rigid docking of the 66-compound candidate library identifies a lead with complete Walker A/B engagement

All 66 hybrid-library compounds were docked in triplicate against the validated pocket (198
total runs; **Table S6**, full results). Mean affinities ranged from −4.9 to −10.2 kcal/mol
(median −7.7 kcal/mol). The top-10 compounds by mean affinity (**Table 2**) were dominated by
COCONUT-derived natural products (9/10); replicate standard deviations were generally small
(0.005–0.29 kcal/mol), indicating stable convergence of the rigid search under the reduced
exhaustiveness used for full-library screening (§2.10).

Because affinity alone does not guarantee engagement with the validated catalytic site (§3.7),
each top-10 pose was checked for direct contact with the 18-residue homology-defined pocket and
the 8-residue Walker A/B subset. This revealed a clear dissociation between affinity rank and
structural relevance: the top-ranked compound by affinity (lig_042, COCONUT, −10.24 kcal/mol)
contacted only 11/18 pocket residues and 4/8 Walker A/B residues, whereas the 10th-ranked
compound by affinity, **lig_012** (ChEMBL, CHEMBL4297643, −9.02 ± 0.09 kcal/mol), contacted
**14/18 validated pocket residues and all 8/8 Walker A/B residues** — the only compound in the
top 10 to fully engage this catalytic subsite (**Figure 6B**). lig_012 originates from the
ChEMBL kinase-inhibitor-mechanism search (§3.8), the source specifically included to provide
ATP-pocket-relevant chemotypes; its selection as the lead candidate over higher-scoring
natural products is therefore consistent with, rather than contrary to, the library's original
design rationale.

lig_012 (MW 418.5 Da, LogP 3.08, TPSA 84.8 Å², QED 0.44, synthetic accessibility score 2.60,
passing 5/5 drug-likeness rules) was selected as the lead candidate on this combined structural
and physicochemical basis (**Figure 6C**). Structural alert screening (RDKit BRENK catalog)
flagged an imine/hydrazone-type linkage (aryl-CH=N–NH-aryl) as a reactive-group concern; no
PAINS, NIH, or ZINC alerts were raised. This alert is reported rather than concealed and should
be weighed against the compound's otherwise favorable profile in any future prioritization for
synthesis or testing — it does not, by itself, disqualify the compound at this in silico stage,
but flags a specific liability for medicinal-chemistry follow-up (e.g., hydrazone hydrolytic
stability).

Protein–ligand interaction analysis (PLIP) of the docked lig_012 pose identified 5 hydrogen
bonds (Gln487, 2.59 Å; Glu543, 2.16 and 2.48 Å — two distinct contacts; Gly545, 2.96 Å; Lys546,
2.44 Å), 3 hydrophobic contacts (Val481, Phe548, Tyr575), and 1 π-stacking interaction (Phe548,
centroid distance 4.55 Å) (**Table S5**, full PLIP output). Notably, Glu543 and Lys546 are the
same Walker A backbone-amide phosphate-anchoring residues independently identified as
functionally engaged in both prior ADP redocking experiments (§3.7), providing a second,
independent line of evidence that this subsite is consistently and correctly engaged across
different ligands and docking runs.

*[FIGURE 6 → Figura6_resultados_docking.png — four-panel composite (no embedded title,
caption below): (A) top-10 ranking by mean affinity ± SD, lig_012 marked; (B) affinity vs.
real pocket-residue contact count, marker size = Walker A/B contacts, color = QED; (C) 2D
structure of the selected candidate; (D) PLIP-detected interaction distances for the selected
candidate's docked pose]*

**Figure 6 caption (for manuscript):** *Docking screening results for the 66-compound hybrid
candidate library against the validated Wzc kinase-domain pocket. (A) Top-10 compounds ranked
by mean rigid-docking affinity (three independent replicates; error bars = SD). (B) Real
structural pocket engagement, not affinity alone, differentiates candidates: lig_012 (red)
contacts the most validated pocket residues and all eight Walker A/B residues despite ranking
10th by affinity. (C) Two-dimensional structure of the selected lead, lig_012 (ChEMBL
CHEMBL4297643). (D) PLIP-detected non-covalent interactions and distances for the docked pose of
lig_012, dominated by hydrogen bonds to the Walker A phosphate-binding backbone (Glu543,
Lys546).*

A receptor–ligand complex PDB file (lig_012 docked pose, corrected bond orders, combined with
the validated receptor domain) was prepared for downstream MD system building in CHARMM-GUI
(hydration, ion placement, and simulation-box parameterization to be performed by the user).

---
## Change log (for internal tracking, remove before submission)
- 2026-08-01: Initial version, §3.1–3.7 drafted covering Phases 1–4 (validation sub-step).
  Figures 1–4 flagged as pending final generation/assembly; source files identified in each case.
- 2026-08-02: §3.8 added — compound library assembly (ChEMBL+COCONUT, 2,346 compounds),
  local drug-likeness screening (5 rules, RDKit), PCA/k-means representative selection, and the
  hybrid selection correcting for ChEMBL under-representation (final: 66 compounds for docking).
- 2026-08-02 (later): Figure 5 rebuilt as a four-panel composite (correlation matrix, elbow
  method, PCA space, functional groups) mirroring the format of a related prior study by the
  authors; real functional-group counts added to the narrative.
- 2026-08-02 (later still): §3.9 added — full 66-compound docking (198 runs), structural
  relevance filter (real pocket/Walker-A/B contact) overriding raw affinity rank, lead candidate
  (lig_012) selected and characterized (QED, SA score, structural alerts, PLIP interactions).
