# 3. Results

## 3.1. A systematic search yielded 14 primary sources across five evidence categories

Of 80 records identified across 11 search queries, 22 duplicates were removed and 58 were screened by title and abstract. Thirty records were excluded as off-topic after individual verification, comprising unrelated crystal structures sharing only genus and species, patents, and unrelated strain genome announcements. Of the 28 full-text reports assessed, 14 met the inclusion criteria through the formal systematic search (**Figure 1**; **Table S1**, entries F01–F14). These spanned identity and genomic data (n = 2), structure (n = 6), kinetics (n = 4), pharmacology (n = 1), and one direct computational antecedent (n = 1).

Four additional sources were identified during Phases 2 and 3 through mechanisms distinct from the formal search. They are reported separately from it, so as not to overstate the apparent yield of the systematic review. Two of them (entries F15–F16) were located by a targeted follow-up search after the formal review left the kinase turnover number unresolved (Section 3.2). The other two (PDB 3LA6 and 3CIO; entries F17–F18) were identified opportunistically through AlphaFold3 template selection during structural modeling (Section 3.5). Neither pair was a product of the search process depicted in Figure 1. The complete 18-entry extraction table (**Table S1**) documents the provenance and inclusion pathway of every source, and the corresponding quality appraisal is given in **Table S2**.

## 3.2. Kinetic parameterization rests on direct phosphatase measurements and a single indirect kinase proxy

**Table 1** summarizes the kinetic parameters used in the ordinary differential equation (ODE) model, together with the provenance and approximation level of each value. The phosphatase parameters — Michaelis constant (K_m) of 1 mM and catalytic constant (k_cat) of 1.46 s⁻¹ — derive from a direct enzymatic measurement, explicitly reported as indistinguishable between the *Escherichia coli* and *Acinetobacter johnsonii* orthologs. The kinase parameters combine one direct measurement, the apparent dissociation constant for adenosine triphosphate (ATP) of 1.1 mM, with one multiply approximated derived value, k_cat ≈ 0.015 s⁻¹. The latter was obtained from a proxy ATPase activity, a graph-read source value, and an estimated construct mass.

The resulting 97-fold difference in turnover number between the two enzymes is the central quantitative input to the control analysis in Section 3.4. Because it is also the principal source of parameter uncertainty in this work, we did not treat it as settled but subjected it to the dedicated robustness test described below.

## 3.3. Genome re-annotation had displaced the published locus tags for Wzb and Wzc

Sequence retrieval by locus tag failed, and the proteins were resolved instead by keyword matching. This revealed that genome re-annotation had changed both the format and the numbering of the locus tags relative to the values reported in the primary phenotypic study (ABBFA003460/ABBFA003461 → ABBFA_03430/ABBFA_03431). The resolved proteins are the low-molecular-weight protein tyrosine phosphatase Ptp/Wzb (GenBank ATY45834.1; 142 amino acids) and the bacterial tyrosine kinase Ptk/Wzc (GenBank ATY45835.1; 727 amino acids). The canonical low-molecular-weight protein tyrosine phosphatase catalytic motif CX₅R was confirmed in Wzb by direct sequence inspection (C10-I-G-N-I-C15-R16).

This discrepancy is reported explicitly because it determines which sequences enter every downstream step. Had the published locus tags been used uncritically, the modeled proteins would not have corresponded to the intended target.

## 3.4. Control analysis assigns flux control almost entirely to the kinase

At steady state, the model predicted a phosphorylated fraction x* = 0.0049 — approximately 0.5% of total Wzc in the phosphorylated state — and a cycling flux J = 0.0071 in arbitrary units, with total Wzc normalized to unity. The flux-control coefficients were C^J_kinase = +0.997 and C^J_phosphatase = +0.003, with ΣC^J = 1.0000, numerically confirming the flux-control summation theorem. Concentration-control coefficients over the phosphorylated level were C^x_kinase = +1.002 and C^x_phosphatase = −1.002 (ΣC^x = −0.0001), likewise confirming the corresponding summation theorem for a conserved moiety.

Sobol total-order sensitivity indices computed under ±50% parameter uncertainty agreed with the point estimate for flux control (S_T,kinase = 1.000; S_T,phosphatase = 0.000). For level control, however, they were markedly less asymmetric (S_T,kinase = 0.461; S_T,phosphatase = 0.576). Flux control and level control therefore diverge for this cycle. The distinction carries mechanistic consequences, since it implies that the quantity a regulator would most effectively perturb is the cycling flux rather than the steady-state phosphorylation level.

An asymmetry of this magnitude (C^J_kinase ≈ 0.997) lies far outside what a ±50% variance-based analysis can meaningfully stress-test. We therefore performed a breakpoint analysis in which k_cat,kin was swept until control became evenly shared. Equal sharing (C^J_kinase = 0.5) required a 102-fold increase in k_cat,kin, to 1.53 s⁻¹ (**Figure 2**). Overturning the qualitative conclusion would thus require a two-order-of-magnitude error in the literature-derived kinase turnover number. This is a far more demanding criterion than the asymmetry itself, and one that the documented approximation layers (Section 3.2) are unlikely to reach.

Independent qualitative support comes from cryo-electron microscopy work on *E. coli* Wzc, which describes the protein as expected to cycle continuously between phosphorylated monomers and dephosphorylated octamers. That description is consistent with a phosphatase-dominated resting state and a kinase-limited transition, and it matches the low predicted x* independently of the quantitative model.

Applying the pre-specified decision rule, C^J_kinase − C^J_phosphatase = +0.995 ≥ 0.15 assigned the cytoplasmic kinase domain of Wzc as the structural target for all subsequent phases.

## 3.5. The AlphaFold3 model is highly confident at the catalytic site despite a moderate global score

The full-length AlphaFold3 model returned a predicted template modeling (pTM) score of 0.76, uniform across the five generated models and free of steric clashes. Predicted aligned error (PAE) analysis attributed this moderate global score to uncertainty in the relative orientation of the cytoplasmic kinase domain with respect to the transmembrane and periplasmic regions (inter-domain PAE 9.8–15.9 Å). It did not reflect poor intra-domain fold quality, which was high (intra-domain PAE 4.8 Å; Walker A/B region 1.7 Å). This distinction is mechanistically expected rather than anomalous: mobility of the kinase domain relative to the rest of Wzc is required for octamer disassembly, so a rigid inter-domain prediction would have been the more suspect result.

Within the retained 250-residue domain (residues 451–700), the mean predicted local distance difference test (pLDDT) score was 93.5, with 96% of residues above 70. The catalytic Walker A (mean 95.9; minimum 91.9) and Walker B (mean 96.4; minimum 93.7) motifs were among the most confidently predicted regions of the entire structure. By contrast, the excluded C-terminal tyrosine-rich tail (residues 701–727) averaged 63.3, consistent with its expected intrinsic disorder (**Figure 3**). Confidence is therefore highest precisely where the docking site lies.

## 3.6. The ATP pocket is more conserved than the domain average

Structural superposition against the isolated *E. coli* kinase-domain crystal structure (PDB 3LA6) yielded a root-mean-square deviation (RMSD) of 1.72 Å over 234 aligned Cα pairs, at 46.6% sequence identity in the aligned region. As an independent cross-check using a different algorithm, iterative all-atom alignment with outlier rejection converged to RMSD = 0.72 Å over a best-fit core of 1,168 of 1,557 atoms. The lower value reflects the exclusion of peripheral, poorly superimposing loops, as expected. Both methods agree that the fold is well conserved and within the range considered reliable for structure-based docking of a predicted model.

Of the 20 residues contacting adenosine diphosphate (ADP) in 3LA6 (≤4.5 Å), 18 mapped within the aligned region and defined the *A. baumannii* docking-site residue set: 481, 482, 483, 484, 487, 488, 496, 498, 499, 541, 542, 543, 544, 545, 546, 547, 548, and 575 (**Figure 4**). Sequence identity within this pocket (50%; 9 of 18 residues identical) exceeded the domain-wide average of 46.6%, consistent with functional conservation of the catalytic site under purifying selection.

PDB 3LA6 corresponds to the Walker A K540M catalytically inactive mutant, used crystallographically to trap ADP without turnover. The equivalent *A. baumannii* residue, Lys546, is intact in the present model, which was predicted from the wild-type sequence. This difference becomes relevant to the interpretation in Section 3.12.

## 3.7. Rigid redocking recovers the phosphate subsite but not the adenine subsite

Redocking of the native ADP ligand into the *A. baumannii* model failed the RMSD < 2 Å success criterion in two independent runs (4.08 Å and 5.76 Å, the latter on a different machine and random seed). The same protocol succeeded against the native 3LA6 receptor as a positive control (0.77 Å). This isolates the discrepancy to receptor-model side-chain geometry rather than to the validity of the docking protocol itself.

In both independent runs, the ADP phosphate moiety correctly engaged the predicted Walker A backbone amides — Glu543, Lys546, and Ser547 — at hydrogen-bond distances of 2.2–2.4 Å. The adenine moiety, however, displaced toward Ala672, Ile700, and Arg673. These residues lie outside the homology-mapped pocket, with Ile700 at the C-terminal boundary of the modeled domain (**Table S3**).

Flexible-side-chain redocking, attempted as a remedy, could not be completed. The spatial extent required by the 18 mobile side chains, approximately 41 × 31 × 25 Å, exceeded the fixed 25 × 25 × 25 Å search box, and the available computational resources did not permit the larger box. This line of investigation was closed by decision, with the cause documented rather than left unexplained. The consequence for subsequent work is explicit: the binding site is defined here by structural homology, not by redocking success, and rigid docking scores are used for relative ranking among candidates rather than as absolute affinity estimates.

## 3.8. A hybrid selection strategy preserved kinase-relevant chemotypes that clustering alone would have discarded

The screening library was assembled from ChEMBL, through a mechanism-of-action search for kinase inhibitors that yielded 29 unique compounds with 25 retrievable structures, and from COCONUT, filtered to 150–600 Da and randomly subsampled to 3,000 entries before downstream filtering. DrugBank was unavailable throughout data collection because of a platform-wide suspension of academic downloads, and the PubChem curated drug-name cross-reference could not be retrieved because of a persistent server-side error. After deduplication by canonical structure rather than by text string, and removal of 260 pan-assay interference compounds (PAINS; 8.6%), the combined library comprised 2,346 compounds (2,322 from COCONUT; 24 from ChEMBL).

Compounds were then evaluated against five independent drug-likeness rule sets (Lipinski, Ghose, Veber, Egan, and Muegge), computed locally from molecular descriptors rather than submitted to a web service, since no public programming interface exists for bulk submission at this scale. Of the 2,346 compounds, 1,261 (53.7%) satisfied all five rule sets and 1,878 (80.1%) satisfied at least four.

To reduce the 1,878-compound set to a chemically representative and computationally tractable subset, principal component analysis (PCA) was applied to six standardized descriptors: molecular weight (MW), octanol–water partition coefficient (LogP), hydrogen-bond donors (HBD), hydrogen-bond acceptors (HBA), topological polar surface area (TPSA), and rotatable bonds. This was followed by k-means clustering. The two leading components explained 71.7% of the total variance (PC1, 47.4%; PC2, 24.3%). The mathematical elbow occurred at k = 7; a practical value of k = 50 was used instead, prioritizing coverage of chemical space over strict elbow optimality. For each cluster, the real compound nearest the centroid — not the mathematical centroid itself — was retained as the representative.

The input imbalance between sources (2,322 COCONUT versus 24 ChEMBL) propagated into the clustering result: only 2 of 50 cluster representatives were of ChEMBL origin. The ChEMBL subset had been included specifically to supply ATP-pocket-relevant chemotypes, so accepting the clustering output alone would have discarded the very rationale for including that source. A hybrid selection was therefore used. All 18 ChEMBL compounds satisfying at least four of five drug-likeness rules were retained irrespective of cluster assignment and combined with the 48 COCONUT cluster representatives, yielding a final 66-compound candidate set (**Figure 5**).

Descriptor correlation analysis (**Figure 5A**) showed the expected strong association between TPSA and HBA (r = 0.84). This is consistent with polar surface area being driven largely by heteroatom acceptors, and it justifies dimensionality reduction before clustering. Functional-group analysis of the 50 representatives (**Figure 5D**) showed a composition dominated by ether (38 of 50), hydroxyl (30 of 50), and aromatic-ring-containing (27 of 50) scaffolds. Amide (17 of 50) and amine (8 of 50) groups were less frequent, carboxylic acid appeared in a minority (5 of 50), and no halogenated compounds were present at all. This profile is consistent with a natural-product-dominated library and stands in clear contrast to synthetic libraries, in which halogenation is common.

## 3.9. Structural engagement, not affinity rank, identified the lead candidate

All 66 compounds were docked in triplicate against the validated pocket, for 198 runs in total (**Table S4**). Mean affinities ranged from −4.9 to −10.2 kcal/mol, with a median of −7.7 kcal/mol. Replicate standard deviations were small (0.005–0.29 kcal/mol), indicating stable convergence of the rigid search. The top 10 compounds by mean affinity were dominated by COCONUT-derived natural products, 9 of 10 (**Table 2**).

Affinity alone does not guarantee engagement with the catalytic site, as the ADP redocking result had already demonstrated (Section 3.7). Each top-10 pose was therefore additionally evaluated for direct contact with the 18-residue homology-defined pocket and with the 8-residue Walker A/B subset. This revealed a clear dissociation between affinity rank and structural relevance. The top-ranked compound by affinity (lig_042; COCONUT; −10.24 kcal/mol) contacted only 11 of 18 pocket residues and 4 of 8 Walker A/B residues. The compound ranked tenth by affinity, lig_012 (ChEMBL CHEMBL4297643; −9.02 ± 0.09 kcal/mol), contacted 14 of 18 pocket residues and all 8 Walker A/B residues — the only compound in the top 10 to engage that subsite completely (**Figure 6B**).

lig_012 (MW 418.5 Da; LogP 3.08; TPSA 84.8 Å²; quantitative estimate of drug-likeness [QED] 0.44; synthetic accessibility score 2.60; 5 of 5 drug-likeness rules satisfied) was therefore selected as the lead candidate on combined structural and physicochemical grounds (**Figure 6C**). Notably, lig_012 originates from the ChEMBL kinase-inhibitor search, the source included precisely to supply ATP-pocket chemotypes. Its selection over higher-scoring natural products is thus consistent with, rather than contrary to, the library's design rationale.

Structural alert screening flagged an imine/hydrazone linkage (aryl-CH=N–NH-aryl) under the Brenk filter; no PAINS, National Institutes of Health, or ZINC alerts were raised. We report this alert rather than omit it. It does not disqualify the compound at the present in silico stage, but it identifies a specific liability — hydrazone hydrolytic stability — that would require attention in any medicinal-chemistry follow-up.

Protein–ligand interaction profiling of the docked pose identified 5 hydrogen bonds (Gln487, 2.59 Å; Glu543, 2.16 Å and 2.48 Å at two distinct contacts; Gly545, 2.96 Å; Lys546, 2.44 Å), 3 hydrophobic contacts (Val481, Phe548, Tyr575), and 1 π-stacking interaction (Phe548; centroid distance 4.55 Å) (**Table S5**). Glu543 and Lys546 are the same Walker A phosphate-anchoring residues independently engaged in both ADP redocking runs (Section 3.7). This provides a second and independent line of evidence that the subsite is consistently recovered across different ligands and docking runs.

## 3.10. The simulated system was thermodynamically stable across the full 200 ns

Before interpreting any structural observable, we verified that the simulation itself was physically well behaved, since no conformational conclusion is meaningful if the underlying ensemble is not. All four system-level properties remained stable across the full 200 ns trajectory (**Table 3**; **Figure S1**).

Temperature averaged 310.14 ± 1.30 K against a 310.15 K target, with a total drift of 0.003 K. Pressure averaged 1.01 ± 103.56 bar against a 1.0 bar target. The large standard deviation reflects the expected noise of the instantaneous virial estimate in a system of this size and does not indicate instability, since the mean is accurate to within 1%. Density averaged 1,022.1 ± 2.1 kg/m³, consistent with an aqueous system containing protein, ligand, and neutralizing ions, and showed no systematic trend. Potential energy averaged −897,245 ± 1,057 kJ/mol with a total drift of −103.7 kJ/mol, a relative drift of approximately 0.01% over 200 ns.

The absence of sustained drift in any of these quantities indicates that the system reached and maintained a consistent thermodynamic state, rather than continuing to relax throughout the production run.

## 3.11. Structural observables changed in a defined temporal sequence and then plateaued

Four structural observables changed during the first third of the trajectory and then reached stable plateaus, but they did not change simultaneously (**Figure 7**; **Table 3**). Their temporal ordering is itself informative and is described here in the sequence observed.

Ligand RMSD, measured after superposition on the protein backbone, moved first. It rose steeply within the first 5 ns and then continued to increase gradually, reaching a plateau of 7.43 ± 0.74 Å near 70–75 ns (**Figure 7B**). Backbone RMSD of the protein followed. It fluctuated between 2 and 3 Å for the first 40 ns, and then rose in a distinct step at 45–55 ns to a plateau of 3.32 ± 0.35 Å that was maintained for the remaining 145 ns (**Figure 7A**). Compaction came last. The radius of gyration (R_g) first underwent a transient expansion, peaking near 18.85 Å at approximately 30 ns, before decreasing sharply at about 70 ns to a plateau of 18.17 ± 0.09 Å (**Figure 7D**). Solvent-accessible surface area (SASA) declined in the same window, stepping down near 72 ns from roughly 13,500 Å² to a plateau of 12,999.7 ± 278.7 Å² (**Figure 7E**).

Principal component analysis of the backbone confirmed that these changes describe a single directed transition rather than random drift. Projections onto the first two components (PC1, 35.9%; PC2, 16.6% of variance) separate the early trajectory from the late trajectory along PC1, and the late frames converge into one compact cluster instead of continuing to disperse (**Figure 7F**).

The concordant decrease in both R_g and SASA identifies the final stage as compaction with burial of the binding site, not as partial unfolding, which would have produced the opposite signature in both quantities. The interpretation we favor is that the complex relaxed from a rigid-docking pose — obtained, by construction, in a receptor held fixed (Section 3.7) — into an induced-fit arrangement in which the protein closes around the ligand. The observed order supports this reading: the ligand adjusts first, the backbone rearranges second, and the site closes last. A rigid-receptor pose is not expected to be the free-energy minimum of a flexible system, so this behavior is consistent with the documented limitation of the docking stage rather than in conflict with it.

## 3.12. The ligand reorganized within the site rather than dissociating from it

A ligand displacement of 7.43 Å is comparable to the longest dimension of lig_012 itself. Taken alone, it would be consistent with dissociation, and we treated that possibility as open until it could be tested directly against independent data.

Per-residue contact occupancy over the full trajectory excludes dissociation (**Table 4**). Five pocket residues remained in contact with the ligand in essentially every frame: Phe548 (100.0%), Gly545 (99.9%), Glu543 (99.8%), Tyr575 (99.6%), and Val544 (97.8%). A ligand that had left the site could not maintain contact occupancies of this magnitude. Ligand RMSD and contact occupancy are therefore not in conflict. The ligand reoriented substantially within a pocket that closed around it, and the RMSD captures that reorientation rather than escape.

The contact profile is strongly bimodal. Beyond the five near-permanent contacts, six residues occupied an intermediate regime — Glu488 (76.1%), Ser547 (72.0%), Lys498 (44.5%), Ser499 (38.5%), Arg483 (29.4%), and Pro542 (22.5%). Seven were essentially transient, below 11%: Lys546 (10.6%), Lys496 (9.0%), Gln487 (1.3%), Val481 (0.2%), Ser484 (0.2%), Pro482 (0.05%), and Ser541 (0.0%). Only 7 of the 18 homology-mapped residues exceeded 50% occupancy, and only 5 exceeded 90%, with a median of 34.0% across the set. The static docking pocket is thus a superset of the dynamically maintained core.

Per-residue root-mean-square fluctuation (RMSF) provides an independent structural explanation for this partition (**Figure 7C**). The 18 pocket residues are not uniformly rigid; they separate into two subsets with markedly different mobility. Residues 481–499 fluctuate at approximately 2.5–4.0 Å and are among the more mobile positions in the entire domain, whereas residues 541–548 and 575 fluctuate below 1 Å and are among the least mobile. This stratification maps directly onto the occupancy data: the rigid subset supplies the five near-permanent contacts, while the mobile 481–499 loop region supplies the transient ones, with a median occupancy near 9%. Local rigidity, measured independently of any ligand contact criterion, therefore predicts which contacts persist.

The most informative single result concerns the two Walker A anchors. Glu543 and Lys546 behaved identically in every static analysis performed in this work. Both anchored the ADP phosphate in both independent redocking runs (Section 3.7), and both formed hydrogen bonds to lig_012 in the docked pose (Section 3.9). Under dynamics, their fates diverge sharply: Glu543 persists at 99.8% occupancy, whereas Lys546 falls to 10.6%. The distinction is structurally interpretable. The Glu543 contact is mediated by the P-loop backbone amide, a geometrically constrained feature of the fold, whereas the Lys546 contact depends on a charged, solvent-exposed side chain that is free to reorient and to compete with water. For a phosphate-binding loop, this asymmetry is mechanistically sensible, and no static analysis could have revealed it. Direct distance monitoring reproduced the same ordering, with Glu543 held near 2.4 Å throughout while Lys546 and Gln487 relaxed to approximately 5 Å and 7 Å, respectively (**Figure 8D**).

## 3.13. Aromatic stacking, not hydrogen bonding, is the persistent binding determinant

Interaction profiling at 10 ns intervals across the trajectory (21 time points) detected 25.8 ± 3.0 interactions per frame, ranging from 18 to 31 (**Figure 8E**). The count did not decay. It increased slightly, from a mean of 23.2 over the first 50 ns to 26.7 over the last 50 ns, with a linear trend of +4.1 interactions across the full 200 ns. On this measure the complex consolidated rather than eroded, in agreement with the contact-occupancy data and again arguing against dissociation.

Contact occupancy and interaction classification measure different quantities and are complementary rather than redundant. Occupancy records any heavy-atom pair within 4.5 Å, whereas classification requires the specific geometry of a defined interaction type. Ser547 illustrates the difference: it maintains 72.0% contact occupancy but registers only a brief classified interaction, near 75–85 ns. Both observations are correct, and each answers a different question.

The residue-resolved interaction map identifies which contacts carry the observed stability (**Figure 8C**). The persistent scaffold is aromatic. Phe548 maintained π–π stacking in every sampled frame, and Tyr575 maintained π–π stacking throughout except for a hydrogen-bonded episode between 45 and 65 ns and a brief interruption near 115–125 ns. Tyr579 engaged at the outset, was lost between approximately 15 and 45 ns, and then maintained π–π stacking continuously from 45 ns to the end. Glu543 maintained a donor–π interaction across all 200 ns, and Val544 and Ile491 maintained alkyl–π contacts throughout. Hydrogen bonds, by contrast, were intermittent and appeared predominantly after the conformational transition: Lys495 formed hydrogen bonds from approximately 55 ns onward, with Lys492 and Lys498 contributing episodically thereafter.

This reframes the binding mode relative to what the static pose suggested. The docked pose was described primarily in terms of hydrogen bonds (Section 3.9), but the interactions that persist under dynamics are stacking and π-mediated contacts between the tolyl, pyrimidine, and pyridine rings of lig_012 and the aromatic residues of the pocket. Hydrogen bonds act as a later-forming and more labile secondary layer.

Two further observations follow from the same map. First, the dynamic binding site is broader than the homology-mapped pocket. Ten residues absent from the original 18-residue set were recruited during the simulation — Met458, Ile491, Lys492, Leu494, Lys495, Ile500, Leu503, Asp570, Tyr579, and Asp648 — of which Lys495 and Tyr579 became stable participants. The recruited set is predominantly hydrophobic and lysine-rich, indicating that the ligand samples an adjacent subsite that a static ADP-based mapping does not capture. Second, two of the recruited residues, Asp570 and Asp648, contributed only during the first 5 ns and were then lost permanently, marking them as features of the starting docked pose rather than of the equilibrated complex.

The four-time-point comparison in **Figure 8A,B** summarizes the same progression visually. The electrostatic surface shows a pocket that closes between 0 and 50 ns and remains closed at 100 and 200 ns, while the interaction networks show no classified hydrogen bonds at the first production frame and a stable set from 50 ns onward. Two points of interpretation apply here. The first production frame is not identical to the docked pose analyzed in Section 3.9, since energy minimization and restrained equilibration intervene between them; in addition, the two profiling tools apply different geometric criteria. Either factor, or both, may account for the difference in hydrogen-bond count between the docked pose and the first production frame, and the present data do not distinguish between them. The complete interaction diagrams for all 21 sampled time points are provided in **Figure S2**.

## 3.14. Limitations

Three limitations constrain the interpretation of these results and are stated explicitly rather than left to inference.

First, the molecular dynamics results derive from a single 200 ns trajectory rather than from independent replicates. Where dispersion is reported for trajectory-derived metrics in Table 3, it is the standard deviation between four 50 ns blocks of that same trajectory, not the standard deviation between independent simulations, and it should not be read as such. Block-wise dispersion measures internal consistency within one sampling path; it does not establish reproducibility across independent initial velocity assignments.

Second, the binding site was defined by structural homology rather than validated by redocking, because ADP redocking did not meet the RMSD < 2 Å criterion in the modeled receptor (Section 3.7). Docking scores were accordingly used for relative ranking among candidates and not as absolute affinity estimates, and the lead compound was selected on structural engagement rather than on score.

Third, the kinase turnover number that drives the control analysis is a multiply approximated value (Section 3.2). The breakpoint analysis quantifies how much error that conclusion tolerates — a factor of 102 — but it does not remove the underlying uncertainty. Resolving it would require a direct kinetic measurement on the *A. baumannii* enzyme.

---

# Table and Figure Captions

## Main-text tables

**Table 1.** Kinetic parameters of the Wzb/Wzc phosphorylation cycle used in the ordinary differential equation model, with provenance and approximation level for each value.

*Abbreviations:* ATP, adenosine triphosphate; K_D, dissociation constant; k_cat, catalytic constant (turnover number); K_m, Michaelis constant; MW, molecular weight; pNPP, para-nitrophenyl phosphate.
*Note:* "Direct" indicates a value reported numerically in the cited source. "Derived" indicates a value calculated in this work from reported quantities, with the calculation and its approximation layers described in the Methods.

**Table 2.** Top 10 candidates from rigid docking of the 66-compound hybrid library against the validated Wzc kinase-domain pocket, ranked by mean binding affinity across three independent replicates.

*Abbreviations:* ΔG, binding affinity score; QED, quantitative estimate of drug-likeness; SA score, synthetic accessibility score; SD, standard deviation.
*Note:* Pocket residues refer to the 18-residue homology-mapped site defined in Section 3.6; Walker A/B residues refer to the 8-residue catalytic subset within it. The selected lead, lig_012, ranks tenth by affinity but first by both engagement criteria.

**Table 3.** Structural and thermodynamic stability of the protein–ligand complex over the 200 ns production trajectory.

*Abbreviations:* R_g, radius of gyration; RMSD, root-mean-square deviation; SASA, solvent-accessible surface area; SD, standard deviation.
*Note:* Dispersion for structural metrics is the standard deviation between four 50 ns blocks of a single trajectory and is not a standard deviation between independent replicates (Section 3.14). Dispersion for thermodynamic properties is the standard deviation across all recorded frames. The large dispersion in pressure reflects the expected noise of the instantaneous virial estimate and not system instability.

**Table 4.** Per-residue contact occupancy between lig_012 and the 18 homology-mapped pocket residues across the 200 ns trajectory, expressed as the percentage of frames in which any heavy atom of the residue lay within 4.5 Å of any heavy atom of the ligand.

*Note:* The distance threshold and residue set are identical to those used in the docking-stage contact analysis (Section 3.9), so that the two analyses are directly comparable. The bimodal distribution — five residues above 97% and seven below 11% — indicates that the static docking pocket is a superset of the dynamically maintained core. Contact occupancy records any heavy-atom pair within the threshold and is therefore broader than the interaction classification shown in Figure 8C, which additionally requires the specific geometry of a defined interaction type.

## Main-text figures

**Figure 1.** PRISMA 2020 flow diagram of the systematic search for Wzb/Wzc kinetic, structural, and pharmacological parameters. Records were identified across five bibliographic platforms and one structural database using 11 search queries, then screened by title and abstract and subsequently by full text against pre-specified criteria.

*Abbreviations:* n, number of records; PRISMA, Preferred Reporting Items for Systematic Reviews and Meta-Analyses.
*Note:* The diagram depicts only the 14 sources obtained through the formal search (entries F01–F14 of Table S1). The four sources identified through other mechanisms (F15–F18) are deliberately excluded from the diagram and are described in Section 3.1.

**Figure 2.** Breakpoint analysis of flux-control robustness to uncertainty in the kinase turnover number. The flux-control coefficient of the kinase is plotted against k_cat,kin swept over a wide multiplicative range. The literature-derived value and the breakpoint at which control becomes evenly shared between the two enzymes are marked.

*Abbreviations:* C^J, flux-control coefficient; k_cat,kin, kinase catalytic constant.

**Figure 3.** Structural confidence of the AlphaFold3 model of *A. baumannii* Wzc. (**A**) Per-residue pLDDT across the full-length protein, annotated with the transmembrane helices, the retained kinase domain, the Walker A and Walker B motifs, and the excluded tyrosine-rich tail. (**B**) Predicted aligned error heatmap. (**C**) Mean pLDDT by functional region.

*Abbreviations:* PAE, predicted aligned error; pLDDT, predicted local distance difference test; pTM, predicted template modeling score.

**Figure 4.** Structural superposition of the *A. baumannii* Wzc kinase domain (blue) onto the isolated *E. coli* kinase-domain crystal structure PDB 3LA6 (gray, transparent), with ADP shown as sticks and the 18 mapped pocket residues in orange.

*Abbreviations:* ADP, adenosine diphosphate; PDB, Protein Data Bank; RMSD, root-mean-square deviation.
*Note:* 3LA6 is the catalytically inactive Walker A K540M mutant, crystallized to trap ADP without turnover. The corresponding *A. baumannii* residue, Lys546, is intact in the present wild-type-derived model.

**Figure 5.** Chemical space characterization and curation of the ligand library. (**A**) Correlation matrix of seven molecular descriptors. (**B**) Elbow analysis for k-means clustering, showing the mathematical elbow and the practical value adopted. (**C**) PCA chemical space with the 50 cluster representatives marked. (**D**) Functional-group composition of the 50 representatives.

*Abbreviations:* HBA, hydrogen-bond acceptors; HBD, hydrogen-bond donors; LogP, octanol–water partition coefficient; MW, molecular weight; PC1/PC2, first and second principal components; PCA, principal component analysis; TPSA, topological polar surface area; WCSS, within-cluster sum of squares.

**Figure 6.** Docking screening results for the 66-compound hybrid library against the validated Wzc kinase-domain pocket. (**A**) Top 10 compounds ranked by mean rigid-docking affinity across three independent replicates; error bars indicate standard deviation. (**B**) Binding affinity plotted against structural pocket engagement; marker size encodes the number of Walker A/B residues contacted and color encodes QED. (**C**) Two-dimensional structure of the selected lead, lig_012 (ChEMBL CHEMBL4297643). (**D**) Interaction distances detected in the docked pose of lig_012.

*Abbreviations:* QED, quantitative estimate of drug-likeness; SA score, synthetic accessibility score; SD, standard deviation.
*Note:* Panel B illustrates the central selection criterion of this work: lig_012 ranks tenth by affinity yet contacts the most validated pocket residues and all eight Walker A/B residues.

**Figure 7.** Structural stability of the Wzc–lig_012 complex over the 200 ns production trajectory. (**A**) Backbone RMSD of the protein. (**B**) RMSD of the ligand after superposition on the protein backbone. (**C**) Per-residue RMSF, with the 18 homology-mapped pocket residues highlighted in red. (**D**) Radius of gyration of the protein. (**E**) Solvent-accessible surface area of the complex. (**F**) Projection of the trajectory onto the first two principal components of backbone motion, colored by simulation time.

*Abbreviations:* PC1/PC2, first and second principal components; R_g, radius of gyration; RMSD, root-mean-square deviation; RMSF, root-mean-square fluctuation; SASA, solvent-accessible surface area.
*Note:* Panels A, B, D, and E change in a defined temporal order — ligand first, backbone at 45–55 ns, compaction and burial near 70 ns — and then plateau. In panel C, the highlighted pocket residues separate into two subsets: residues 481–499 fluctuate at 2.5–4.0 Å, whereas residues 541–548 and 575 fluctuate below 1 Å. This stratification corresponds to the bimodal contact occupancy reported in Table 4.

**Figure 8.** Evolution of protein–ligand interactions across the 200 ns trajectory. (**A**) Electrostatic surface of the complex at 0, 50, 100, and 200 ns. (**B**) Interaction networks at the same four time points. (**C**) Residue-resolved interaction-type map across the trajectory, sampled every 10 ns; color encodes the dominant interaction type per residue and time point. (**D**) Minimum distance from the ligand to the three residues identified as key in the static docked pose. (**E**) Aggregate interaction counts by type over time.

*Abbreviations:* ns, nanoseconds; π–π, pi–pi stacking.
*Note:* In panel C, residues engaging in more than one interaction type at a given time point are colored by the dominant type, ranked in the order hydrogen bond > π-cation > π–π stacking > donor–π > carbon–π > alkyl–π > hydrophobic. The first production frame shown in panels A and B follows energy minimization and restrained equilibration and is therefore not identical to the docked pose analyzed in Section 3.9.

## Supplementary tables

**Table S1.** Master extraction table of the systematic review and subsequent targeted searches, documenting the inclusion pathway for each of the 18 sources.

**Table S2.** Adapted seven-domain quality appraisal for each of the 18 sources.

**Table S3.** ADP redocking interaction distances in the *A. baumannii* rigid receptor, from the independent validation run.

**Table S4.** Complete rigid-docking results for all 66 compounds of the hybrid candidate library, including ranking, source, mean and best-hit affinity, number of drug-likeness rules satisfied, and physicochemical descriptors.

**Table S5.** Protein–ligand interactions detected in the docked pose of lig_012, with residue, interaction type, distance, and angle.

## Supplementary figures

**Figure S1.** Thermodynamic stability of the simulated system over the 200 ns production trajectory. (**A**) Temperature. (**B**) Pressure. (**C**) Density. (**D**) Potential energy.

*Note:* All four properties fluctuate about stable means without sustained drift, confirming that the production ensemble is physically well behaved.

**Figure S2.** Complete gallery of protein–ligand interaction diagrams at 10 ns intervals across the 200 ns trajectory (21 time points).
