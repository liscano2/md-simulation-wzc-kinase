# AUDITORÍA 002 — Fase 3, corrida de AlphaFold3 (Wzc, dominio quinasa)

**Fecha:** 1 de agosto de 2026. **Insumo auditado:** `fold_2026_08_01_12_29.zip`, corrida real del
usuario en alphafoldserver.com.

## 0. Lo que se envió vs. lo que se planeó

**Desviación del plan detectada.** Se envió la proteína **completa** de Wzc (727 aa), no el
dominio quinasa citoplasmático aislado que habíamos acordado (Compuerta 4, plan v2). Esto incluye
las dos hélices transmembranales N-terminales.

**¿Es un problema?** No para el resultado final — ver §2 y §3 — pero sí cambia el pTM global (ver
§1) y significa que hay que **recortar** el dominio antes de usarlo en docking, en vez de usar el
modelo tal cual. Ya se hizo (§4).

## 1. Confianza global — R1 (biología estructural)

| Métrica | Valor | Lectura |
|---|---|---|
| pTM | 0,76 | Moderado — ver §2 para la explicación |
| ipTM | ninguno (no aplica, cadena única) | — |
| fracción desordenada | 0,05–0,06 | Baja, razonable |
| clashes | 0,0 | Ninguno |
| ranking_score | 0,78–0,79 | Consistente entre los 5 modelos generados |

**Los 5 modelos son prácticamente idénticos en confianza** (pTM=0,76 en todos) — buena señal de
convergencia, no de un resultado inestable.

## 2. Por qué el pTM global (0,76) es engañoso si se usa solo — R1

Diagnóstico con la matriz PAE completa:

| Comparación | PAE promedio | Lectura |
|---|---|---|
| Dentro del dominio quinasa (451-700) | 4,8 Å | Muy confiable |
| Dentro de la zona Walker A/B (529-575) | **1,7 Å** | Extremadamente confiable |
| Dentro de la región TM (1-60) | 7,9 Å | Confiable |
| Dominio quinasa ↔ región TM | 9,8 Å | Orientación relativa incierta |
| Dominio quinasa ↔ resto (loop periplásmico) | 15,9 Å | Sin confianza en la orientación relativa |

**Conclusión de R1:** el pTM moderado no refleja mala calidad del dominio catalítico — refleja
que AlphaFold3 (correctamente) no tiene certeza sobre cómo se orienta el dominio citoplasmático
respecto al resto de la proteína, porque están conectados por una región con movilidad real
(consistente con la biología: el dominio quinasa debe moverse para permitir el desensamblaje del
octámero descrito por Yang et al. 2021). **Esto no es un defecto del modelo, es información real.**
El dato que importa para docking es la calidad *dentro* del dominio, que es alta.

## 3. Calidad local en el sitio de interés — R1 + R2

| Región | pLDDT media | pLDDT mínima | % residuos >70 |
|---|---|---|---|
| Proteína completa | 87,9 | 37,6 | — |
| Hélices TM (16-45) | 93,8 | 80,5 | 100% |
| Dominio quinasa (451-700, recorte final) | 93,5 | 58,8 | 96% |
| **Walker A ±10 (pos. 539)** | **95,9** | **91,9** | **100%** |
| **Walker B ±10 (pos. 564)** | **96,4** | **93,7** | **100%** |
| Cola de tirosinas (701-727, EXCLUIDA del recorte) | 63,3 | 41,0 | 30% |

**Veredicto de R2:** el sitio catalítico (Walker A/B, donde va a ir el docking) tiene la mejor
confianza de toda la estructura. La cola de tirosinas C-terminal, correctamente excluida del
dominio usado para docking, tiene baja confianza — consistente con ser una región intrínsecamente
flexible (tiene que estarlo: se fosforila y necesita movilidad para eso). **Esto es exactamente
lo que se esperaría de una predicción correcta, no una señal de alarma.**

## 4. Plantillas usadas por AlphaFold3 — hallazgo nuevo, no anticipado

AlphaFold3 usó 4 plantillas reales, identificadas en el zip:

| PDB | Qué es | Ya la teníamos? |
|---|---|---|
| 7NHR | Octámero cryo-EM de Wzc (*E. coli*), la que ya usamos como referencia | Sí |
| 7NI2 | Estructura relacionada de la misma serie | No, nueva |
| **3LA6** | **Cristal del dominio quinasa (447-720) + ADP unido, *E. coli*** | **No — hallazgo importante** |
| 3CIO | Cristal de Etk (homólogo Wzc de la cepa K30) | No, nueva |

**3LA6 resuelve el Bloqueante 6 de la auditoría anterior** (R2, "sin control positivo para
docking en el bolsillo de ATP"): es un cristal del mismo dominio con **ADP realmente unido dentro
del sitio catalítico**. Además, Yang et al. 2021 declaran haber usado 3LA6 como plantilla de
homología para construir el dominio quinasa de 7NHR — hay una cadena de evidencia estructural
completa y consistente entre tres fuentes independientes (3LA6 → 7NHR → nuestro modelo AF3).

## 5. Extracción del dominio — decisión y trazabilidad

**Límite usado:** residuos 451-700 de la numeración de *A. baumannii*.

**Justificación (no arbitraria):** Yang et al. 2021 definen el dominio quinasa de *E. coli* como
Arg452-Lys701, con Walker A (Lys540) 88 residuos después del inicio y 161 antes del final. Se
localizó el Walker A real en la secuencia de *A. baumannii* (posición 539, motivo `GPSPEVGKS`,
patrón `[AG]X5GK[S/T]` — **nota: el patrón correcto tiene 5 residuos variables, no 4 como se
había programado por error en el script de la sesión anterior, ya corregido**) y se aplicó el
mismo desplazamiento relativo: 539−88=451, 539+161=700.

**Resultado del recorte:** 250 aa, pLDDT media 93,5, 96% de residuos con pLDDT >70. Guardado como
`Wzc_dominio_quinasa_Abaumannii_modelo0.pdb`.

## 6. Bloqueantes / hallazgos de esta auditoría

| # | Hallazgo | Severidad | Acción |
|---|---|---|---|
| 1 | Se modeló la proteína completa, no el dominio aislado | Menor (no bloquea — se recortó con criterio real) | Resuelto — recorte trazable en §5 |
| 2 | Bug corregido: el patrón de Walker A usado en la sesión de curaduría tenía un espaciador incorrecto (X4 en vez de X5) | Menor, ya corregido | Resuelto |
| 3 | 3LA6 y 3CIO no estaban en nuestra tabla de estructuras hasta esta sesión | Informativo — mejora el proyecto | Resuelto — F17/F18 añadidas |
| 4 | Solo se generó/revisó el `model_0` de los 5 disponibles | Menor | Confirmado por decisión explícita del usuario: se sigue solo con model_0 |
| 5 | Superposición estructural real contra 7NHR y 3LA6 no realizada todavía (solo comparación por PAE/plantilla, no un alineamiento 3D real) | Mayor | **RESUELTO — ver §8, resultado real con RMSD** |
| 6 | Bloqueante de la auditoría anterior (R2: "sin control positivo para docking") | — | **Resuelto**: 3LA6 con ADP cumple ese rol |

## 8. Superposición real y bolsillo de docking (2026-08-01, actualización)

**Metodología:** alineamiento de secuencias (BLOSUM62, global) entre el dominio recortado de
*A. baumannii* (451-700, 250 aa) y la cadena A de 3LA6 (259 aa) — **no** por número de residuo
crudo, exactamente para evitar el error que ya se había corregido antes con Walker A. Solo se
superpusieron los pares de Cα que el alineamiento confirma como equivalentes.

| Métrica | Valor |
|---|---|
| Pares de Cα alineados sin gaps | 234 |
| Identidad de secuencia (dominio completo) | 46,6% |
| **RMSD de la superposición** | **1,72 Å** |
| Residuos del bolsillo de ADP (3LA6, dentro de 4,5 Å del ligando) | 20 |
| Residuos trasladados con éxito a *A. baumannii* | 18 (2 cayeron fuera de la región alineada) |
| Identidad de secuencia **dentro del bolsillo** | 9/18 = 50% |

**Interpretación de R1/R2:** RMSD de 1,72 Å con 46,6% de identidad es una señal fuerte de
plegamiento conservado — está en el rango típico de homólogos estructurales confiables para
docking. El bolsillo catalítico está *más* conservado (50%) que el promedio del dominio (46,6%),
exactamente el patrón que se espera de un sitio funcional bajo presión selectiva — es una
verificación de consistencia interna, no solo un número aislado.

**Corrección importante de nomenclatura:** 3LA6 es el mutante **K540M** (catalíticamente
inactivo), no la forma silvestre — estrategia estándar para cristalizar con nucleótido unido sin
recambio catalítico. El residuo equivalente en nuestro modelo de *A. baumannii* es **Lys546**,
intacto (nuestro modelo parte de la secuencia silvestre real).

**Bolsillo de docking definido — residuos de *A. baumannii* (numeración real del modelo):**
```
481, 482, 483, 484, 487, 488, 496, 498, 499, 541, 542, 543, 544, 545, 546, 547, 548, 575
```
Estos son los residuos que se usarán para definir la caja de docking en AutoDock Vina (Fase 4).

**Archivos generados:** `AF3_Abaumannii_superpuesto_a_3LA6.pdb` (estructura completa ya alineada
espacialmente a 3LA6, útil para inspección visual conjunta en PyMOL/ChimeraX).

## 9. Veredicto final

**Fase 3 CERRADA.** RMSD real de 1,72 Å confirma que el modelo de *A. baumannii* conserva el
plegamiento del dominio quinasa de referencia. El bolsillo de docking está definido con 18
residuos concretos, con conservación funcional verificable (50% de identidad, superior al
promedio del dominio, 46,6%). No quedan bloqueantes. Único pendiente no crítico: comparar los
otros 4 modelos de AlphaFold3 si en algún momento se quiere reforzar el ensamble (decisión ya
tomada por el usuario: no hacerlo por ahora, seguir solo con model_0).
