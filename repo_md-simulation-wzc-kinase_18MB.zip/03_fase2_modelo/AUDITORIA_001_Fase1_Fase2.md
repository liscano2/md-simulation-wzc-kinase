# AUDITORÍA ADVERSARIAL — Fase 1 (curaduría) + Fase 2 (modelo del ciclo)
### Proyecto Wzb/Wzc — *Kinases and Phosphatases* (MDPI)

**Fecha:** 31 de julio de 2026. **Activada por:** el usuario, antes de comprometer la Compuerta 4
con el resultado "la quinasa domina el control del flujo (C^J=0,997)".

**Nota de honestidad procesal:** el usuario indicó haber adjuntado Doublet et al. 1999 (*FEBS
Lett* 445:137-143) para reforzar esta auditoría. El archivo no llegó a este mensaje. Esta
auditoría se hizo con lo efectivamente disponible; **no se inventó ni se asumió contenido de esa
fuente**. Ver Bloqueante R1-1 más abajo.

Se realizaron 2 búsquedas dirigidas nuevas para esta auditoría (no se reciclaron búsquedas
anteriores sin verificar): (1) evidencia independiente sobre si el ciclo Wzc/Wzb es
limitado-por-quinasa *in vivo*; (2) modelos cinéticos/MCA competidores publicados en 2024-2026.

---

## R1 — Biología de sistemas y modelado cinético

| Ítem del checklist | Veredicto |
|---|---|
| Unidades homogéneas | **Parcial.** Km_fosfatasa (1 mM, sustrato pNPP) y Km_quinasa (1,1 mM, KD de ATP) son cantidades conceptualmente distintas forzadas a la misma forma funcional (saturación en [Wzc]). No es un error de unidades en sentido estricto, pero sí una aproximación estructural del modelo que debe declararse explícitamente, no solo en una nota de tabla. |
| [E] conocida o Vmax asumido | Vmax se normalizó asumiendo [E_Wzb]=[E_Wzc]=1 (referencia arbitraria) porque no hay abundancia real (PaxDb pendiente). La comparación de control depende de esta igualdad asumida — declarar como supuesto explícito. |
| Conservación del pool impuesta | Sí, correcta (Wzc_total constante). |
| ΣC^J = 1 reportado | Sí, verificado numéricamente (1,0000). |
| Sobol sobre el rango declarado | Sí, ±50 %, resultado robusto (ST=1,000/0,000 sobre el flujo). |
| Valores de ortólogo marcados fila por fila | Sí, columna `es_ortologo` completa en las 25 filas de `tabla_S1_curaduria.csv`. |
| ¿El ACM se usa donde tiene sentido o se fuerza? | Se usa correctamente. Y esta auditoría encontró el respaldo bibliográfico que faltaba: la extensión de los teoremas de sumatoria a **ciclos con metabolito conservado** (ΣFCC=1 sobre el flujo, ΣCCC=0 sobre el nivel) es un resultado clásico de la teoría de control metabólico, citable (PMID 3996393) — **antes se derivaba solo por argumento de escalado sin cita; ya no hace falta esa evasiva.** |
| ¿El SBML reproduce el resultado? | **No hecho todavía.** Pendiente antes de cerrar la Fase 2 formalmente. |

**Hallazgo de apoyo independiente encontrado en esta auditoría:** el propio modelo cualitativo de
Yang et al. 2021 (*Nat Commun*, la fuente estructural que ya citamos) describe que <cite index="169-1">Wzc se espera que cicle constantemente entre monómeros fosforilados y octámeros desfosforilados en la célula.</cite> Esto es consistente, de forma independiente, con un sistema limitado por la quinasa (la fosfatasa resetea rápido el estado, la quinasa es el evento lento que dispara el desensamble) — **refuerza** la plausibilidad biológica del resultado cuantitativo, no lo contradice.

### Bloqueantes (R1)
- **R1-1. RESUELTO (31/07/2026, con matiz).** El usuario adjuntó Doublet et al. 1999. Se leyó
  completo: **no contiene Km, kcat ni KD numérico** — es un artículo de mapeo de sitio por
  mutagénesis con ensayos cualitativos (unión a FSBA sí/no; autofosforilación sí/no), no cinética
  de Michaelis-Menten clásica. No mejora el valor numérico de kcat_kin, pero **sí resuelve la
  pregunta de si existía una fuente más directa disponible: no la hay, verificado**. Aporta además
  evidencia mecanística convergente valiosa: identifica el motivo Walker A/B (no el subdominio
  tipo-quinasa-eucariota) como el sitio catalítico real de Ptk, en un ortólogo independiente
  (*A. johnsonii*) — coincide exactamente con Walker A/B/DXD de Wzc (Soulat et al. 2007). Se
  agregó como F16 en `tabla_extraccion.csv`.
- **R1-2.** El uso de actividad ATPasa como proxy de fosforilación productiva **sesga en una
  dirección conocida y declarable**: el propio Soulat et al. dice que Wzc es más eficiente como
  ATPasa que como quinasa *in vitro* — si una fracción de esa hidrólisis es "fútil" (no acoplada a
  fosfotransferencia), el kcat_kin real sería **menor**, no mayor, lo que **reforzaría** la
  dominancia de la quinasa en el control, no la debilitaría. Ya trasladado a Discusión (ver
  celda de Limitaciones en N2).

---

## R2 — Preparación estructural (Fases 3-5 aún no iniciadas — auditoría de disposición, no de ejecución)

| Ítem | Estado |
|---|---|
| Plantillas PDB descargadas | 8/8 verificadas (2WJD, 2FEK, 7DHD, 7DHE, 7NHR, 7NIB, 7NII, 7NIH). Buen estado. |
| Sitio catalítico del nuevo blanco (dominio quinasa de Wzc, tras Compuerta 4) | Parcialmente definido: Walker A (Lys540), Walker B, motivo DXD (Asp562/Asp564, ambos requeridos), Tyr569 (sitio de autofosforilación intramolecular) — todos con fuente real (Soulat et al. 2007). Falta el pLDDT local del sitio en el modelo de *A. baumannii* (aún no generado). |
| Coincidencia de constructos | **Mayor, no verificado.** El constructo usado en la cinética de Soulat et al. (Ser447-Lys720) y el usado en las estructuras cryo-EM de Yang et al. (2021, serie 7NHx/7NIx) — no confirmé en esta sesión que cubran exactamente el mismo rango de residuos. Verificar antes de usar ambas fuentes como si describieran "la misma proteína" sin matices. |
| Control positivo para docking en el nuevo sitio | Pendiente — a diferencia de Wzb (donde 7DHE con bencilfosfonato es candidato natural), no hay aún un ligando de referencia identificado para el bolsillo de ATP de la quinasa. Tarea de Fase 4. |
| Filtros PAINS/selectividad | Siguen aplicando igual; el riesgo se desplaza de "miméticos de fosfotirosina" (relevante para Wzb) a "inhibidores de bolsillo de ATP poco selectivos" (relevante para quinasas en general) — mitigado en parte por la ausencia de homólogos eucariotas en BY-quinasas, ya verificada. |

### Bloqueantes (R2)
Ninguno — es esperable que estos ítems estén pendientes, dado que Fase 3 no ha comenzado. Se
listan como **checklist de arranque de Fase 3**, no como defectos de Fase 1/2.

---

## R3 — Biología de la cápsula/EPS y encaje editorial

| Ítem | Veredicto |
|---|---|
| Cepa y relevancia clínica | Justificada (AB307-0294, única caracterización funcional publicada de *ptp*/*ptk* en *A. baumannii*). |
| Novedad frente a 2024-2026 | Reverificada en esta sesión con una búsqueda dedicada a modelos cinéticos/MCA de Wzc/Wzb — **sin competencia directa encontrada.** El antecedente de 2020 (bloqueo de interacción por homología) sigue siendo el más cercano y ya está diferenciado en el plan. |
| Encaje con el alcance de la revista | **Reforzado por el resultado de N2**, no solo por el diseño: el ángulo "¿manda la quinasa o la fosfatasa?" ahora tiene una respuesta cuantitativa (0,997 vs 0,003), no es solo una pregunta retórica bien encuadrada. |
| Limitaciones declaradas vs. escondidas | Declaradas extensamente y con detalle inusual para esta etapa — buena señal para un revisor real. |
| **Riesgo nuevo, de peso biológico (no solo estadístico)** | El kcat de la quinasa viene de un **constructo truncado** (dominio citoplasmático aislado, sin anclaje de membrana ni el contexto octamérico). Yang et al. 2021 mostraron que la fisiología depende explícitamente del ensamblaje/desensamblaje del octámero — un fragmento aislado en un tubo de ensayo podría no capturar bien la cinética real dentro de ese contexto oligomérico. **Esto debe ir en Limitaciones de forma prominente en el manuscrito, no como nota al pie.** |
| Pendiente administrativo | Verificar indexación de la revista en Scopus/Web of Science antes de comprometer el APC — sigue sin hacerse (tarea del usuario). |

### Bloqueantes (R3)
- **R3-1. RESUELTO (31/07/2026).** Párrafo de limitación sobre el constructo truncado redactado
  e insertado como celda de Markdown al final de `N2_modelo_ciclo_WzbWzc.ipynb`, listo para
  trasladar al manuscrito.

---

## Tabla consolidada

| # | Revisor | Comentario | Severidad | Sección afectada | Acción correctiva | Estado |
|---|---|---|---|---|---|---|
| 1 | R1 | Doublet et al. 1999 no verificado (archivo no recibido) | Bloqueante | Cinética de la quinasa (N2) | Leer y extraer lo que aporte | **Resuelto** — sin número mejor, pero confirma que no existe fuente más directa y aporta convergencia mecanística (Walker A/B) |
| 2 | R1 | kcat_kin vía ATPasa puede sobreestimar la fosforilación productiva | Mayor (mitigado — sesga a favor de H1) | Discusión / Limitaciones | Declarar la direccionalidad del sesgo explícitamente | **Resuelto** — incluido en el párrafo de limitaciones de N2 |
| 3 | R1 | Cita faltante para el teorema de sumatoria en ciclos conservados | Menor | Métodos (N2) | Añadir cita PMID 3996393 | **Resuelto** |
| 4 | R1 | SBML aún no generado | Menor | Reproducibilidad | Generar antes de cerrar Fase 2 formalmente | Pendiente |
| 5 | R2 | Coincidencia de constructos (cinética vs. cryo-EM) no verificada | Mayor | Preparación de Fase 3 | Verificar rango de residuos exacto antes de modelar el sitio | Pendiente, tarea de Fase 3 |
| 6 | R2 | Sin control positivo para docking en el bolsillo de ATP de la quinasa | Menor | Fase 4 | Buscar candidato (p. ej. análogos de ATP no hidrolizables con afinidad reportada) | Pendiente, tarea de Fase 4 |
| 7 | R3 | Constructo truncado sin contexto oligomérico — riesgo biológico, no solo estadístico | Bloqueante para el manuscrito | Discusión / Limitaciones | Redactar párrafo explícito de limitación antes del envío | **Resuelto** — párrafo redactado e insertado en N2 |
| 8 | R3 | Indexación de la revista sin verificar | Mayor | Decisión editorial | Verificar en Scopus/Scimago antes de pagar APC | Pendiente (usuario) |

## Recomendación editorial simulada (actualizada)

**Revisión menor.** Los dos bloqueantes que impedían tratar la Compuerta 4 como definitiva ya se
resolvieron: (1) se verificó que no existe una fuente más directa que Soulat et al. 2007 para el
kcat de la quinasa — Doublet et al. 1999 se leyó completo y no la mejora, pero sí aporta
convergencia mecanística independiente (Walker A/B); (2) el párrafo de limitación sobre el
constructo truncado está redactado. **La Compuerta 4 (docking/DM sobre el dominio quinasa de
Wzc) puede tratarse ahora como la decisión operativa del proyecto**, con las limitaciones
correspondientes ya integradas en el notebook, no pendientes de escribir después.

Quedan 3 ítems menores/mayores sin bloquear el avance: generar el SBML, verificar la coincidencia
exacta de constructos antes de Fase 3, y verificar la indexación de la revista (tarea del
usuario, independiente del pipeline técnico).

## Lista priorizada de arreglos (actualizada — ya no hay bloqueantes para avanzar a Fase 3)

1. ~~Conseguir y leer Doublet et al. 1999~~ — **hecho**.
2. ~~Redactar el párrafo de limitación sobre el constructo truncado~~ — **hecho**.
3. Verificar el rango de residuos del constructo de Soulat vs. las estructuras de Yang antes de
   usarlas conjuntamente en Fase 3. *(primer paso real de Fase 3)*
4. ~~Trasladar la cita PMID 3996393 al notebook N2~~ — **hecho**.
5. Generar el SBML del modelo (puede hacerse en paralelo a Fase 3, no la bloquea).
6. (Recordatorio abierto desde Fase 0) Verificar indexación de la revista — tarea del usuario.
